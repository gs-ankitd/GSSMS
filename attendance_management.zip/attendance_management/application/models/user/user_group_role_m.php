<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Group_Role_m extends CI_Model {

	/* Start of retrieving individual column values*/
	function getRoleId($id) {
		$this->db->where('GRP_ROLE_ID', $id);
		return $this->db->get('user_group_role')->first_row()->Role_ID;			
	}
	function getUserGrpId($id) {
		$this->db->where('GRP_ROLE_ID', $id);
		return $this->db->get('user_group_role')->first_row()->USER_GRP_ID;		
	}

	


/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUserGroupRole() {
		//return $this->db->get('user_group_role')->result();
		return $this->db->query('SELECT a. *,b.ROLE_NM,c.USER_GRP_NM ,g.USER_NAME AS Created_by_Name,h.USER_NAME AS Updated_by_Name
                                 FROM user_group_role a 
								 LEFT JOIN role_mst b ON a.	ROLE_ID = b.	ROLE_ID
								 LEFT JOIN user_group c ON a.USER_GRP_ID = c.USER_GRP_ID
								 LEFT JOIN user_mst g ON a.CREATED_BY = g.USER_ID
								 LEFT JOIN user_mst h ON a.UPDATED_BY = h.USER_ID')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert( $RoleID,$UserGrpID) {
		$data = array(
   					'ROLE_ID' =>$RoleID,
   					'USER_GRP_ID' => $UserGrpID
					);
		$this->db->insert('user_group_role', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($id,  $RoleID,$UserGrpID) {
		$data = array(
   					'ROLE_ID' =>$RoleID,
   					'USER_GRP_ID' => $UserGrpID
					);
		$this->db->where('GRP_ROLE_ID', $id);
		$this->db->update('user_group_role', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($id) {
		$this->db->where('GRP_ROLE_ID', $id);
		$this->db->delete('user_group_role'); 		
	}
/* End of Delete Data */
/*  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx---Validation Check for User Group Role----xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/

	public function checkUserGrpRole($pvs_userGroup,$pvs_userRole)
	{

		$this->db->where('ROLE_ID',$pvs_userRole);
		$this->db->where('USER_GRP_ID',$pvs_userGroup);
		$query=$this->db->get('user_group_role');
		if($query->num_rows() > 0)
		{
			return true; 
		}
		else
		{
			return false;   
		}
	}
	
	
}

?>