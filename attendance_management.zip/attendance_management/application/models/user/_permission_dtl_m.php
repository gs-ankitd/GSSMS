<br />
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Permission_dtl_m extends CI_Model {
 
 
	/* Start of retrieving individual column values*/
	
	function getPermissionsRefTypeId($id) {
		$this->db->where('PERMISSIONS_DTL_ID', $id);
		return $this->db->get('permission_dtl')->first_row()->PERMISSIONS_REF_TYPE_ID;			
	}
	function getPermissionsRefId($id) {
		$this->db->where('PERMISSIONS_DTL_ID', $id);
		return $this->db->get('permission_dtl')->first_row()->PERMISSIONS_REF_ID;			
	}

	function getPermissionsId($id) {
		$this->db->where('PERMISSIONS_DTL_ID', $id);
		return $this->db->get('permission_dtl')->first_row()->PERMISSIONS_ID;			
	}
	
	function getObjectId($id) {
		$this->db->where('PERMISSIONS_DTL_ID', $id);
		return $this->db->get('permission_dtl')->first_row()->OBJECT_ID;			
	}

	
/* End of retrieving individual column values*/

/* Start of retrieving all column values*/

	function getAllPermissionDtl() {
		return $this->db->get('permission_dtl')->result();		
	}

/* End of retrieving all column values*/

/* Start of Insert Data */



	
	function insert($PermissionsRefTypeId, $PermissionsRefId, $PermissionsId, $ObjectId) 
	{
		$data = array(

					'PERMISSIONS_REF_TYPE_ID'  =>  $PermissionsRefTypeId,
					'PERMISSIONS_REF_ID'	   => $PermissionsRefId,
					'PERMISSIONS_ID'		   =>  $PermissionsId,
					'OBJECT_ID' 	     	    =>  $ObjectId,
   					
				);
		$this->db->insert('permission_dtl', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */
	

	function update($pid,$PermissionsRefTypeId,$PermissionsRefId,$PermissionsId,$ObjectId) {
		$data = array(
					'PERMISSIONS_REF_TYPE_ID'  =>  $PermissionsRefTypeId,
					'PERMISSIONS_REF_ID'	   => $PermissionsRefId,
					'PERMISSIONS_ID'		   =>  $PermissionsId,
					'OBJECT_ID' 	     	    =>  $ObjectId,
				);
		$this->db->where('PERMISSIONS_DTL_ID', $pid);
		$this->db->update('permission_dtl', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */
	

	function delete($id) {
		$this->db->where('PERMISSIONS_DTL_ID', $id);
		$this->db->delete('permission_dtl'); 		
	}
/* End of Delete Data */
	
}
