<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_master_m extends CI_Model {

	/* Start of retrieving individual column values*/
	function getUserName($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->USER_NAME;		
	}

	function getReg_email($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->REG_EMAIL_ID;			
	}
	
	function getPassword($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->PASSWORD;			
	}
	
	function getUserStatus($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->USER_STATUS_ID;			
	}
	
	function getPersonid($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row();			
	}
	
	function getExtRefid($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->EXT_REF_NBR;			
	}
	function getUserLastLoginAt($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->LAST_LOGIN_AT;			
	}
	
	function getUserDmnid($id) {
		$this->db->where('USER_ID', $id);
		return $this->db->get('user_mst')->first_row()->DMN_ID;			
	}
	
	
/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUsers() {
		//$this->db->where('IS_DELETED', '0');
		//return $this->db->get('user_mst')->result();
		return $this->db->query('SELECT a.*, b.DMN_NM
								 FROM user_mst a
								 LEFT JOIN user_domain b ON a.DMN_ID = b.DMN_ID
								 WHERE a.IS_DELETED = 0')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($UserName, $REG_EMAIL_ID, $PASSWORD, $UserStatus , $ExtRefid, $Activation, $UserDmnid, $UserLastLoginAt) 
	{
		$data = array(
   					'USER_NAME' =>$UserName,
   					'REG_EMAIL_ID' => $REG_EMAIL_ID,
					'PASSWORD' => $PASSWORD,
   					'USER_STATUS_ID' => '1',
   					'EXT_REF_NBR' => $ExtRefid,
					//'LAST_LOGIN_AT' => $UserLastLoginAt,
					'ACTIVATION' => $Activation,
					'DMN_ID' => $UserDmnid,
					'IS_DELETED' => '0',
					'CREATED_BY' =>  $this->session->userdata('user_id'),
					'UPDATED_BY' => $this->session->userdata('user_id'),
					'CREATED_ON' => date('Y-m-d H:i:s'),
					'UPDATED_ON' => date('Y-m-d H:i:s')
					
					);
		$this->db->insert('user_mst', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($id, $UserName, $REG_EMAIL_ID, $PASSWORD, $UserStatus, $Personid, $ExtRefid, $UserDmnid, $UserLastLoginAt) 
	{
		$data = array(
   					'USER_NAME' =>$UserName,
   					'REG_EMAIL_ID' => $REG_EMAIL_ID,
					'PASSWORD' => $PASSWORD,
   					'USER_STATUS_ID' => $UserStatus,
					'Person_ID' => $Personid,
   					'EXT_REF_NBR' => $ExtRefid,
					'LAST_LOGIN_AT' => $UserLastLoginAt,
					'DMN_ID' => $UserDmnid,
					'UPDATED_BY' => $this->session->userdata('user_id'),
					'UPDATED_ON' => date('Y-m-d H:i:s',now())
					);
		$this->db->where('USER_ID', $id);
		$this->db->update('user_mst', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($id) {
		$data = array(
   					'IS_DELETED' =>'1',
					);
		$this->db->where('USER_ID', $id);
		$this->db->update('user_mst', $data);		
	}
/* End of Delete Data */


/*  Start of business rules */
	function validateloginCredentials($username , $password){
		
		$this->db->where('USER_NAME', $username);
		$this->db->where('PASSWORD', $password);
		//$this->db->where('activation', NULL);
		return $query = $this->db->get('user_mst');
		/*if($query->num_rows() > 0)
		{
			return $query;
		}else
		{
			return false;
		}*/
			
		
	}
	
	
	function checkifusernameexists($username){
		
		$this->db->where('USER_NAME', $username);
		$query = $this->db->get('user_mst');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
	}
	
	function checkifemailexists($emailid){
		
		$this->db->where('REG_EMAIL_ID', $emailid);
		$query = $this->db->get('user_mst');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
	}

	function checkiforgcodeexists($orgcode){
		
		$this->db->where('OA_CD', $orgcode);
		$query = $this->db->get('org_accounts');
		if($query->num_rows() > 0)
		{
			return true;
		}else{
			return false;
		}
	}

	
	function getOaID()
		{
		
		$this->db->where('DMN_ID', $this->session->userdata('user_domain_id'));
		return $query = $this->db->get('user_domain');
		}
	
	function updateLogoutTime(){
		$data = array(
					'LAST_LOGIN_AT' => date('Y-m-d H:i:s'),
					);
		$this->db->where('USER_ID',$this->session->userdata('user_id'));
		$this->db->update('user_mst', $data); 
	}
	function getAllUsersDrop() {
		return $this->db->query('SELECT a.*
								 FROM user_mst a
								 WHERE a.IS_DELETED = 0')->result();		
	}

	function getuserdetailsfromemail($emailid){
	$this->db->where('REG_EMAIL_ID', $emailid);
		return $this->db->get('user_mst')->row();	
	
	}

	function update_password($username,$password){
	$data = array(
					'PASSWORD' => $password
				 );
		$this->db->where('USER_NAME', $username);
		$this->db->update('user_mst', $data); 	
		return $this->db->affected_rows();
	}

	function acc($email,$activation){
	
		$data = array(
						'ACTIVATION' => NULL
					 );
		$this->db->where('REG_EMAIL_ID', $email);
		$this->db->where('ACTIVATION', $activation);
		$this->db->update('user_mst', $data); 	
		return $this->db->affected_rows();
	}
/*  End of business rules */	
	
	
}