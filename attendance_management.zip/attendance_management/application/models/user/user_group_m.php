<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Group_m extends CI_Model {

/* Start of retrieving individual column values*/
	function getUserGrpNm($id) {
		$this->db->where('USER_GRP_ID', $id);
		return $this->db->get('user_group')->first_row()->USER_GRP_NM;			
	}
				
	function getUserDmnid($id) {
		$this->db->where('USER_GRP_ID', $id);
		return $this->db->get('user_group')->first_row()->DMN_ID;			
	}
	
	function getIsDeleted($id) {
		$this->db->where('USER_GRP_ID', $id);
		return $this->db->get('user_group')->first_row()->IS_DELETED;			
	}	
/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUserGroup() {
		//$this->db->where('IS_DELETED', '0');
		//return $this->db->get('user_group')->result();
		return $this->db->query('SELECT a.*, b.DMN_NM,g.USER_NAME AS Created_by_Name,h.USER_NAME AS Updated_by_Name
								 FROM user_group a
								 LEFT JOIN user_domain b ON a.DMN_ID = b.DMN_ID
								 LEFT JOIN user_mst g ON a.CREATED_BY = g.USER_ID
								 LEFT JOIN user_mst h ON a.UPDATED_BY = h.USER_ID
								 WHERE a.IS_DELETED = 0')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($userGrpNm, $UserGrpDmnid, $users) {
		$data = array(
   					'USER_GRP_NM' =>$userGrpNm,
   					'DMN_ID' => $UserGrpDmnid,
					'CREATED_BY' =>$this->session->userdata('user_id'),
					'CREATED_ON' => date('Y-m-d H:i:s')
					);
		$this->db->insert('user_group', $data); 
		$query = $this->db->insert_id();

		
		foreach($users as $user_id)
		{
		$data = array(
   					'USER_GRP_ID' =>$query,
					'USER_ID' => $user_id,
					'CREATED_BY' =>$this->session->userdata('user_id'),
					'CREATED_ON' => date('Y-m-d H:i:s')
					);
		$this->db->insert('user_group_dtl', $data); 
		}
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($id, $userGrpNm, $UserGrpDmnid) 
	{
		$data = array(
   					'USER_GRP_NM' =>$userGrpNm,
   					'DMN_ID' => $UserGrpDmnid,
					'UPDATED_BY' => $this->session->userdata('user_id'),
					'UPDATED_ON' => date('Y-m-d H:i:s')
					);
		$this->db->where('USER_GRP_ID', $id);
		$this->db->update('user_group', $data);
		
		
		
		
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($id) {
		$data = array(
   					'IS_DELETED' =>'1',
					);
		$this->db->where('USER_GRP_ID', $id);
		$this->db->update('user_group', $data);		
	}
/* End of Delete Data */
/*  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx---Validation Check for User Group ---xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/

	public function checkUserGrpRole($pvs_userGroup)
	{
		$this->db->where('USER_GRP_NM',$pvs_userGroup);
		$query=$this->db->get('user_group');
		if($query->num_rows() > 0)
		{
			return true; 
		}
		else
		{
			return false;   
		}
	}	


	public function getUserID($pvn_grpID)
	{
		$this->db->where('USER_GRP_ID',$pvn_grpID);
		$query=$this->db->get('user_group_dtl');
		return $query->result();
	}	

	public function insertUser($usergrpid,$user)
	{
		
		$data = array(
   					'USER_GRP_ID' =>$usergrpid,
					'USER_ID'=>$user
					);
		$this->db->insert('user_group_dtl', $data); 
		
	}	

	public function delete_grpdtl($usergrpid,$user)
	{
		$this->db->where('USER_GRP_ID', $usergrpid);
		$this->db->where('USER_ID', $user);
		$this->db->delete('user_group_dtl'); 
	}	








}

?>