<?php
/*---------------------------------------------------------------------------------------*/
/*   Author       : Aakash Mewada                                                */
/*   Date         : April 09, 2014                                                 */
/*   Synopsis     : Code for
					1)CRUD User Group Detail										*/
/*   Code Modifications:                                                             */
/*----------------------------------------------------------------------------------------*/
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_group_dtl_m extends CI_Model {
	
/* Start of retrieving individual column values*/ 
	function getUserGrpDtlID($id) {
		$this->db->where('USER_GRP_DTL_ID', $id);
		return $this->db->get('user_group_dtl')->first_row()->USER_GRP_DTL_ID;		
	}

	function getUserGrpID($id) {
		$this->db->where('USER_GRP_DTL_ID', $id);
		return $this->db->get('user_group_dtl')->first_row()->USER_GRP_ID;			
	}
	
	function getUserID($id) {
		$this->db->where('USER_GRP_DTL_ID', $id);
		return $this->db->get('user_group_dtl')->first_row()->USER_ID;		
	}
/* End of retrieving individual column values*/	

/* Start of retrieving all column values*/	
	function getAllUserGrpDtl() {
		return $this->db->query('SELECT a . * , b.USER_GRP_NM, C.USER_NAME
								FROM user_group_dtl a
								LEFT JOIN user_group b ON a.USER_GRP_ID = b.USER_GRP_ID
								LEFT JOIN user_mst c ON a.USER_ID = c.USER_ID')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert( $pvi_USER_GRP_ID, $pvi_USER_ID, $pvi_CREATED_BY, $pvd_CREATED_ON) {
		
		$data = array(
			'USER_GRP_ID' => $pvi_USER_GRP_ID,
			'USER_ID' => $pvi_USER_ID,
			'CREATED_BY' => $pvi_CREATED_BY,
			'CREATED_ON' => $pvd_CREATED_ON
		);
		$this->db->insert('user_group_dtl', $data); 		
	}
/* End of Insert Data */

/* Start of Update Data */
	function update($id, $pvi_USER_GRP_ID, $pvi_USER_ID, $pvi_UPDATED_BY, $pvd_UPDATED_ON) {
		
		$data = array(
			'USER_GRP_ID' => $pvi_USER_GRP_ID,
			'USER_ID' => $pvi_USER_ID,
			'UPDATED_BY' => $pvi_UPDATED_BY,
			'UPDATED_ON' => $pvd_UPDATED_ON
		);
		$this->db->where('USER_GRP_DTL_ID', $id);
		$this->db->update('user_group_dtl', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */
	function delete($id) {
		$this->db->where('USER_GRP_DTL_ID', $id);
		$this->db->delete('user_group_dtl'); 		
	}
/* End of Delete Data */	
}