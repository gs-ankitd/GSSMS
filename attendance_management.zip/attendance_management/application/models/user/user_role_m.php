<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Role_m extends CI_Model {

	/* Start of retrieving individual column values*/
	function getRoleId($id) {
		$this->db->where('USER_ROLE_ID', $id);
		return $this->db->get('user_role')->first_row()->ROLE_ID;		
	}

	function getUserId($id) {
		$this->db->where('USER_ROLE_ID', $id);
		return $this->db->get('user_role')->first_row()->USER_ID;			
	}

/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUserRoles() {
		//return $this->db->get('user_role')->result();
		return $this->db->query('SELECT a.*, c.USER_NAME AS Created_By_Name,d.USER_NAME AS Updated_By_Name,e.USER_NAME,f.ROLE_NM
								 FROM user_role a
								 LEFT JOIN user_mst e ON a.USER_ID = e.USER_ID
								 LEFT JOIN role_mst f ON a.ROLE_ID = f.ROLE_ID
								 LEFT JOIN user_mst c ON a.CREATED_BY = c.USER_ID
								 LEFT JOIN user_mst d ON a.UPDATED_BY = d.USER_ID')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($USER_ID, $roleId) {
		$data = array(
   					'ROLE_ID' =>$roleId,
   					'USER_ID' => $USER_ID,
					'CREATED_BY' =>$this->session->userdata('user_id'),
					'CREATED_ON' => date('Y-m-d H:i:s')
					);
		$this->db->insert('user_role', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($id, $USER_ID, $roleId) {
		$data = array(
   					'ROLE_ID' =>$roleId,
   					'USER_ID' => $USER_ID,
					'UPDATED_BY' => $this->session->userdata('user_id'),
					'UPDATED_ON' => date('Y-m-d H:i:s')
					);
		$this->db->where('USER_ROLE_ID', $id);
		$this->db->update('user_role', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($id) {
		$this->db->where('USER_ROLE_ID', $id);
		$this->db->delete('user_role'); 		
	}
/* End of Delete Data */
	
	
}
?>