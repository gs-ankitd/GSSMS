<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_domain_m extends CI_Model {

	/* Start of retrieving individual column values*/
	function getUserDmnID($gvn_userNm) {
		$this->db->where('DMN_NM', $gvn_userNm);
		return $this->db->get('user_domain')->first_row()->DMN_ID;		
	}

	function getUserDmnName($gvn_userDmnId) {
		$this->db->where('DMN_ID', $gvn_userDmnId);
		return $this->db->get('user_domain')->first_row()->DMN_NM;		
	}

	function getDescription($gvn_userDmnId) {
		$this->db->where('DMN_ID', $gvn_userDmnId);
		return $this->db->get('user_domain')->first_row()->DSCRPTN;			
	}
	
	function getOAId($gvn_userDmnId) {
		$this->db->where('DMN_ID', $gvn_userDmnId);
		return $this->db->get('user_domain')->first_row()->OA_ID;			
	}
	
	function getOABrandId($gvn_userDmnId) {
		$this->db->where('DMN_ID', $gvn_userDmnId);
		return $this->db->get('user_domain')->first_row()->OA_BRAND_ID;			
	}
	
	function getIsDeleted($gvn_userDmnId) {
		$this->db->where('DMN_ID', $gvn_userDmnId);
		return $this->db->get('user_domain')->first_row()->IS_DELETED;			
	}
	

	function getCreatedBy($gvn_roleId) {
		$this->db->where('DMN_ID', $gvn_roleId);
		return $this->db->get('user_domain')->first_row()->CREATED_BY;			
	}
	
	function getUpdatedBy($gvn_roleId) {
		$this->db->where('DMN_ID', $gvn_roleId);
		return $this->db->get('user_domain')->first_row()->UPDATED_BY;			
	}
	
	function getCreatedOn($gvn_roleId) {
		$this->db->where('DMN_ID', $gvn_roleId);
		return $this->db->get('user_domain')->first_row()->CREATED_ON;			
	}
	
	function getUpdatedOn($gvn_roleId) {
		$this->db->where('DMN_ID', $gvn_roleId);
		return $this->db->get('user_domain')->first_row()->UPDATED_ON;			
	}	
	
/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUserDomain() {
		//$this->db->where('Is_Deleted', '0');
		//return $this->db->get('user_domain')->result();
		return $this->db->query('SELECT a.*, b.OA_NM,c.OA_BRAND_NM,d.USER_NAME AS CREATED_BY_UNM,e.USER_NAME AS UPDATED_BY_UNM
								 FROM user_domain a
								 LEFT JOIN org_accounts b ON a.OA_ID = b.OA_ID
								 LEFT JOIN oa_brands c ON a.OA_BRAND_ID = c.OA_BRAND_ID
								 LEFT JOIN user_mst d ON a.CREATED_BY = d.USER_ID
								 LEFT JOIN user_mst e ON a.UPDATED_BY = e.USER_ID
								 WHERE a.IS_DELETED = 0')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($gvs_userDmnName, $gvs_dscrptn, $gvn_oaId, $gvn_oaBrandId) {
		$data = array(
   					'DMN_NM' =>$gvs_userDmnName,
   					'DSCRPTN' => $gvs_dscrptn,
					'OA_ID' => $gvn_oaId,
   					'OA_BRAND_ID' => $gvn_oaBrandId,
					'CREATED_ON'=>date('Y-m-d H:i:s'),
					'CREATED_BY'=>$this->session->userdata('user_id')
					);
		$this->db->insert('user_domain', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($gvn_userDmnId, $gvs_userDmnName, $gvs_dscrptn, $gvn_oaId, $gvn_oaBrandId) {
		$data = array(
   					'DMN_NM' =>$gvs_userDmnName,
   					'DSCRPTN' => $gvs_dscrptn,
					'OA_ID' => $gvn_oaId,
   					'OA_BRAND_ID' => $gvn_oaBrandId,
					'UPDATED_ON'=>date('Y-m-d H:i:s'),
					'UPDATED_BY'=>$this->session->userdata('user_id')
					);
		$this->db->where('DMN_ID', $gvn_userDmnId);
		$this->db->update('user_domain', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($gvn_userDmnId) {
		$data = array(
   					'IS_DELETED' =>'1',
					);
		$this->db->where('DMN_ID', $gvn_userDmnId);
		$this->db->update('user_domain', $data); 		
	}
/* End of Delete Data */
	
	
}