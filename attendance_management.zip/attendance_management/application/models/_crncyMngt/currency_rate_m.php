<?php
/*---------------------------------------------------------------------------------------*/
/*   Author       : Aakash Mewada                                                */
/*   Date         : Feb 20, 2014                                                 */
/*   Synopsis     : Code for
					1)CRUD Currency_rate										*/
/*   Code Modifications:                                                             */
/*----------------------------------------------------------------------------------------*/
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Currency_rate_m extends CI_Model {
	
/* Start of retrieving individual column values*/
	function getSrcCurrID($id) {
		$this->db->where('Curr_Rate_ID', $id);
		return $this->db->get('currency_rate')->first_row()->Src_Curr_ID;		
	}
	
	function getTrgCurrID($id) {
		$this->db->where('Curr_Rate_ID', $id);
		return $this->db->get('currency_rate')->first_row()->Trg_Curr_ID;			
	}
	
	
	function getExRate($id) {
		$this->db->where('Curr_Rate_ID', $id);
		return $this->db->get('currency_rate')->first_row()->Ex_Rate;	
	}
	
	function getEffFrom($id) {
		$this->db->where('Curr_Rate_ID', $id);
		return $this->db->get('currency_rate')->first_row()->Eff_From;	
	}
	
	function getEffTo($id) {
		$this->db->where('Curr_Rate_ID', $id);
		return $this->db->get('currency_rate')->first_row()->Eff_To;		
	}
/* End of retrieving individual column values*/	

/* Start of retrieving all column values*/	
	function getAllCurrencyRate() {
		return $this->db->get('currency_rate')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */	
	function insert($src_curr_id,$trg_curr_id,$ex_rate,$eff_from,$eff_to) {
		$data = array(
   					'Src_Curr_ID'=>$src_curr_id,
					'Trg_Curr_ID'=>$trg_curr_id,
					'Ex_Rate'=>$ex_rate,
					'Eff_From'=>$eff_from,
					'Eff_To'=>$eff_to
					
				);
		$this->db->insert('currency_rate', $data); 		
	}
/* End of Insert Data */

/* Start of Update Data */
	function update($curr_rate_id,$src_curr_id,$trg_curr_id,$ex_rate,$eff_from,$eff_to) {
		$data = array(
					'Curr_Rate_ID'=>$curr_rate_id,
   					'Src_Curr_ID'=>$src_curr_id,
					'Trg_Curr_ID'=>$trg_curr_id,
					'Ex_Rate'=>$ex_rate,
					'Eff_From'=>$eff_from,
					'Eff_To'=>$eff_to
					
				);
		$this->db->where('Curr_Rate_ID', $curr_rate_id);
		$this->db->update('currency_rate', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */
	function delete($id) {
		$this->db->where('Curr_Rate_ID', $id);
		$this->db->delete('currency_rate'); 		
	}
/* End of Delete Data */	
}