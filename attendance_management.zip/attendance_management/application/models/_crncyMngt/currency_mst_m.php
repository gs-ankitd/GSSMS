<?php
/*---------------------------------------------------------------------------------------*/
/*   Author       : Aakash Mewada                                                */
/*   Date         : Feb 20, 2014                                                 */
/*   Synopsis     : Code for
					1)CRUD Currency_master										*/
/*   Code Modifications:                                                             */
/*----------------------------------------------------------------------------------------*/
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Currency_mst_m extends CI_Model {
	
/* Start of retrieving individual column values*/
	function getCurrCode($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->Curr_Code;		
	}
	
	function getCurrName($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->Curr_Name;			
	}
	
	function getCurrSymbol($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->Curr_Symbol;		
	}
	
	function getOaId($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->OA_ID;			
	}
	
	function getCountryID($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->Country_ID;		
	}
	
	function getRefID($id) {
		$this->db->where('Curr_ID', $id);
		return $this->db->get('currency_mst')->first_row()->Ref_ID;			
	}
/* End of retrieving individual column values*/	

/* Start of retrieving all column values*/	
	function getAllCurrency() {
		return $this->db->get('currency_mst')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($curr_code,$curr_name,$curr_symbol,$oa_id,$country_id,$ref_id,$created_by,$created_on) {
		$data = array(
   					'Curr_Code' =>$curr_code,
   					'Curr_Name' =>$curr_name,
					'Curr_Symbol'=>$curr_symbol,
					'OA_ID'=>$oa_id,
					'Country_ID'=>$country_id,
					'Ref_ID'=>$ref_id,
					'Created_On'=>$created_on,
					'Created_by'=>$created_by
				);
		$this->db->insert('currency_mst', $data); 		
	}
/* End of Insert Data */
	
	function refIdExist($id)
	{
		$this->db->where('Ref_ID', $id);
		$query = $this->db->get('currency_mst');
		if ($query->num_rows() == 1){
			return true;
		}
		else{
			return false;
		}
	}
	
/* Start of Update Data */
	function update($curr_id,$curr_code,$curr_name,$curr_symbol,$oa_id,$country_id,$ref_id,$updated_by,$updated_on) {
		$data = array(
					'Curr_ID'=>$curr_id,
   					'Curr_Code' =>$curr_code,
   					'Curr_Name' =>$curr_name,
					'Curr_Symbol'=>$curr_symbol,
					'OA_ID'=>$oa_id,
					'Country_ID'=>$country_id,
					'Ref_ID'=>$ref_id,
					'Updated_on'=>$updated_on,
					'Updated_by'=>$updated_by
				);
		$this->db->where('Curr_ID', $curr_id);
		$this->db->update('currency_mst', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */
	function delete($id) {
		$this->db->where('Curr_ID', $id);
		$this->db->delete('currency_mst'); 		
	}
/* End of Delete Data */	
}