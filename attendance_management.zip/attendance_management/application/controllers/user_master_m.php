<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_master_m extends CI_Model {

	/* Start of retrieving individual column values*/
	function getUserName($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->User_Name;		
	}

	function getReg_email($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->Reg_email;			
	}
	
	function getPassword($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->Password;			
	}
	
	function getUserStatus($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->User_Status;			
	}
	
	function getPersonid($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->Person_ID;			
	}
	
	function getExtRefid($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->Ext_Ref_ID;			
	}
	function getUserLastLoginAt($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->Last_Login_AT;			
	}
	
	function getUserDmnid($id) {
		$this->db->where('User_ID', $id);
		return $this->db->get('user_mst')->first_row()->USER_DMN_ID;			
	}
	
	
/* End of retrieving individual column values*/

/* Start of retrieving all column values*/
	function getAllUsers() {
		return $this->db->get('user_mst')->result();		
	}
/* End of retrieving all column values*/

/* Start of Insert Data */
	function insert($UserName, $Reg_email, $Password, $UserStatus , $Personid, $ExtRefid,  $UserDmnid, $UserLastLoginAt) 
	{
		$data = array(
   					'User_Name' =>$UserName,
   					'Reg_email' => $Reg_email,
					'Password' => $Password,
   					'User_Status' => '1',
					'Person_ID' => $Personid,
   					'Ext_Ref_ID' => $ExtRefid,
					'Last_Login_AT' => $UserLastLoginAt,
					'USER_DMN_ID' => $UserDmnid,
					'Created_By' =>  $this->session->userdata('username'),
					'Updated_By' => $this->session->userdata('username'),
					'Created_On' => date('Y-m-d H:i:s',now()),
					'Updated_On' => date('Y-m-d H:i:s',now())
					
					);
		$this->db->insert('user_mst', $data); 		
	}
	
/* End of Insert Data */

/* Start of Update Data */

	function update($id, $UserName, $Reg_email, $Password, $UserStatus, $Personid, $ExtRefid, $UserDmnid, $UserLastLoginAt) 
	{
		$data = array(
   					'User_Name' =>$UserName,
   					'Reg_email' => $Reg_email,
					'Password' => $Password,
   					'User_Status' => $UserStatus,
					'Person_ID' => $Personid,
   					'Ext_Ref_ID' => $ExtRefid,
					'Last_Login_AT' => $UserLastLoginAt,
					'USER_DMN_ID' => $UserDmnid,
					'Updated_By' => $this->session->userdata('username'),
					'Updated_On' => date('Y-m-d H:i:s',now())
					);
		$this->db->where('User_ID', $id);
		$this->db->update('user_mst', $data); 	
	}
/* End of Update Data */

/* Start of Delete Data */

	function delete($id) {
		$this->db->where('User_ID', $id);
		$this->db->delete('user_mst'); 		
	}
/* End of Delete Data */


/*  Start of business rules */
	function validateloginCredentials($username , $password){
		
		$this->db->where('User_Name', $username);
		$this->db->where('Password', $password);
		//$this->db->where('activation', NULL);
		$query = $this->db->get('user_mst');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
			
		
	}
	
	
	function checkifusernameexists($username){
		
		$this->db->where('User_Name', $username);
		$query = $this->db->get('user_mst');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
	}
	
	function checkifemailexists($emailid){
		
		$this->db->where('Reg_email', $emailid);
		$query = $this->db->get('user_mst');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
	}

	function checkiforgcodeexists($orgcode){
		
		$this->db->where('OA_CD', $orgcode);
		$query = $this->db->get('org_accounts');
		if($query->num_rows() > 0)
		{
			return true;
		}else
		{
			return false;
		}
	}

/*  End of business rules */	
	
	
}