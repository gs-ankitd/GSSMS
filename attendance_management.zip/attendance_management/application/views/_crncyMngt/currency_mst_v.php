<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('crncyMngt/currency_mst');?>">Currency</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
        
			<fieldset>
				
                  <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('crncyMngt/currency_mst/newCurrency/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr><?php foreach($currency as $curr): ?>
						
                        	<th><?php echo $curr->Obj_Attrbt_Dsply_Nm; ?></th>
                            
                            
                        
                            <?php endforeach; ?>	
                        	<!--<th>Code</th>
                        	<th>Name</th>
							<th>Symbol</th>
							<th>Organisation Code</th>-->
				
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                 
                    	<?php foreach($c as $list): ?>
						<tr>
                           <?php foreach($currency as $curr): ?>
                        <?php if($curr->Obj_Attrbt_Dsply_Nm == 'Curr_Code'){ ?>
                        	<td class="center"><?php echo $list->Curr_Code; ?></td>
                            <?php  } ?>
                             <?php if($curr->Obj_Attrbt_Dsply_Nm == 'Curr_Name'){ ?>
                        	<td class="center"><?php echo $list->Curr_Name; ?></td>
                            <?php  } ?>
                            
                             <?php if($curr->Obj_Attrbt_Dsply_Nm == 'Curr_Symbol'){ ?>
                        	<td class="center"><?php echo $list->Curr_Symbol; ?></td>
                            <?php  } ?>
                            
                           <?php endforeach; ?> 
                            
                      	</tr>	
                        
                            <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->