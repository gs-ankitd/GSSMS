<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group_dtl');?>">User Group Detail</a> 
		</li>
	</ul>
</div>  
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>User Group Detail Details</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">   
        
			<fieldset>
            	<div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/user_group_dtl/addUserGrpDtl/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                 <br><br>

				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
<tr>
							<th>User Group Detail ID</th>
                            <th>User Group Name</th>
                            <th>USER Name</th>
<?php /*
//var_dump($visi);
if(validateColVisibility('USER_GRP_DTL_ID',$visi))
{
?>
<th>User Group Detail ID</th>
<?php
}
?>

<?php
if (validateColVisibility('USER_GRP_ID',$visi)) {
?>
<th>>User Group Name</th>
<?php
}
?>

<?php
if (validateColVisibility('USER_ID',$visi)) {
?>
<th>USER Name</th>
<?php
}
*/?>
<th>Actions</th>
</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>

<?php foreach($lva_UserGrpDtl as $list) :?>
<tr>
							<td><?php echo $list->USER_GRP_DTL_ID;?></td>
                        	<td><?php echo $list->USER_GRP_NM;?></td>
                            <td><?php echo $list->USER_NAME;?></td>
<?php /*
if(validateColVisibility('USER_GRP_DTL_ID',$visi))
{
?>
	<td class="center"><?php echo $list->USER_GRP_DTL_ID; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('USER_GRP_ID',$visi))
{
?>
	<td class="center"><?php echo $list->USER_GRP_ID; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('USER_ID',$visi))
{
?>
	<td class="center"><?php echo $list->USER_ID; ?></td>
<?php
}
*/?>
                            <td class="center ">
								<a href="<?php echo site_url('user/user_group_dtl/editUserGrpDtl/'.$list->USER_GRP_DTL_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span>                                             
								</a>
								<a href="<?php echo site_url('user/user_group_dtl/delete/'.$list->USER_GRP_DTL_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span> 
								</a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->