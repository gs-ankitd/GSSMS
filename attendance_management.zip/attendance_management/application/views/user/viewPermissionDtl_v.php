<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/permission_dtl/');?>">Permission Detail</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <div class="control-group <?php if(form_error('PermissionsRefTypeId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Permissions RefTypeId</label>
								<div class="controls">
                                <select name="PermissionsRefTypeId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php
									  foreach($PermissionsRefTypeIdDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->MSTR_ID==$PermissionsRefTypeId)
									   {//start of ($list->TypeID==$HierTypeId)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									   }//end of ($list->MasterID==$HierTypeId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('PermissionsRefTypeId'); ?>
									</span>
								</div>
							  </div>

                   
                   <div class="control-group <?php if(form_error('PermissionsRefId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Permissions Ref Id</label>
								<div class="controls">
							
							<select name="PermissionsRefId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($PermissionsRefIdDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->TYP_ID==$PermissionsRefId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->TYP_ID;?>" selected="selected"><?php echo $list->TYP_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
								 ?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('PermissionsRefId'); ?>
									</span>
								</div>
							  </div>
   
                   
                    <div class="control-group <?php if(form_error('PermissionsId')) echo 'error';?>">
						<label class="control-label">Permissions Id</label>
						<div class="controls">
							<select name="PermissionsId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($PermissionsIdDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->MSTR_ID==$PermissionsId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
								 ?>
                                </select>
							<span class="help-inline">
								<?php echo form_error('PermissionsId'); ?>
                               
							</span>
						</div>
					</div>
                    
            
   <?php if(form_error('msg[]')) echo "<a style='color:red;'>Kindly Select a Object Attribute Previlege</a>" ?>                            
                              
<table class="table table-striped table-bordered bootstrap-datatable datatable" >
              
                	<!-- Start of table head -->
					<thead>
						<tr>
							<th>Action</th>

                            <th>Object</th>

                        	<th>Object Attribute</th>

							<th>Organisation Account</th>

                            <th>Org Account Brand</th>

                        	<th>User</th>
                       
                           
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
        <tbody>
            <?php foreach($obj_attrbt_previleges_list  as $list) :?>
            <tr>

        		<td class="center"><input type="checkbox" <?php if($list->OBJ_ATTRBT_PREVILEGES_ID == $ObjAttrbtPrevilegesId) echo 'checked="checked"'?>  value="<?php echo $list->OBJ_ATTRBT_PREVILEGES_ID ; ?>" name="msg[]"  /></td>
 
                <td class="center"><?php echo $list->OBJ_NM; ?></td>
   
                <td class="center"><?php echo $list->OBJ_ATTRBT_NM;?></td>
               
                <td class="center"><?php echo $list->OA_NM; ?></td>
   
                <td class="center"><?php echo $list->OA_BRAND_NM; ?></td>
 
                <td class="center"><?php echo $list->USER_NAME; ?></td>
    


               
            </tr>	
            <?php endforeach; ?>						
        </tbody>
                    <!-- End of table body -->
				</table>   
                              
                              
                              
                              
                              
                              
                              
                              
<!-- end of form controls -->
                    
                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('user/permission_dtl');?>"> 
						<button type="button" class="btn">Cancel</button>
                        </a> 
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>