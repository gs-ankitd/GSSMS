<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       : Ankit Dedhia                                                */
/*   Date         : Oct 2013                                                 */
/*   Synopsis     : Code for
					1)Profile Page View											*/
/*   Code Modifications:                                                             */
/*----------------------------------------------------------------------------------------*/



?>
		
<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Profile</a>
					</li>
				</ul>
			</div>
 <!-- breadcrumb ends -->            
	
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->	
			
 <?php if(isset($editmsg)) echo $editmsg; ?>    
					  <div class="row-fluid sortable">
				<div class="box span12" style="margin-left:1px;">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i> Edit Profile</h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                   
                   
						<form class="form-horizontal" action="<?php if(isset($action)) echo $action;?>" method="post" name="form1">
							<fieldset>

                              <div class="control-group <?php if(form_error('username'))  echo 'error'; ?>">
	<label class="control-label" for="focusedInput">Username<span style="color:red;">*</span> </label>
								<div class="controls">
								   <input type="text" name="username" id="username" value="<?php if(isset($username)) echo $username; else echo set_value('username');?>" readonly  >
                                    <span class="help-inline">
                                          <?php echo form_error('username'); ?>
          							</span>									
								</div>
							  </div>
                              

                              
     
                              <div class="control-group <?php if(form_error('oldPassword'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Old Password </label>
								<div class="controls">
								  <input type="password" name="oldPassword" id="oldPassword" value="" >         
           						 <span class="help-inline">
                                          <?php echo form_error('oldPassword'); ?>
          							</span>	
								</div>
							  </div>
                             
                               <div class="control-group <?php if(form_error('newPassword'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">New Password </label>
								<div class="controls">
								 <input type="password" name="newPassword" id="newPassword" value="" >         
        							<span class="help-inline">
                                          <?php echo form_error('newPassword'); ?>
          							</span>	
								</div>
							  </div>
                              
                              
                               <div class="control-group <?php if(form_error('confirmPassword'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Confirm Password </label>
								<div class="controls">
								 <input type="password" name="confirmPassword" id="confirmPassword" value="" >         
        							<span class="help-inline">
                                          <?php echo form_error('confirmPassword'); ?>
          							</span>	
								</div>
							  </div>
	

     
     
      <div class="control-group <?php if(form_error('email'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Email Address<span style="color:red;">*</span> </label>
								<div class="controls">
								 <input type="text" name="email" id="email" value="<?php if(isset($email)) echo $email; else echo set_value('email');?>">
        							<span class="help-inline">
                                          <?php echo form_error('email'); ?>
          							</span>			
								</div>
							  </div>
                              
                              
							  <div class="form-actions">
								<button type="submit" class="btn btn-primary">Save changes</button>
								<?php echo anchor('dashboard/dashboard','Cancel',array('class'=>'btn')); ?>
							  </div>
							</fieldset>
						  </form>
					
					</div><!--class="box-content"-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
       
    
</div><!--/fluid-row-->
				
	
		
	</div>

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>


		
	</div><!--/.fluid-container-->

		
</body>
</html>
