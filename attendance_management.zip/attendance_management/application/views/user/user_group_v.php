<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group');?>">User Group</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> User Group</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
              
			<fieldset>
                   
                    <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/user_group/newUserGroup'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<?php
                            if(validateColVisibility('USER_GRP_ID',$visi))
                            {
                            ?>
                        	<th>User Group ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                        	<th>User Group Name</th>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('User_ID',$visi))
                            {
                            ?>
							<th>User ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('Ext_Ref_ID',$visi))
                            {
                            ?>
							<th>Ext Ref ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('DMN_ID',$visi))
                            {
                            ?>
                            <th>User Domain ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <th>Deleted</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                           <th>Created By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                           <th>Updated By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                            <th>Created On</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                            <th>Updated On</th>
                            <?php
							}
							?>
                            <th>Actions</th>
                           
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($UserGroups as $usergroup) :?>
						<tr>
                        	<?php
                            if(validateColVisibility('USER_GRP_ID',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $usergroup->USER_GRP_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $usergroup->USER_GRP_NM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('User_ID',$visi))
                            {
                            ?>
							<td class="center"><?php echo $usergroup->User_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('Ext_Ref_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $usergroup->Ext_Ref_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('DMN_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $usergroup->DMN_NM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <td class="center"><?php if($usergroup->IS_DELETED) echo "Yes"; else echo "No"; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                           <td class="center"><?php echo $usergroup->Created_by_Name; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                           <td class="center"><?php echo $usergroup->Updated_by_Name; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $usergroup->CREATED_ON; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $usergroup->UPDATED_ON; ?></td>
                            <?php
							}
							?>
                            
                            <td class="center ">
                                 <a href="<?php echo site_url('user/user_group/editUserGroup/'.$usergroup->USER_GRP_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('user/user_group/delete/'.$usergroup->USER_GRP_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->