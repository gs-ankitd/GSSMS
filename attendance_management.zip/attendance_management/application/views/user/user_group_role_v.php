<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group_role');?>">User Group Roles</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> User Group Roles</h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/user_group_role'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
          
			<fieldset>
                    <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/user_group_role/newGrpRole'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                       		<?php
                            if(validateColVisibility('GRP_ROLE_ID',$visi))
                            {
                            ?>
                        	<th>Group Role ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('ROLE_ID',$visi))
                            {
                            ?>
                        	<th>Role ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_ID',$visi))
                            {
                            ?>
							<th>User Group ID</th>
                           	<?php
							}
							?>
                             <?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                           <th>Created By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                          <th>Updated By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                            <th>Created On</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                            <th>Updated On</th>
                            <?php
							}
							?>
                            <th>Actions</th>
                           
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($user as $list) :?>
						<tr>
                        	<?php
                            if(validateColVisibility('GRP_ROLE_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->GRP_ROLE_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('ROLE_ID',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $list->ROLE_NM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_ID',$visi))
                            {
                            ?>
							<td class="center"><?php echo $list->USER_GRP_NM; ?></td>
                             <?php
							}
							?>
							<?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->Created_by_Name; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_GRP_NM',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->Updated_by_Name; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                           <td class="center"><?php echo $list->CREATED_ON; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                           <td class="center"><?php echo $list->UPDATED_ON; ?></td>
                            <?php
							}
							?>
                            
                           
                            <td class="center ">

                                <a href="<?php echo site_url('user/user_group_role/editGrpRole/'.$list->GRP_ROLE_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('user/user_group_role/delete/'.$list->GRP_ROLE_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->