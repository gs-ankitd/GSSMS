<script>
	function orgAccFunc(OAId){
		//alert(typeId);
		if(OAId){//if there is a typeId pressed and has a value
		
		$.ajax({
			url:"<?php echo site_url('user/user_domain/ajaxOrgLive/').'/';?>"+OAId, //here we are calling our user controller 
 			success: function(typeDropdown) //we're calling the response json array 'activities'
 			{
				 $("#OaBrandID > option").remove(); //first of all clear select items
				
 				$.each(typeDropdown,function(type_id,type_name) //here we're doing a foeach loop round each activity with id as the key and activity as the value
 				{
 					 opt = $('<option />'); // here we're creating a new select option with for each activity
 					opt.val(type_id);
					opt.text(type_name);
 					$('#OaBrandID').append(opt); //here we will append these new <span class="adtext" id="adtext_1">select options</span> to a dropdown 
 				});
 			}
 
 				});		
		}//if ends
	}
</script>

<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_domain');?>">User Domain Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    <!-- start of div -User DMN ID-->
                  <!--	<div class="control-group <?php// if(form_error('UserDmnID')) echo 'error';?>">
                      <label class="control-label">User Domain ID</label>
                      <div class="controls">
                                         <input class="input-xlarge" id="UserDmnID" name="UserDmnID" type="text" value="<?php// echo set_value('UserDmnID', $UserDmnID); ?>">
							<span class="help-inline">
								<?php //echo form_error('UserDmnID'); ?>
							</span>
                        </div>
                      </div>-->
                    <!-- end of div -User DMN ID-->
                    <!-- Start Of Form Controls   -->
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('UserDmnName')) echo 'error';?>">
						<label class="control-label">User Domain Name</label>
						<div class="controls">
							<input class="input-xlarge" id="UserDmnName" name="UserDmnName" type="text" value="<?php echo set_value('UserDmnName', $UserDmnName); ?>">
							<span class="help-inline">
								<?php echo form_error('UserDmnName'); ?>
							</span>
                           </div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Dscrptn')) echo 'error';?>">
						<label class="control-label">Description</label>
						<div class="controls">
							<input class="input-xlarge" id="Dscrptn" name="Dscrptn" type="text" value="<?php echo set_value('Dscrptn', $Dscrptn); ?>">
							<span class="help-inline">
								<?php echo form_error('Dscrptn'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->

					 <!-- start of div -OA ID-->
                  <div class="control-group <?php if(form_error('OaId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Oa Id</label>
								<div class="controls">
                                <select name="OaId" data-rel="chosen" onchange="orgAccFunc(this.value)">
                                <option value="">Select an option</option>
                                <?php
									  foreach($organisationDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_ID==$OaId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_ID;?>" selected="selected"><?php echo $list->OA_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_ID;?>" ><?php echo $list->OA_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('OaId'); ?>
									</span>
								</div>
					</div>
                    
                       <!--end Of div OA ID -->

					 <!-- start of div -OA brands ID-->

                    
                     <div class="control-group <?php if(form_error('OaBrandID')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Oa Brand ID</label>
								<div class="controls">
                                <?php 
							if($actionMode == 1){ ?>
							
							<select name="OaBrandID" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
						 foreach($orgBrandsDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_BRAND_ID==$OaBrandID)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_BRAND_ID;?>" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
							}else{
								
								
								?>
                                <select name="OaBrandID"  id="OaBrandID"  >
                               <option value="">Select an option</option>
								 
     							
                                
                                <?php } ?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('OaBrandID'); ?>
									</span>
								</div>
							  </div>
                    <!-- end of div -User DMN ID-->
                    
                   <!-- start of div - Is Deleted -->
                   <div class="control-group ">
                   <label class="control-label">Is Deleted</label>
                   <div class="controls">
                    <?php  if(($IsDeleted)==1){ ?>
                 <input type="checkbox" name="IsDeleted" id="IsDeleted"   checked="checked">
                        <?php }else {?>
                          <input type="checkbox" name="IsDeleted" id="IsDeleted"  ><?php } ?>
                                     <span class="help-inline">
                                                  <?php //echo form_error('inactive'); ?>
                             </span>  
                   </div>
                   </div>

                    <!-- end of div - Is Deleted -->
                    
                    <!-- start of hidden inputs -->
                    
                    <!-- end of hidden inputs -->
                    <!-- end Of Form Controls   -->
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('user/user_domain');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>