<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/permission_dtl');?>">Permission Detail</a> 
    		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Permission Detail</h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/permission_dtl'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
         <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/permission_dtl/newPermissionDtl');?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  <br><br>
                
			<fieldset>
				
               
				<table class="table table-striped table-bordered bootstrap-datatable datatable" >
              
                	<!-- Start of table head -->
					<thead>
						<tr>
                          <?php if (validateColVisibility('PERMISSIONS_REF_TYPE_ID',$visibleCol)) {?>
                        	<th>Permission Ref Type Id</th>
                             <?php } ?>  
                          <?php if (validateColVisibility('PERMISSIONS_REF_ID',$visibleCol)) {?>
                            <th>Permission Ref Id</th>
                             <?php } ?>  
                          <?php if (validateColVisibility('PERMISSIONS_ID',$visibleCol)) {?>
                        	<th>Permissions Id</th>
                             <?php } ?>  
                          <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>
                            <th>Object </th>
                             <?php } ?> 
                          <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>
                            <th>Object Attribute</th>
                             <?php } ?> 
                          <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>
                            <th>Org Account </th>
                             <?php } ?> 
                          <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>
                            <th>Org Account Brand</th>
                             <?php } ?>  
                          <?php if (validateColVisibility('CREATED_BY',$visibleCol)) {?>
                          <th>Created By</th>
                           <?php } ?>  
                          <?php if (validateColVisibility('UPDATED_BY',$visibleCol)) {?>
                          <th>Updated By</th>
                           <?php } ?>  
                          <?php if (validateColVisibility('CREATED_ON',$visibleCol)) {?>
                          <th>Created_On</th>
                           <?php } ?>  
                          <?php if (validateColVisibility('UPDATED_ON',$visibleCol)) {?>
                          <th>Updated_On</th>
                          <?php } ?> 
                            <th>Action</th>
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
        <tbody>
            <?php foreach($permission  as $permissions) :?>
            <tr>
            <?php if (validateColVisibility('PERMISSIONS_REF_TYPE_ID',$visibleCol)) {?>
                <td class="center"><?php echo $permissions->REF_TYPE ; ?></td>
            <?php } ?>  
            <?php if (validateColVisibility('PERMISSIONS_REF_ID',$visibleCol)) {?>  
                <td class="center"><?php echo $permissions->REF_ID; ?></td>
            <?php } ?>  
            <?php if (validateColVisibility('PERMISSIONS_ID',$visibleCol)) {?>    
                <td class="center"><?php echo $permissions->PER_ID;?></td>
		 	<?php } ?>  
            <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>    
                <td class="center"><?php echo $permissions->OBJ_NM; ?></td>
       	 	<?php } ?>
            <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>    
                <td class="center"><?php echo $permissions->OBJ_ATTRBT_NM; ?></td>
       	 	<?php } ?>
            <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>    
                <td class="center"><?php echo $permissions->OA_NM; ?></td>
       	 	<?php } ?>
            <?php if (validateColVisibility('OBJ_ATTRBT_PREVILEGES_ID',$visibleCol)) {?>    
                <td class="center"><?php echo $permissions->OA_BRAND_NM; ?></td>
       	 	<?php } ?>  
            <?php if (validateColVisibility('CREATED_BY',$visibleCol)) {?>
            <td class="center"><?php echo $permissions->Created_by_Name; ?></td>
             <?php } ?>  
            <?php if (validateColVisibility('UPDATED_BY',$visibleCol)) {?>
            <td class="center"><?php echo $permissions->Updated_by_Name; ?></td>
             <?php } ?>  
            <?php if (validateColVisibility('CREATED_ON',$visibleCol)) {?>
            <td class="center"><?php echo $permissions->CREATED_ON; ?></td>
             <?php } ?>  
            <?php if (validateColVisibility('UPDATED_ON',$visibleCol)) {?> 
            <td class="center"><?php echo $permissions->UPDATED_ON; ?></td>      
			<?php } ?>

                <td class="center ">
                    
                     <a href="<?php echo site_url('user/permission_dtl/editPermissionDtl/'.$permissions->PERMISSIONS_DTL_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('user/permission_dtl/delete/'.$permissions->PERMISSIONS_DTL_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
                </td>
            </tr>	
            <?php endforeach; ?>						
        </tbody>
                    <!-- End of table body -->
				</table> 
                

                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->