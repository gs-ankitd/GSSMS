<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_master');?>">User Master Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!--End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			 <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			 <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			 <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    
                    <!-- Start Of Form Controls   -->
                   
                    <!-- start of div - UserName -->
                    <div class="control-group <?php if(form_error('UserName')) echo 'error';?>">
						<label class="control-label">User Name</label>
						<div class="controls">
							<input class="input-xlarge" id="UserName" name="UserName" type="text" value="<?php echo set_value('UserName', $UserName); ?>">
							<span class="help-inline">
								<?php echo form_error('UserName'); ?>
							</span>
                            </div>
					</div>
                    <!-- end of div - UserName -->
                    
                    <!-- start of div - Email ID -->
                    <div class="control-group <?php if(form_error('RegEmail')) echo 'error';?>">
						<label class="control-label">Registered Email</label>
						<div class="controls">
							<input class="input-xlarge" id="RegEmail" name="RegEmail" type="text" value="<?php echo set_value('RegEmail', $RegEmail); ?>">
							<span class="help-inline">
								<?php echo form_error('RegEmail'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div -Email ID -->
                    
                    <!-- start of div - Password-->
                    <div class="control-group <?php if(form_error('Password')) echo 'error';?>">
						<label class="control-label">Password</label>
						<div class="controls">
							<input class="input-xlarge" id="Password" name="Password" type="text" value="<?php echo set_value('Password', $Password); ?>">
							<span class="help-inline">
								<?php echo form_error('Password'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div - Password -->
                    
                    <!-- start of div - UserStatus -->
                   <div class="control-group ">
                   <label class="control-label">User Status</label>
                   <div class="controls">
                    <?php  if(($UserStatus)==1){ ?>
                 <input type="checkbox" name="UserStatus" id="UserStatus"   checked="checked">
                        <?php }else {?>
                          <input type="checkbox" name="UserStatus" id="UserStatus"  ><?php } ?>
                                     <span class="help-inline">
                                                  <?php //echo form_error('inactive'); ?>
                             </span>  
                   </div>
                   </div>

                    <!-- end of div - User Status -->
                    
                    <!-- start of div - Person ID -->
                    <div class="control-group <?php if(form_error('PersonID')) echo 'error';?>">
						<label class="control-label">Person ID</label>
						<div class="controls">
							<input class="input-xlarge" id="PersonID" name="PersonID" type="text" value="<?php echo set_value('PersonID'); ?>">
							<span class="help-inline">
								<?php echo form_error('PersonID'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div -Person ID -->
                    
                    <!-- start of div - Ext Ref ID -->
                    <div class="control-group <?php if(form_error('ExtRefID')) echo 'error';?>">
						<label class="control-label">Ext Ref ID</label>
						<div class="controls">
							<input class="input-xlarge" id="ExtRefID" name="ExtRefID" type="text" value="<?php echo set_value('ExtRefID', $ExtRefID); ?>">
							<span class="help-inline">
								<?php echo form_error('ExtRefID'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div - Ext Ref ID-->
                    
                    <!-- start of div -Last Login ID-->
                    <div class="control-group <?php if(form_error('LastLoginAt')) echo 'error';?>">
						<label class="control-label">Last Login AT</label>
						<div class="controls">
							<input class="input-xlarge" id="LastLoginAt" name="LastLoginAt" type="text" value="<?php echo set_value('LastLoginAt', $LastLoginAt); ?>">
							<span class="help-inline">
								<?php echo form_error('LastLoginAt'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div -Last Login ID-->
                    
                    <!-- start of div -User DMN ID-->
                  	<div class="control-group <?php if(form_error('UserDmnID')) echo 'error';?>">
                      <label class="control-label">User Domain ID</label>
                      <div class="controls">
                                                <select name="UserDmnID" data-rel="chosen">
                                                <option value="">Select an option</option>
                                                <?php
                           foreach($userdmniddropdown as $list)
                           {//start of foreach($CountryDrop as $list)
                            
                            if($list->DMN_ID==$UserDmnID)
                            {//start of ($list->MasterID==$Country_ID)
                          ?>
                                                        <option value="<?php echo $list->DMN_ID;?>" selected="selected"><?php echo $list->DMN_NM;?></option>
                          <?php
                            }
                            else
                            {
                          ?><option value="<?php echo $list->DMN_ID;?>" ><?php echo $list->DMN_NM;?></option><?php
                            }//end of ($list->MasterID==$Country_ID)
                          }//end of foreach($CountryDrop as $list)
                                                  ?>
                         
                            </select>
                            <span class="help-inline">
								<?php echo form_error('UserDmnID'); ?>
							</span>
                        </div>
                      </div>
                    <!-- end of div -User DMN ID-->
                  
                    <!-- start of hidden inputs -->
					
                    <input name="UserID" type="hidden" value="<?php echo set_value('UserID', $UserID); ?>">
                    <!-- end of hidden inputs -->
                    
                    <!-- end Of Form Controls   -->
                    <!-- start of div -->
                    <div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('user/user_master','Cancel',array('class'=>'btn')); ?>
					</div>
                    <!-- end of div -->
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>