<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group');?>">User Group</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
    
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                     <!-- start of div -User Group ID -->
                    <!-- <div class="control-group <?php if(form_error('UserGrpID')) echo 'error';?>">
						<label class="control-label">User Group ID</label>
						<div class="controls">
							<input class="input-xlarge" id="UserGrpID" name="UserGrpID" type="text" value="<?php // echo set_value('UserGrpID', $UserGrpID); ?>">
							<span class="help-inline">
								<?php //echo form_error('UserGrpID'); ?>
							</span>
						</div>
					</div>-->
                    <!-- end of div -User Group ID-->
					<!-- start of div - User Group Name -->
					<div class="control-group <?php if(form_error('UserGrpNm')) echo 'error';?>">
						<label class="control-label">User Group Name</label>
						<div class="controls">
							<input class="input-xlarge" id="UserGrpNm" name="UserGrpNm" type="text" value="<?php echo set_value('UserGrpNm', $UserGrpNm); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpNm'); ?>
							</span>
                           
						</div>
					</div>
                     <!-- end of div  - User Group Name-->
                    
                                        
                                        
                   
                                        
                                        
                   <!-- start of div -User DMN ID-->
                  	<div class="control-group <?php if(form_error('UserDmnID')) echo 'error';?>">
                      <label class="control-label">User Domain ID</label>
                      <div class="controls">
                                                <select name="UserDmnID" data-rel="chosen">
                                                <option value="">Select an option</option>
                                                <?php
                           foreach($userdmniddropdown as $list)
                           {//start of foreach($CountryDrop as $list)
                            
                            if($list->DMN_ID==$UserDmnID)
                            {//start of ($list->MasterID==$Country_ID)
                          ?>
                                                        <option value="<?php echo $list->DMN_ID;?>" selected="selected"><?php echo $list->DMN_NM;?></option>
                          <?php
                            }
                            else
                            {
                          ?><option value="<?php echo $list->DMN_ID;?>" ><?php echo $list->DMN_NM;?></option><?php
                            }//end of ($list->MasterID==$Country_ID)
                          }//end of foreach($CountryDrop as $list)
                                                  ?>
                         
                            </select>
                        </div>
                      </div>
                    <!-- end of div -User DMN ID-->



					 <!-- start of div -User DMN ID-->
                  	<!--<div class="control-group <?php if(form_error('UserDmnID')) echo 'error';?>">
                      <label class="control-label">Select User</label>
                      <div class="controls">
                   
                           <?php
                           foreach($getAllUserDropdown as $list)
                            {//start of foreach($CountryDrop as $list)
                        
								 
								if($user_id)
								{
									 ?>  
      <input  type="checkbox" name="user_name[]" value="<?php echo $list->USER_ID; ?>" checked="checked" /><?php echo $list->USER_NAME; ?>
        
        <?php }else {?> 

<input  type="checkbox" name="user_name[]" value="<?php echo $list->USER_ID; ?>"  /><?php echo $list->USER_NAME; ?>
        <?php }
							}//end of foreach($getAllUserDropdown as $list)
                           ?>
                         
                        
                        </div>
                      </div>-->
                    <!-- end of div -User DMN ID-->


					<div class="control-group">
        <label class="control-label" for="selPeople">Select Users</label>
        <div class="controls">
          <select id="user_name" name="user_name[]" multiple data-rel="chosen">
                                  <?php
          foreach($getAllUserDropdown as $list)
          {
           if(isset($assgnd_users_ids) && in_array($list->USER_ID,$assgnd_users_ids))
           {
            ?><option value="<?php echo $list->USER_ID;?>" selected="selected"><?php echo $list->USER_NAME;?></option><?php
           }
           else
           {
            ?><option value="<?php echo $list->USER_ID;?>"><?php echo $list->USER_NAME;?></option><?php
           }
          }
                                  ?>
          </select>
                                  
        </div>
         </div>
                  
 
 
<!-- end of form controls -->
                    <!-- start of hidden inputs -->
      					<input class="input-xlarge" id="UserGrpID" name="UserGrpID" type="hidden" value="<?php  echo set_value('UserGrpID', $UserGrpID); ?>">
						<!--<input class="input-xlarge" id="UserGrpDtlID" name="UserGrpDtlID" type="hidden" value="<?php  echo set_value('UserGrpDtlID', $UserGrpDtlID); ?>">-->
                    <!-- end of hidden inputs -->
  					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('user/user_group');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
                    
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>