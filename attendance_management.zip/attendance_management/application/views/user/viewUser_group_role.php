<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group_role');?>">User Group Role Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					<legend></legend>
                    
                    <!-- Start Of Form Controls   -->
                     <!-- start of div -User Group Role ID -->
                   <!--  <div class="control-group <?php //if(form_error('GrpRoleID')) echo 'error';?>">
						<label class="control-label">Group Role ID</label>
						<div class="controls">
							<input class="input-xlarge" id="GrpRoleID" name="GrpRoleID" type="text" value="<?php// echo set_value('GrpRoleID', $GrpRoleID); ?>">
							<span class="help-inline">
								<?php //echo form_error('GrpRoleID'); ?>
							</span>
						</div>
					</div>-->
                    <!-- end of div -User Group Role ID-->
                    <!--start Of div-->
			        <div class="control-group <?php if(form_error('RoleID')) echo 'error';?>">
						<label class="control-label">Role ID</label>
						 <div class="controls">
                                                <select name="RoleID" data-rel="chosen">
                                                <option value="">Select an option</option>
                                                <?php
                           foreach($roleiddropdown as $list)
                           {//start of foreach($CountryDrop as $list)
                            
                            if($list->ROLE_ID==$RoleID)
                            {//start of ($list->MasterID==$Country_ID)
                          ?>
                                                        <option value="<?php echo $list->ROLE_ID;?>" selected="selected"><?php echo $list->ROLE_NM;?></option>
                          <?php
                            }
                            else
                            {
                          ?><option value="<?php echo $list->ROLE_ID;?>" ><?php echo $list->ROLE_NM; ?></option><?php
                            }//end of ($list->MasterID==$Country_ID)
                          }//end of foreach($CountryDrop as $list)
                                                  ?>
                         
                            </select>
                            <span class="help-inline">
								<?php echo form_error('RoleID'); ?>
							</span>
                        </div>
					</div>
                    <!-- end of div -->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('UserGrpID')) echo 'error';?>">
						<label class="control-label">User Group ID</label>
						 <div class="controls">
                                                <select name="UserGrpID" data-rel="chosen">
                                                <option value="">Select an option</option>
                                                <?php
                           foreach($userroleiddropdown as $list)
                           {//start of foreach($CountryDrop as $list)
                            
                            if($list->USER_GRP_ID==$UserGrpID)
                            {//start of ($list->MasterID==$Country_ID)
                          ?>
                                                        <option value="<?php echo $list->USER_GRP_ID;?>" selected="selected"><?php echo $list->USER_GRP_NM;?></option>
                          <?php
                            }
                            else
                            {
                          ?><option value="<?php echo $list->USER_GRP_ID;?>" ><?php echo $list->USER_GRP_NM; ?></option><?php
                            }//end of ($list->MasterID==$Country_ID)
                          }//end of foreach($CountryDrop as $list)
                                                  ?>
                         
                            </select>
                            <span class="help-inline">
								<?php echo form_error('UserGrpID'); ?>
							</span>
                        </div>
					</div>
                    <!-- end of div -->

					
                    <!-- start of hidden inputs -->
                   <input class="input-xlarge" id="GrpRoleID" name="GrpRoleID" type="hidden" value="<?php echo set_value('GrpRoleID', $GrpRoleID); ?>">
                    <!-- end of hidden inputs -->
                    <!-- end Of Form Controls   -->
                    <div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('user/user_group_role');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>