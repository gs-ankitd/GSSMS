<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_group_c');?>">User Group</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
    
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
 <!-- start of div -->
					<div class="control-group <?php if(form_error('UserGrpNm')) echo 'error';?>">
						<label class="control-label">User Group Name</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="UserGrpNm" type="text" value="<?php echo set_value('UserGrpNm', $UserGrpNm); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpNm'); ?>
							</span>
                           
						</div>
					</div>
 <!-- end of div -->
 <!-- start of div -->
					<div class="control-group <?php if(form_error('UserId')) echo 'error';?>">
						<label class="control-label">Hier Type Entity Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="UserId" type="text" value="<?php echo set_value('UserId', $UserId); ?>">
							<span class="help-inline">
								<?php echo form_error('UserId'); ?>
							</span>
						</div>
					</div>
 <!-- end of div -->
                    
                    
 <!-- start of div -->
                    <div class="control-group <?php if(form_error('ExtRefId')) echo 'error';?>">
						<label class="control-label">Level Seq</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="ExtRefId" type="text" value="<?php echo set_value('ExtRefId', $ExtRefId); ?>">
							<span class="help-inline">
								<?php echo form_error('ExtRefId'); ?>
							</span>
						</div>
					</div>
 <!-- end of div -->
                    
                    
 <!-- start of div -->                    
                    <div class="control-group <?php if(form_error('UserDmnID')) echo 'error';?>">
						<label class="control-label">Oa Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="UserDmnID" type="text" value="<?php echo set_value('UserDmnID', $UserDmnID); ?>">
							<span class="help-inline">
								<?php echo form_error('UserDmnID'); ?>
							</span>
						</div>
					</div>
 <!-- end of div -->
                    
 <!-- start of div -->                    
                     <div class="control-group <?php if(form_error('IsDeleted')) echo 'error';?>">
						<label class="control-label">Is Deleted</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="IsDeleted" type="text" value="<?php echo set_value('IsDeleted', $IsDeleted); ?>">
							<span class="help-inline">
								<?php echo form_error('IsDeleted'); ?>
							</span>
						</div>
					</div>
<!-- end of div -->
<!-- start of div -->                    
                     <div class="control-group <?php if(form_error('UserGrpCreatedBy')) echo 'error';?>">
						<label class="control-label">User Group CreatedBy</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="UserGrpCreatedBy" type="text" value="<?php echo set_value('UserGrpCreatedBy', $UserGrpCreatedBy); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpCreatedBy'); ?>
							</span>
						</div>
					</div>
<!-- end of div -->
<!-- start of div -->                    
                     <div class="control-group <?php if(form_error('UserGrpUpdatedBy')) echo 'error';?>">
						<label class="control-label">User Group UpdatedBy</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="UserGrpUpdatedBy" type="text" value="<?php echo set_value('UserGrpUpdatedBy', $UserGrpUpdatedBy); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpUpdatedBy'); ?>
							</span>
						</div>
					</div>
<!-- end of div -->
<!-- start of div -->                    
                     <div class="control-group <?php if(form_error('UserGrpCreatedOn')) echo 'error';?>">
						<label class="control-label">Oa Brand ID</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="UserGrpCreatedOn" type="text" value="<?php echo set_value('UserGrpCreatedOn', $UserGrpCreatedOn); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpCreatedOn'); ?>
							</span>
						</div>
					</div>
<!-- end of div -->
<!-- start of div -->                    
                     <div class="control-group <?php if(form_error('UserGrpUpdatedOn')) echo 'error';?>">
						<label class="control-label">Oa Brand ID</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="UserGrpUpdatedOn" type="text" value="<?php echo set_value('UserGrpUpdatedOn', $UserGrpUpdatedOn); ?>">
							<span class="help-inline">
								<?php echo form_error('UserGrpUpdatedOn'); ?>
							</span>
						</div>
					</div>
<!-- end of form controls -->
                    <!-- start of hidden inputs -->
      <!-- <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">-->
                    <!-- end of hidden inputs -->
  					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
                    
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>