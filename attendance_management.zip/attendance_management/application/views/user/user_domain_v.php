<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_domain');?>">User Domain</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> User Domain Details</h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/user_domain'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
        	
			<fieldset>
                 
                  <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/user_domain/newUserDomain'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<?php
                            if(validateColVisibility('DMN_ID',$visi))
                            {
                            ?>
                        	<th>ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('DMN_NM',$visi))
                            {
                            ?>
                        	<th>User Domain Name</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('DSCRPTN',$visi))
                            {
                            ?>
							<th>Description</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('OA_ID',$visi))
                            {
                            ?>
                            <th>Org Account</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('OA_BRAND_ID',$visi))
                            {
                            ?>
                            <th>Org Account Brand</th>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <th>Deleted</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                            <th>Created By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                          	<th>Updated By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                          	<th>Created On</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                            <th>Updated On</th>
                            <?php
							}
							?>
                           
                            <th>Actions</th>
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($listDomain as $list) :?>
						<tr><?php
                            if(validateColVisibility('DMN_ID',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $list->DMN_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('DMN_NM',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $list->DMN_NM; ?></td>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('DSCRPTN',$visi))
                            {
                            ?>
							<td class="center"><?php echo $list->DSCRPTN; ?></td>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('OA_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->OA_NM; ?></td>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('OA_BRAND_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->OA_BRAND_NM; ?></td>
                            <?php
							}
							?>
                             <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <td class="center"><?php if($list->IS_DELETED) echo "Yes"; else echo "No"; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->CREATED_BY_UNM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->UPDATED_BY_UNM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->CREATED_ON; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $list->UPDATED_ON; ?></td>
                            <?php
							}
							?>

                            <td class="center ">
                                 <a href="<?php echo site_url('user/user_domain/editUserDomain/'.$list->DMN_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('user/user_domain/delete/'.$list->DMN_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->