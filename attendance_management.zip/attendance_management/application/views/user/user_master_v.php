<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/user_master');?>">Users</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> Users</h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/user_mst'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
       
			<fieldset>               
                <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('user/user_master/newUser');?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
							<?php
                            if(validateColVisibility('USER_ID',$visi))
                            {
                            ?>
                                <th>ID</th>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('USER_ID',$visi))
                            {
                            ?>
                            <th>User</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('REG_EMAIL_ID',$visi))
                            {
                            ?>
                        	<th>Email ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('PASSWORD',$visi))
                            {
                            ?>
							<th>Password</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_STATUS_ID',$visi))
                            {
                            ?>
							<th>User Status</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('Person_ID',$visi))
                            {
                            ?>
                            <th>Person ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('EXT_REF_NBR',$visi))
                            {
                            ?>
                            <th>External Ref ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('EXT_REF_NBR',$visi))
                            {
                            ?>
                            <th>Last Login</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_DMN_ID',$visi))
                            {
                            ?>
                            <th>User Domain ID</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <th>Is Deleted</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                            <th>Created By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                           <th>Updated By</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                           <th>Created On</th>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                          <th>Updated On</th>
                            <?php
							}
							?>
                           
                            <th>Actions</th>
                            
                            
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($Users as $user)
								{
						?>
						<tr>
                        	<?php
                            if(validateColVisibility('USER_ID',$visi))
                            {
                            ?>
                        	
                        	<td class="center"><?php echo $user->USER_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_NAME',$visi))
                            {
                            ?>
                        	<td class="center"><?php echo $user->USER_NAME; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('REG_EMAIL_ID',$visi))
                            {
                            ?>
							<td class="center"><?php echo $user->REG_EMAIL_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('PASSWORD',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->PASSWORD; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_STATUS_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->USER_STATUS_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('Person_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->Person_ID; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('EXT_REF_NBR',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->EXT_REF_NBR; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('LAST_LOGIN_AT',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->LAST_LOGIN_AT; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('USER_DMN_ID',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->USER_DMN_NM; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('IS_DELETED',$visi))
                            {
                            ?>
                            <td class="center"><?php if($user->IS_DELETED == '1') echo "Yes"; else echo "No"; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_BY',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->CREATED_BY; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_BY',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->UPDATED_BY; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('CREATED_ON',$visi))
                            {
                            ?>
                            <td class="center"><?php echo $user->CREATED_ON; ?></td>
                            <?php
							}
							?>
                            <?php
                            if(validateColVisibility('UPDATED_ON',$visi))
                            {
                            ?>
                           <td class="center"><?php echo $user->UPDATED_ON; ?></td>
                            <?php
							}
							?>
                            <td class="center ">
                                
                                 <a href="<?php echo site_url('user/user_master/editUser/'.$user->USER_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('user/user_master/delete/'.$user->USER_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
							</td>
                      	</tr>	
                        <?php } ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->