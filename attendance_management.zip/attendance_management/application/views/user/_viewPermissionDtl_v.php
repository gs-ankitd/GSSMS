<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/permission_dtl');?>">Permission Detail </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>

		</div>
 
    		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					<legend></legend>

<!-- start of form controls -->                    
					<div class="control-group <?php if(form_error('PermissionsRefTypeId')) echo 'error';?>">
						<label class="control-label">Permissions RefTypeId</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="PermissionsRefTypeId" type="text" value="<?php echo set_value('PermissionsRefTypeId', $PermissionsRefTypeId); ?>">
							<span class="help-inline">
								<?php echo form_error('PermissionsRefTypeId'); ?>
							</span>
                           
						</div>
					</div>

					<div class="control-group <?php if(form_error('PermissionsRefId')) echo 'error';?>">
						<label class="control-label">Permissions Ref Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="PermissionsRefId" type="text" value="<?php echo set_value('PermissionsRefId', $PermissionsRefId); ?>">
							<span class="help-inline">
								<?php echo form_error('PermissionsRefId'); ?>
							</span>
						</div>
					</div>
                   
                    <div class="control-group <?php if(form_error('PermissionsId')) echo 'error';?>">
						<label class="control-label">Permissions Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="PermissionsId" type="text" value="<?php echo set_value('PermissionsId', $PermissionsId); ?>">
							<span class="help-inline">
								<?php echo form_error('PermissionsId'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('ObjectId')) echo 'error';?>">
						<label class="control-label">Object Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="ObjectId" type="text" value="<?php echo set_value('ObjectId', $ObjectId); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjectId'); ?>
							</span>
						</div>
					</div>
<!-- end of form controls -->
                    
                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                        
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
                    
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>