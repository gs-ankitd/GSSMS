<?php
	echo $header;
	//echo $menu;
	echo $body;
	echo $footer;
?>