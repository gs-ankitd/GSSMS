			<!-- content ends -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		
        <hr />
        	
		<footer>
			<p class="pull-right">Powered by: <a href="http://geeconglobal.com/">Geecon</a></p>
		</footer>
	</div><!--/.fluid-container-->
</body>
<!-- End of Body Section -->
</html>