<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('attndMngt/attendance_employee');?>">Attendance Management</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    


					 <!-- start of div -OA ID-->
                  <div class="control-group <?php if(form_error('empId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Employee Id</label>
								<div class="controls">
                       <input class="input-xlarge" id="empId" name="empId" type="text" value="<?php echo set_value('empId', $empId); ?>">
                                	<span class="help-inline">
										<?php echo form_error('empId'); ?>
									</span>
								</div>
					</div>
                    
                       <!--end Of div OA ID -->


                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('empNm')) echo 'error';?>">
						<label class="control-label">Employee Name</label>
						<div class="controls">
							
                            
                            <select name="empNm" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($employeeDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->EMP_NAME==$empNm)
									   {//start of ($list->TypeID==$empId)
										?>
                                        <option value="<?php echo $list->EMP_NAME;?>" selected="selected"><?php echo $list->EMP_NAME;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->EMP_NAME;?>" ><?php echo $list->EMP_NAME;?></option><?php
									   }//end of ($list->MasterID==$empId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
							<span class="help-inline">
								<?php echo form_error('empNm'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    
					 <!-- start of div -OA brands ID-->

                    
                     <div class="control-group <?php if(form_error('OaBrandID')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Org Account Brand</label>
								<div class="controls">
							
							<select name="OaBrandID" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
						 foreach($orgBrandsDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_BRAND_ID==$OaBrandID)
									   {//start of ($list->TypeID==$empId)
										?>
                                        <option value="<?php echo $list->OA_BRAND_ID;?>" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
									   }//end of ($list->MasterID==$empId)
									 }//end of foreach($typename as $list)?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('OaBrandID'); ?>
									</span>
								</div>
							  </div>
                    <!-- end of div -User DMN ID-->
                    
                    
                    <!-- start of hidden inputs -->
                   <input name="id" type="hidden" value="<?php echo set_value('id', $attndEmpId); ?>">
							 
                    <!-- end of hidden inputs -->
                    <!-- end Of Form Controls   -->
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('attndMngt/attendance_employee');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>