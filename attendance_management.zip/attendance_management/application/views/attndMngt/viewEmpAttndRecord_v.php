<script>
 $(function () {

            $('.date-time').datetimepicker(); // selector picks any element with class="date-time"

            //$('#ukFormat').datetimepicker({ dateFormat: 'dd-mm-yy' }); // selector picks element with id="ukFormat"                       
            $('#ukFormat').datetimepicker({ dateFormat: 'yy-mm-dd' });

            $('#dateTimePicker').datetimepicker({ dateFormat: 'dd-mm-yy',
                onSelect: function (dateText) {

                    /* get the selected date */
                    var selectedDate = $('#dateTimePicker').datetimepicker('getDate');

                    /* create an array of day and month names based on the datepicker defaults */
                    /* to set the _defaults for day and month names, take a look here http://jqueryui.com/demos/datepicker/#localization  */
                    var dayNames = $.datepicker._defaults.dayNames;
                    var monthNames = $.datepicker._defaults.monthNames;

                    /* assign are vars */
                    var date = selectedDate.getDate();
                    var day = dayNames[selectedDate.getDay()]; // taking the day name from the array of day names 
                    var month = monthNames[selectedDate.getMonth()]; // taking the month name from the array of month names
                    var year = selectedDate.getFullYear();
                    var time = selectedDate.getHours() + ':' + selectedDate.getMinutes();

                    /* update the ui */ 
                    $('#day').html('day: ' + date + ' ' + day);
                    $('#month').html('month: ' + month);
                    $('#year').html('year: ' + year);
                    $('#time').html('time: ' + time);

                },
                onClose: function (dateText) {
                    /* do something */
                }
            });

        });
		
		
		 $(function () {

            $('.date-time').datetimepicker(); // selector picks any element with class="date-time"

            //$('#ukFormat').datetimepicker({ dateFormat: 'dd-mm-yy' }); // selector picks element with id="ukFormat"                       
            $('#ukFormat').datetimepicker({ dateFormat: 'yy-mm-dd' });

            $('#dateTimePicker1').datetimepicker({ dateFormat: 'dd-mm-yy',
                onSelect: function (dateText) {

                    /* get the selected date */
                    var selectedDate = $('#dateTimePicker1').datetimepicker('getDate');

                    /* create an array of day and month names based on the datepicker defaults */
                    /* to set the _defaults for day and month names, take a look here http://jqueryui.com/demos/datepicker/#localization  */
                    var dayNames = $.datepicker._defaults.dayNames;
                    var monthNames = $.datepicker._defaults.monthNames;

                    /* assign are vars */
                    var date = selectedDate.getDate();
                    var day = dayNames[selectedDate.getDay()]; // taking the day name from the array of day names 
                    var month = monthNames[selectedDate.getMonth()]; // taking the month name from the array of month names
                    var year = selectedDate.getFullYear();
                    var time = selectedDate.getHours() + ':' + selectedDate.getMinutes();

                    /* update the ui */ 
                    $('#day').html('day: ' + date + ' ' + day);
                    $('#month').html('month: ' + month);
                    $('#year').html('year: ' + year);
                    $('#time').html('time: ' + time);

                },
                onClose: function (dateText) {
                    /* do something */
                }
            });

        });
		
		
			$(function () {

            $('.date-time').datetimepicker(); // selector picks any element with class="date-time"

            //$('#ukFormat').datetimepicker({ dateFormat: 'dd-mm-yy' }); // selector picks element with id="ukFormat"                       
            $('#ukFormat').datetimepicker({ dateFormat: 'yy-mm-dd' });

            $('#dateTimePicker2').datetimepicker({ dateFormat: 'dd-mm-yy',
                onSelect: function (dateText) {

                    /* get the selected date */
                    var selectedDate = $('#dateTimePicker2').datetimepicker('getDate');

                    /* create an array of day and month names based on the datepicker defaults */
                    /* to set the _defaults for day and month names, take a look here http://jqueryui.com/demos/datepicker/#localization  */
                    var dayNames = $.datepicker._defaults.dayNames;
                    var monthNames = $.datepicker._defaults.monthNames;

                    /* assign are vars */
                    var date = selectedDate.getDate();
                    var day = dayNames[selectedDate.getDay()]; // taking the day name from the array of day names 
                    var month = monthNames[selectedDate.getMonth()]; // taking the month name from the array of month names
                    var year = selectedDate.getFullYear();
                    var time = selectedDate.getHours() + ':' + selectedDate.getMinutes();

                    /* update the ui */ 
                    $('#day').html('day: ' + date + ' ' + day);
                    $('#month').html('month: ' + month);
                    $('#year').html('year: ' + year);
                    $('#time').html('time: ' + time);

                },
                onClose: function (dateText) {
                    /* do something */
                }
            });

        });
		
		
				 $(function () {

            $('.date-time').datetimepicker(); // selector picks any element with class="date-time"

            //$('#ukFormat').datetimepicker({ dateFormat: 'dd-mm-yy' }); // selector picks element with id="ukFormat"                       
            $('#ukFormat').datetimepicker({ dateFormat: 'yy-mm-dd' });

            $('#dateTimePicker3').datetimepicker({ dateFormat: 'dd-mm-yy',
                onSelect: function (dateText) {

                    /* get the selected date */
                    var selectedDate = $('#dateTimePicker3').datetimepicker('getDate');

                    /* create an array of day and month names based on the datepicker defaults */
                    /* to set the _defaults for day and month names, take a look here http://jqueryui.com/demos/datepicker/#localization  */
                    var dayNames = $.datepicker._defaults.dayNames;
                    var monthNames = $.datepicker._defaults.monthNames;

                    /* assign are vars */
                    var date = selectedDate.getDate();
                    var day = dayNames[selectedDate.getDay()]; // taking the day name from the array of day names 
                    var month = monthNames[selectedDate.getMonth()]; // taking the month name from the array of month names
                    var year = selectedDate.getFullYear();
                    var time = selectedDate.getHours() + ':' + selectedDate.getMinutes();

                    /* update the ui */ 
                    $('#day').html('day: ' + date + ' ' + day);
                    $('#month').html('month: ' + month);
                    $('#year').html('year: ' + year);
                    $('#time').html('time: ' + time);

                },
                onClose: function (dateText) {
                    /* do something */
                }
            });

        });
</script>
<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('attndMngt/empAttndRecord');?>">Employee Attendance Record Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                    <!--start Of div-->
                    <div class="control-group  <?php if(form_error('ATTND_EMP_ID'))  echo 'error'; ?>">
						<label class="control-label" for="focusedInput">Attendance Emp ID<span style="color:red;">*</span> </label>
						<div class="controls">
						<select name="ATTND_EMP_ID" data-rel="chosen">
                    		<option value="">Select an option</option>
                        	<?php
								foreach($AttndEmpIDDrop as $list)
								{//start of foreach($typename as $list)  
									if($list->ATTND_EMP_ID==$ATTND_EMP_ID)
									{//start of if($list->TypeID==$parentTypeID)
									?>
                                    <option value="<?php echo $list->ATTND_EMP_ID;?>" selected="selected"><?php echo $list->EMP_NM;?></option>
									<?php
									}
									else
									{
									?><option value="<?php echo $list->ATTND_EMP_ID;?>" ><?php echo $list->EMP_NM;?></option><?php
									}//end of if($list->TypeID==$parentTypeID)
								}//end of foreach($typename as $list)
                            ?>	 
     					</select>
                        </div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_IN_UTC_TIME')) echo 'error';?>">
						<label class="control-label">PUNCH IN UTC TIME</label>
						<div class="controls">
                        <input type="text" name="PUNCH_IN_UTC_TIME" id="dateTimePicker" value="<?php echo set_value('PUNCH_IN_UTC_TIME', $PUNCH_IN_UTC_TIME); ?>"/>
							<!--<input class="input-xlarge datepicker" id="PUNCH_IN_UTC_TIME" name="PUNCH_IN_UTC_TIME" type="text" value="<?php echo set_value('PUNCH_IN_UTC_TIME', $PUNCH_IN_UTC_TIME); ?>">-->
                            
							<span class="help-inline">
								<?php echo form_error('PUNCH_IN_UTC_TIME'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_IN_NOTE')) echo 'error';?>">
						<label class="control-label">PUNCH IN NOTE</label>
						<div class="controls">
							<input class="input-xlarge" id="PUNCH_IN_NOTE" name="PUNCH_IN_NOTE" type="text" value="<?php echo set_value('PUNCH_IN_NOTE', $PUNCH_IN_NOTE); ?>">
							<span class="help-inline">
								<?php echo form_error('PUNCH_IN_NOTE'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_IN_TIME_OFFSET')) echo 'error';?>">
						<label class="control-label">PUNCH IN TIME OFFSET</label>
						<div class="controls">
							<input class="input-xlarge" id="PUNCH_IN_TIME_OFFSET" name="PUNCH_IN_TIME_OFFSET" type="text" value="<?php echo set_value('PUNCH_IN_TIME_OFFSET', $PUNCH_IN_TIME_OFFSET); ?>">
							<span class="help-inline">
								<?php echo form_error('PUNCH_IN_TIME_OFFSET'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                                      
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_IN_USER_TIME')) echo 'error';?>">
						<label class="control-label">PUNCH IN USER TIME</label>
						<div class="controls">
							<!--<input class="input-xlarge datepicker" id="PUNCH_IN_USER_TIME" name="PUNCH_IN_USER_TIME" type="datetime-local" value="<?php echo set_value('PUNCH_IN_USER_TIME', $PUNCH_IN_USER_TIME); ?>">-->
                     <input type="text" name="PUNCH_IN_USER_TIME" id="dateTimePicker1" value="<?php echo set_value('PUNCH_IN_USER_TIME', $PUNCH_IN_USER_TIME); ?>"/>       
					
							<span class="help-inline">
								<?php echo form_error('PUNCH_IN_USER_TIME'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_OUT_UTC_TIME')) echo 'error';?>">
						<label class="control-label">PUNCH OUT UTC TIME</label>
						<div class="controls">
							<!--<input class="input-xlarge datepicker" id="PUNCH_OUT_UTC_TIME" name="PUNCH_OUT_UTC_TIME" type="datetime-local" value="<?php echo set_value('PUNCH_OUT_UTC_TIME', $PUNCH_OUT_UTC_TIME); ?>">-->
                           <input type="text" name="PUNCH_OUT_UTC_TIME" id="dateTimePicker2" value="<?php echo set_value('PUNCH_OUT_UTC_TIME', $PUNCH_OUT_UTC_TIME); ?>"/> 
                                                      
				
							<span class="help-inline">
								<?php echo form_error('PUNCH_OUT_UTC_TIME'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_OUT_NOTE')) echo 'error';?>">
						<label class="control-label">PUNCH OUT NOTE</label>
						<div class="controls">
							<input class="input-xlarge" id="PUNCH_OUT_NOTE" name="PUNCH_OUT_NOTE" type="text" value="<?php echo set_value('PUNCH_OUT_NOTE', $PUNCH_OUT_NOTE); ?>">
							<span class="help-inline">
								<?php echo form_error('PUNCH_OUT_NOTE'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_OUT_TIME_OFFSET')) echo 'error';?>">
						<label class="control-label">PUNCH OUT TIME OFFSET</label>
						<div class="controls">
							<input class="input-xlarge" id="PUNCH_OUT_TIME_OFFSET" name="PUNCH_OUT_TIME_OFFSET" type="text" value="<?php echo set_value('PUNCH_OUT_TIME_OFFSET', $PUNCH_OUT_TIME_OFFSET); ?>">
							<span class="help-inline">
								<?php echo form_error('PUNCH_OUT_TIME_OFFSET'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('PUNCH_OUT_USER_TIME')) echo 'error';?>">
						<label class="control-label">PUNCH OUT USER TIME</label>
						<div class="controls">
							<!--<input class="input-xlarge datepicker" id="PUNCH_OUT_USER_TIME" name="PUNCH_OUT_USER_TIME" type="datetime-local" value="<?php echo set_value('PUNCH_OUT_USER_TIME', $PUNCH_OUT_USER_TIME); ?>">-->
						<input type="text" name="PUNCH_OUT_USER_TIME" id="dateTimePicker3" value="<?php echo set_value('PUNCH_OUT_USER_TIME', $PUNCH_OUT_USER_TIME); ?>"/>
							<span class="help-inline">
								<?php echo form_error('PUNCH_OUT_USER_TIME'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
      
                    <!--start Of div-->
                    <div class="control-group  <?php if(form_error('ATTND_STATUS_ID'))  echo 'error'; ?>">
						<label class="control-label" for="focusedInput">ATTENDANCE STATUS<span style="color:red;">*</span> </label>
						<div class="controls">
						<select name="ATTND_STATUS_ID" data-rel="chosen">
                    		<option value="">Select an option</option>
                        	<?php
								foreach($AttndStatusDrop as $list)
								{//start of foreach($typename as $list)  
									if($list->MSTR_ID==$ATTND_STATUS_ID)
									{//start of if($list->TypeID==$parentTypeID)
									?>
                                    <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
									<?php
									}
									else
									{
									?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									}//end of if($list->TypeID==$parentTypeID)
								}//end of foreach($typename as $list)
                            ?>	 
     					</select>
                        </div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group  <?php if(form_error('OA_BRAND_ID'))  echo 'error'; ?>">
						<label class="control-label" for="focusedInput">OA BRAND<span style="color:red;">*</span> </label>
						<div class="controls">
						<select name="OA_BRAND_ID" data-rel="chosen">
                    		<option value="">Select an option</option>
                        	<?php
								foreach($OABrandsDrop as $list)
								{//start of foreach($typename as $list)  
									if($list->OA_BRAND_ID==$OA_BRAND_ID)
									{//start of if($list->TypeID==$parentTypeID)
									?>
                                    <option value="<?php echo $list->OA_BRAND_ID;?>" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
									<?php
									}
									else
									{
									?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
									}//end of if($list->TypeID==$parentTypeID)
								}//end of foreach($typename as $list)
                            ?>	 
     					</select>
                        </div>
					</div>
                    <!--end Of div-->
                    
                    <!-- start of hidden inputs -->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->

                    <!-- end Of Form Controls   -->
                   <div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('attndMngt/empAttndRecord','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>