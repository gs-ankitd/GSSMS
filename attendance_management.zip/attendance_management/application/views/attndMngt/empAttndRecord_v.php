<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('attndMngt/empAttndRecord');?>">Employee Attendance Record</a> 
		</li>
	</ul>
</div>  
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Employee Attendance Record Details</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">   
        
			<fieldset>
            	<div style="float:right"><a class="btn btn-info" href="<?php echo site_url('attndMngt/empAttndRecord/addEmpAttndRecord/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                 <br><br>

				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
<tr>
							<th>Attendance ID</th>
                            <th>Attendance Emp ID</th>
                            <th>PunchIn UTC Time</th>
                            <th>PunchIn Note</th>
                            <th>PunchIn Time Offset</th>
                            <th>PunchIn User Time</th>
                    		<th>PunchOut UTC Time</th>
                            <th>PunchOut Note</th>
                            <th>PunchOut Time Offset</th>
                            <th>PunchOut User Time</th>
                            <th>Attendance Status</th>
                            <th>OA BRAND</th>
<?php /*
//var_dump($visi);
if(validateColVisibility('ATTND_ID',$visi))
{
?>
<th>Attendance ID</th>
<?php
}
?>

<?php
if (validateColVisibility('ATTND_EMP_ID',$visi)) {
?>
<th>Attendance Emp ID</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_IN_NOTE',$visi)) {
?>
<th>PunchIn UTC Time</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_IN_NOTE',$visi)) {
?>
<th>PunchIn Note</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_IN_TIME_OFFSET',$visi)) {
?>
<th>PunchIn Time Offset</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_IN_USER_TIME',$visi)) {
?>
<th>PunchIn User Time</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_OUT_UTC_TIME',$visi)) {
?>
<th>PunchOut UTC Time</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_OUT_NOTE',$visi)) {
?>
<th>PunchOut Note</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_OUT_TIME_OFFSET',$visi)) {
?>
<th>PunchOut Time Offset</th>
<?php
}
?>

<?php
if (validateColVisibility('PUNCH_OUT_USER_TIME',$visi)) {
?>
<th>PunchOut User Time</th>
<?php
}
?>

<?php
if (validateColVisibility('ATTND_STATUS_ID',$visi)) {
?>
<th>Attendance Status</th>
<?php
}
?>

<?php
if (validateColVisibility('OA_BRAND_ID',$visi)) {
?>
<th>OA BRAND</th>
<?php
}
*/?>
<th>Actions</th>
</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>

<?php foreach($lva_EmpAttndRecord as $list) :?>
<tr>
							<td><?php echo $list->ATTND_ID;?></td>
                            <td><?php echo $list->EMP_NM;?></td>
                        	<td><?php echo $list->PUNCH_IN_UTC_TIME;?></td>
                            <td><?php echo $list->PUNCH_IN_NOTE;?></td>
                            <td><?php echo $list->PUNCH_IN_TIME_OFFSET;?></td>
                            <td><?php echo $list->PUNCH_IN_USER_TIME;?></td>
                            <td><?php echo $list->PUNCH_OUT_UTC_TIME;?></td>
                            <td><?php echo $list->PUNCH_OUT_NOTE;?></td>
                            <td><?php echo $list->PUNCH_OUT_TIME_OFFSET;?></td>
                            <td><?php echo $list->PUNCH_OUT_USER_TIME;?></td>
                            <td><?php echo $list->MSTR_NM;?></td>
                            <td><?php echo $list->OA_BRAND_NM;?></td>
<?php /*
if(validateColVisibility('ATTND_ID',$visi))
{
?>
	<td class="center"><?php echo $list->ATTND_ID; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('ATTND_EMP_ID',$visi))
{
?>
	<td class="center"><?php echo $list->ATTND_EMP_ID; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_IN_UTC_TIME',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_IN_UTC_TIME; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_IN_NOTE',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_IN_NOTE; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_IN_TIME_OFFSET',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_IN_TIME_OFFSET; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_IN_USER_TIME',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_IN_USER_TIME; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_OUT_UTC_TIME',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_OUT_UTC_TIME; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_OUT_NOTE',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_OUT_NOTE; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_OUT_TIME_OFFSET',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_OUT_TIME_OFFSET; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('PUNCH_OUT_USER_TIME',$visi))
{
?>
	<td class="center"><?php echo $list->PUNCH_OUT_USER_TIME; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('ATTND_STATUS_ID',$visi))
{
?>
	<td class="center"><?php echo $list->ATTND_STATUS_ID; ?></td>
<?php
}
?>

<?php
if(validateColVisibility('OA_BRAND_ID',$visi))
{
?>
	<td class="center"><?php echo $list->OA_BRAND_NM; ?></td>
<?php
}
*/?>
                            <td class="center ">
								<a href="<?php echo site_url('attndMngt/empAttndRecord/editEmpAttndRecord/'.$list->ATTND_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span>                                             
								</a>
								<a href="<?php echo site_url('attndMngt/empAttndRecord/delete/'.$list->ATTND_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span> 
								</a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->