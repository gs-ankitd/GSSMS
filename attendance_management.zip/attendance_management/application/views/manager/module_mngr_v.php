<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)Enable/Disable Module View						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/
?>

			
<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Module Manager</a>
					</li>
				</ul>
			</div>
 <!-- breadcrumb ends -->           
            
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->   	

    
<?php 
$sql="SELECT * FROM application_dtl where APP_ID= ".$lvs_appid;
$query=mysql_query($sql);

$num=mysql_num_rows($query);
if($num == 0)
{
?>
					  <div class="row-fluid sortable">
				<div class="box span12" style="margin-left:1px;">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i>Module Manager</h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">

						<form class="form-horizontal"  action="<?php if(isset($action)) echo $action;?>" method="post" name="form1">
							<fieldset>
                            
							  <div class="control-group">
								<label class="control-label" for="focusedInput" style="width:250px;">Repopulate </label>
								<div class="controls">
						
                        <input type="checkbox" name="repopulate"   >

                                  <?php echo form_error('master_code'); ?>
								</div><!--/class="controls" -->
							  </div><!--/class="class="control-group"" -->
                       
            
     <div id="mod">
<?php 
	if(isset($lvs_appid))
	{
		$var_appid=$lvs_appid;
	}
?>

						
     </div><!--id="mod" -->
   
       
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								<button class="btn" onClick="history.go(-1); return false;">Cancel</button>
							  </div>
							</fieldset>
						  </form><!--$action form -->
					
					</div><!--/box-content-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
            
<?php 
}//end if $num == 0
else
{
 ?>       
       
       
       <div class="row-fluid sortable">
				<div class="box span12" style="margin-left:1px;">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i>Module Manager</h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                    <?php  if(isset($message)) echo $message; ?>
                    

						<form class="form-horizontal"  action="<?php if(isset($action_m)) echo $action_m;?>" method="post" name="form1">
							<fieldset>
                            
							  
                       
            
     <div id="mod">
	<?php 
	if(isset($lvs_appid))
	{
		$var_appid=$lvs_appid;
	}
	?>
	<?php foreach($lvs_module as $list) 
    {//start of foreach($lvs_module as $list)
		 
	?>

     
					
	<?php 

	if(isset($enableDisableModule[$list->MSTR_ID]->ENABLED))
	{
		
		$check=$enableDisableModule[$list->MSTR_ID]->ENABLED;
		if($check=='1')// start checked if module is enabled.
		{
			
	?>
                       <!--  <input type="checkbox"  checked name="module_<?php echo $list->MasterID; ?>">-->
                         <div class="control-group">
								<label class="control-label" for="focusedInput" style="width:250px;"><a href="<?php echo site_url('manager/epic_mngr/index/'.$var_appid.'/'.$list->MSTR_ID)?>"><?php echo $list->MSTR_NM;  ?> </a></label>
								<div class="controls" style="margin-left:300px;">
						 <input data-no-uniform="true" checked type="checkbox" class="iphone-toggle" name="module_<?php echo $list->MSTR_ID; ?>">

                                  <?php echo form_error('master_code'); ?>
								  	</div><!--/class="controls"-->
							  </div><!--/class="control-group"-->
	<?php 
		} //  end of checked if module is enabled.
		else
		{ //  start of unchecked if module is disabled.
	?>

                          <div class="control-group">
								<label class="control-label" for="focusedInput" style="width:250px;"><a href="<?php echo site_url('manager/epic_mngr/index/'.$var_appid.'/'.$list->MSTR_ID)?>"><?php echo $list->MSTR_NM;  ?> </a></label>
								<div class="controls" style="margin-left:300px;">
						  <input data-no-uniform="true"  type="checkbox" class="iphone-toggle" id="module_<?php echo $list->MSTR_ID; ?>" name="module_<?php echo $list->MSTR_ID; ?>">
                              <!--<input type="checkbox" id="module_<?php echo $list->MSTR_ID; ?>" name="module_<?php echo $list->MSTR_ID; ?>" >-->

							  </div><!--/class="controls"-->
							  </div><!--/class="control-group"-->
<?php
		}//end of unchecked if module is disabled.
	}//end if $enableDisableModule[$list->MasterID]->Enabled
?>

							
	<?php 
	}//end of foreach($lvs_module as $list)
	?>
						
     </div><!--/id="mod"-->
   
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								<button class="btn" onClick="history.go(-1); return false;">Cancel</button>
							  </div><!--/class="form-actions"-->
							</fieldset>
						  </form><!--$action_m form -->
					
					</div><!--/class="box-content"-->
				</div><!--/span-->
			
			</div><!--/row-fluid sortable-->
<?php 
} 
?>
    
</div><!--/fluid-row-->
	</div>

			<!--/row-->

			<!--/row-->
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
		
		
	</div><!--/.fluid-container-->
    
   

		
</body>
</html>
