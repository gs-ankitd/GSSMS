<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)Enable/Disable Feature View						*/
/*   Code Modifications	: Added Comments - 06-12-13 Sherwin Machado                             */
/*----------------------------------------------------------------------------------------*/
?>

<body>

<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Feature Manager</a>
					</li>
				</ul>
			</div>
<!-- breadcrumb ends -->
            
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->   

       
       <div class="row-fluid sortable">
				<div class="box span12" style="margin-left:1px;">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i>Feature Manager</h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                    <?php  if(isset($message)) echo $message; ?>
                    
						<form class="form-horizontal"  action="<?php if(isset($action_f)) echo $action_f;?>" method="post" name="form1">
							<fieldset>
                            
							  
                       
            
     <div id="mod">
    
     <?php foreach($lvs_feature as $list) 
	 {
		 
	 ?>

     <div class="control-group">
								<label class="control-label" for="focusedInput" style="width:250px;"><a href="<?php //echo site_url('settings/epic_mgnr_v/'.$lvs_appid.'/'.$lvs_fid.'/'.$list->MasterID)?>"><?php echo $list->MasterName;  ?> </a></label>
								<div class="controls">
					
                      
                      <?php if($enableDisableFeature[$list->MasterID]==1)
					  		{  //if master Id is 1. checked
					  ?>
                         <input data-no-uniform="true"  type="checkbox" class="iphone-toggle" name="feature_<?php echo $list->MasterID; ?>" checked>
					 <?php
							}
							else
							{//if master Id is not 1 uncheck
                     ?>
                     <input data-no-uniform="true"  type="checkbox" class="iphone-toggle" name="feature_<?php echo $list->MasterID; ?>" >

                      <?php 
							}//end of uncheck
							?>

								</div>
							  </div>
			<?php 
			
            }

            ?>
						
     </div>
   
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								
                                 <?php echo anchor('manager/epic_mngr/index/'.$pvs_appid.'/'.$pvs_fid,'Cancel',array('class'=>'btn')); ?>
							  </div>
							</fieldset>
						  </form>
					
					</div><!--/class="box-content"-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
     
    
</div><!--/fluid-row-->
				
		<hr>
        
		
		
	</div>

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

	</div><!--/.fluid-container-->
    
   

		
</body>
</html>
