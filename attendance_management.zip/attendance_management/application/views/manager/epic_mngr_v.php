<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)Enable/Disable Epic View						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/
?>
 
			
<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Epic Manager</a>
					</li>
				</ul>
			</div>
<!-- breadcrumb ends -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->     

       
       <div class="row-fluid sortable">
				<div class="box span12" style="margin-left:1px;">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i>Epic Manager</h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                    <?php  //if(isset($message)) echo $message; ?>
                    
						<form class="form-horizontal"  action="<?php if(isset($action_f)) echo $action_f;?>" method="post" name="form1">
							<fieldset>
                            
							  
                       
            
     <div id="mod">
    
     <?php foreach($funcid as $list) 
	 {//start of foreach($funcid as $list)
		 
	 ?>

     <div class="control-group">
								<label class="control-label" for="focusedInput" style="width:250px;"><a href="<?php echo site_url('manager/feature_mngr/index/'.$lvs_appid.'/'.$lvs_fid.'/'.$list->MasterID)?>"><?php echo $list->MasterName;  ?> </a></label>
								<div class="controls">
					
                      
				<?php if($enableDisableEpic[$list->MasterID]==1)
				{  //start of checked if master id is 1
				?>
                         <input data-no-uniform="true"  type="checkbox" class="iphone-toggle" name="epic_<?php echo $list->MasterID; ?>" checked>
				<?php
				} //end of checked if master id is 1
				else
				{ //start of unchecked if master id is not 1				?>
                     <input data-no-uniform="true"  type="checkbox" class="iphone-toggle" name="epic_<?php echo $list->MasterID; ?>" >
				<?php 
                }//end of unchecked if master id is not 1
                ?>

								</div><!--/class="controls" -->
							  </div><!--/class="class="control-group"" -->
			<?php 
            }//end of foreach($funcid as $list)
            ?>
						
     </div><!--/id="mod" -->
   
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								 <?php echo anchor('manager/module_mgnr','Cancel',array('class'=>'btn')); ?>
							  </div><!--/class = form-actionst-->
							</fieldset>
						  </form>
					
					</div><!--/class - box-content-->
				</div><!--/span-->
			
			</div><!--/row-fluid sortable-->
     
    
</div><!--/fluid-row-->
				
		<hr>
        
		
		
	

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

		
	</div><!--/.fluid-container-->
    
   

		
</body>
</html>
