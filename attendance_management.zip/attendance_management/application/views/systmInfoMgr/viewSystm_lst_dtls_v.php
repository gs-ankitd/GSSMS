<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systemInfoMgr/systm_lst_dtls');?>">
System List Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                     <!--start Of div--> 
                    <div class="control-group <?php if(form_error('TBL_NM')) echo 'error';?>">
						<label class="control-label">Table Number</label>
						<div class="controls">
							<input class="input-xlarge" id="TBL_NM" name="TBL_NM" type="text" value="<?php echo set_value('TBL_NM',$TBL_NM); ?>" <?php if($actionMode == 1) echo "readonly "; ?>>
							<span class="help-inline">
								<?php echo form_error('TBL_NM'); ?>
							</span>
                            <p class="help-block">
                            	<!--Like, GEE01-->
							</p>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('LST_NMBR')) echo 'error';?>">
						<label class="control-label">Last Number</label>
						<div class="controls">
							<input class="input-xlarge" id="LST_NMBR" name="LST_NMBR" type="text" value="<?php echo set_value('LST_NMBR', $LST_NMBR); ?>">
							<span class="help-inline">
								<?php echo form_error('LST_NMBR'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!-- end Of Form Controls   -->        
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('systmInfoMgr/systm_lst_dtls');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>