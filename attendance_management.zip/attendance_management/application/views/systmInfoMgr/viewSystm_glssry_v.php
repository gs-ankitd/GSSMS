<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmInfoMgr/systm_glssry');?>">System Glossery Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                     <!--start Of div-->
                     <div class="control-group <?php if(form_error('glssryCd')) echo 'error';?>">
						<label class="control-label">Glossery Code</label>
						<div class="controls">
							<input class="input-xlarge" id="glssryCd" name="glssryCd" type="text" value="<?php echo set_value('glssryCd', $glssryCd); ?>">
							<span class="help-inline">
								<?php echo form_error('glssryCd'); ?>
							</span>
                            <p class="help-block">
                            	
							</p>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('glssryMnng')) echo 'error';?>">
						<label class="control-label">Glossery Mnng</label>
						<div class="controls">
							<input class="input-xlarge" id="glssryMnng" name="glssryMnng" type="text" value="<?php echo set_value('glssryMnng', $glssryMnng); ?>">
							<span class="help-inline">
								<?php echo form_error('glssryMnng'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->

					<!--start Of div-->
                    <div class="control-group <?php if(form_error('glssryDscrptn')) echo 'error';?>">
						<label class="control-label">Glossery Description </label>
						<div class="controls">
							<input class="input-xlarge" id="glssryDscrptn" name="glssryDscrptn" type="text" value="<?php echo set_value('glssryDscrptn', $glssryDscrptn); ?>">
							<span class="help-inline">
								<?php echo form_error('glssryDscrptn'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!-- start of hidden inputs -->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->

                    <!-- end Of Form Controls   -->
                   <div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('systmInfoMgr/systm_glssry');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>