<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('excptnMngt/exception_log');?>">
Exception Log</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                     <!--start Of div--> 
                    <div class="control-group <?php if(form_error('id')) echo 'error';?>">
						<label class="control-label">Exception Log ID</label>
						<div class="controls">
							<input class="input-xlarge" id="id" name="id" type="text" value="<?php echo set_value('id',$id); ?>">
							<span class="help-inline">
								<?php echo form_error('id'); ?>
							</span>
                            <p class="help-block">
                            	<!--Like, GEE01-->
							</p>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('EXCEPTION_TYPE_ID')) echo 'error';?>">
						<label class="control-label">Exception Type ID</label>
						<div class="controls">
							<input class="input-xlarge" id="EXCEPTION_TYPE_ID" name="EXCEPTION_TYPE_ID" type="text" value="<?php echo set_value('EXCEPTION_TYPE_ID', $exc_typ_id); ?>">
							<span class="help-inline">
								<?php echo form_error('EXCEPTION_TYPE_ID'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('MSG_ID')) echo 'error';?>">
						<label class="control-label">Message Type ID</label>
						<div class="controls">
							<input class="input-xlarge" id="MSG_ID" name="MSG_ID" type="text" value="<?php echo set_value('MSG_ID', $msg_id); ?>">
							<span class="help-inline">
								<?php echo form_error('MSG_ID'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('OA_ID')) echo 'error';?>">
						<label class="control-label">OA ID</label>
						<div class="controls">
							<input class="input-xlarge" id="OA_ID" name="OA_ID" type="text" value="<?php echo set_value('OA_ID', $oa_id); ?>">
							<span class="help-inline">
								<?php echo form_error('OA_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('OA_BRAND_ID')) echo 'error';?>">
						<label class="control-label">OA Brand ID</label>
						<div class="controls">
							<input class="input-xlarge" id="OA_BRAND_ID" name="OA_BRAND_ID" type="text" value="<?php echo set_value('OA_BRAND_ID', $oa_brand_id); ?>">
							<span class="help-inline">
								<?php echo form_error('OA_BRAND_ID'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('App_ID')) echo 'error';?>">
						<label class="control-label">App ID</label>
						<div class="controls">
							<input class="input-xlarge" id="App_ID" name="App_ID" type="text" value="<?php echo set_value('App_ID', $app_id); ?>">
							<span class="help-inline">
								<?php echo form_error('App_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Module_ID')) echo 'error';?>">
						<label class="control-label">Module ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Module_ID" name="Module_ID" type="text" value="<?php echo set_value('Module_ID', $module_id); ?>">
							<span class="help-inline">
								<?php echo form_error('Module_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Process_ID')) echo 'error';?>">
						<label class="control-label">Process ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Process_ID" name="Process_ID" type="text" value="<?php echo set_value('Process_ID', $process_id); ?>">
							<span class="help-inline">
								<?php echo form_error('Process_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Location_No')) echo 'error';?>">
						<label class="control-label">Location Number</label>
						<div class="controls">
							<input class="input-xlarge" id="Location_No" name="Location_No" type="text" value="<?php echo set_value('Location_No', $loc_no); ?>">
							<span class="help-inline">
								<?php echo form_error('Location_No'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('ERROR_NBR')) echo 'error';?>">
						<label class="control-label">Exception Sequence</label>
						<div class="controls">
							<input class="input-xlarge" id="ERROR_NBR" name="ERROR_NBR" type="text" value="<?php echo set_value('ERROR_NBR', $err_num); ?>">
							<span class="help-inline">
								<?php echo form_error('ERROR_NBR'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Error_Desc')) echo 'error';?>">
						<label class="control-label">Error Description</label>
						<div class="controls">
							<input class="input-xlarge" id="Error_Desc" name="Error_Desc" type="text" value="<?php echo set_value('Error_Desc', $err_desc); ?>">
							<span class="help-inline">
								<?php echo form_error('Error_Desc'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('ERROR_STACK')) echo 'error';?>">
						<label class="control-label">Error Stack</label>
						<div class="controls">
							<input class="input-xlarge" id="ERROR_STACK" name="ERROR_STACK" type="text" value="<?php echo set_value('ERROR_STACK', $err_stack); ?>">
							<span class="help-inline">
								<?php echo form_error('ERROR_STACK'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('CALL_STACK')) echo 'error';?>">
						<label class="control-label">Call Stack</label>
						<div class="controls">
							<input class="input-xlarge" id="CALL_STACK" name="CALL_STACK" type="text" value="<?php echo set_value('CALL_STACK', $call_stack); ?>">
							<span class="help-inline">
								<?php echo form_error('CALL_STACK'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('SESSION_ID')) echo 'error';?>">
						<label class="control-label">Session ID</label>
						<div class="controls">
							<input class="input-xlarge" id="SESSION_ID" name="SESSION_ID" type="text" value="<?php echo set_value('SESSION_ID', $sess_id); ?>">
							<span class="help-inline">
								<?php echo form_error('SESSION_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('MESSAGE_LEVEL')) echo 'error';?>">
						<label class="control-label">Message Level</label>
						<div class="controls">
							<input class="input-xlarge" id="MESSAGE_LEVEL" name="MESSAGE_LEVEL" type="text" value="<?php echo set_value('MESSAGE_LEVEL', $msg_lvl); ?>">
							<span class="help-inline">
								<?php echo form_error('MESSAGE_LEVEL'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                     
                    <!-- end Of Form Controls   -->       
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('excptnMngt/exception_log','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>