<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('excptnMngt/exception_log');?>">Exception Log</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Exception Log</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
       
			<fieldset>
				
                <legend>Exception Log</legend>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<th>Exception Log ID</th>
                        	<th>Msg Type ID</th>
							<th>OA ID</th>
							<th>App ID</th>
                            <th>Module ID</th>
                            <th>Process ID</th>
                            <th>Location No</th>
                            <th>Exception Seq</th>
                            <th>Error Description</th>
                            <th>Error Stack</th>
                            <th>Call Stack</th>
                            <th>Session ID</th>
                            <th>Message Level</th>
                           
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($lva_exception as $row) :?>
						<tr>
                        
                        	<td class="center"><?php echo $row->EXCEPTION_LOG_ID; ?></td>
                        	<td class="center"><?php echo $row->Message_Type_ID; ?></td>
							<td class="center"><?php echo $row->OA_ID; ?></td>
                            <td class="center"><?php echo $row->App_ID; ?></td>
                            <td class="center"><?php echo $row->Module_ID; ?></td>
                            <td class="center"><?php echo $row->Process_ID; ?></td>
                            <td class="center"><?php echo $row->Location_No; ?></td>
                            <td class="center"><?php echo $row->Exception_Seq; ?></td>
                            <td class="center"><?php echo $row->Error_Desc; ?></td>
                            <td class="center"><?php echo $row->ERROR_STACK; ?></td>
                            <td class="center"><?php echo $row->CALL_STACK; ?></td>
                            <td class="center"><?php echo $row->SESSION_ID; ?></td>
                            <td class="center"><?php echo $row->MESSAGE_LEVEL; ?></td>
                           
                            <td class="center ">
								<a class="btn btn-info" href="<?php echo site_url('excptnMngt/exception_log/editException/'.$row->EXCEPTION_LOG_ID);?>">
									<i class="icon-edit icon-white"></i>  
									Edit                                            
								</a>
								<a class="btn btn-danger" href="<?php echo site_url('excptnMngt/exception_log/delete/'.$row->EXCEPTION_LOG_ID);?>">
									<i class="icon-trash icon-white"></i> 
									Delete
								</a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->