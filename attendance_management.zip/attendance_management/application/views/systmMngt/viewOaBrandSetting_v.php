<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/oa_brand_settings');?>">Oa Brands </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>

<!-- start of form controls -->
					<!-- start of div OABS ID -->
					<!--<div class="control-group <?php //if(form_error('oabsID')) echo 'error';?>">
						<label class="control-label">OABS ID</label>
						<div class="controls">
							<input class="input-xlarge" id="oabsID" name="oabsID" type="text" value="<?php //echo set_value('oabsID', $oabsID); ?>">
							<span class="help-inline">
								<?php //echo form_error('oabsID'); ?>
							</span>
                           
						</div>
					</div>  -->
                    <!-- End of div OABS ID -->  
                    <!-- start of div OABS Attribute ID -->               
					<div class="control-group <?php if(form_error('OabsAttributeID')) echo 'error';?>">
						<label class="control-label">Setting Value</label>
						<div class="controls">
							 <select name="OabsAttributeID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($indmstnamedrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->MSTR_ID==$OabsAttributeID)
									   {//start of ($list->TypeID==$HierTypeId)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									   }//end of ($list->MasterID==$HierTypeId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
							<span class="help-inline">
								<?php echo form_error('OabsAttributeId'); ?>
							</span>
                           
						</div>
					</div>
					<!-- End of div OABS Attribute ID -->
                    <!-- start of div OABS Setting Value -->    
					<div class="control-group <?php if(form_error('OabsSettingValue')) echo 'error';?>">
						<label class="control-label">Setting</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OabsSettingValue" type="text" value="<?php echo set_value('OabsSettingValue', $OabsSettingValue); ?>">
							<span class="help-inline">
								<?php echo form_error('OabsSettingValue'); ?>
							</span>
						</div>
					</div>
                    <!-- End of div OABS Setting Value --> 
                    <!-- start of div OAB ID --> 
                    <div class="control-group <?php if(form_error('OaBrandId')) echo 'error';?>">
						<label class="control-label">Org Account Brand</label>
						<div class="controls">
							<select name="OaBrandId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
         foreach($orgBrandsDrop as $list)
           {//start of foreach($typename as $list)
            
            if($list->OA_BRAND_ID==$OaBrandId)
            {//start of ($list->TypeID==$OaId)
          ?>
                                        <option value="<?php echo $list->OA_BRAND_ID;?>" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
          <?php
            }
            else
            {
          ?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
            }//end of ($list->MasterID==$OaId)
          }//end of foreach($typename as $list)
 
 ?></select>
							<span class="help-inline">
								<?php echo form_error('OaBrandId'); ?>
							</span>
						</div>
					</div>
                    <!-- End of div OAB ID --> 
                    <!-- start of div Ref ID --> 
                    <div class="control-group <?php if(form_error('RefId')) echo 'error';?>">
						<label class="control-label">Ref Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="RefId" type="text" value="<?php echo set_value('RefId', $RefId); ?>">
							<span class="help-inline">
								<?php echo form_error('RefId'); ?>
							</span>
						</div>
					</div>
                    <!-- End of div Ref ID -->
                    <!-- start of div Description -->  
                    <div class="control-group <?php if(form_error('Description')) echo 'error';?>">
						<label class="control-label">Description</label>
						<div class="controls">
							<input class="input-xlarge" id="Description" name="Description" type="text" value="<?php echo set_value('Description', $Description); ?>">
							<span class="help-inline">
								<?php echo form_error('Description'); ?>
							</span>
						</div>
					</div>
                    <!-- End of div Description -->
                    <!-- start of div Validation -->
                     <div class="control-group <?php if(form_error('Validation')) echo 'error';?>">
						<label class="control-label">Validation</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="Validation" type="text" value="<?php echo set_value('Validation', $Validation); ?>">
							<span class="help-inline">
								<?php echo form_error('Validation'); ?>
							</span>
						</div>
					</div>
                   <!-- start of div Validation -->
                   <!-- start of div - Is Active -->
                   <div class="control-group ">
                   <label class="control-label">Active</label>
                   <div class="controls">
                    <?php  if(($IsActive)==1){ ?>
                 <input type="checkbox" name="IsActive" id="IsActive"   checked="checked">
                        <?php }else {?>
                          <input type="checkbox" name="IsActive" id="IsActive"  ><?php } ?>
                                     <span class="help-inline">
                                                  <?php //echo form_error('inactive'); ?>
                             </span>  
                   </div>
                   </div>

                   <!-- end of div - Is Active -->
<!-- end of form controls -->

                    <!-- start of hidden inputs -->
                 <input name="oabsId" type="hidden" value="<?php echo set_value('oabsId', $oabsId); ?>">
                   <!-- end of hidden inputs -->
                            
					<div class="form-actions">
                    
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('systmMngt/oa_brand_settings/');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>