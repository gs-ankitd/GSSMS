<script>
/*function readURL1(input) 
 {
  
            if (input.files &&input.files[0]) {
              var reader = new FileReader();

                reader.onload = function (e) {
                    $('#banner_logo')
                        .attr('src', e.target.result)
						.css('display', 'inline-block')
						.css('margin-left','165px')
                        .width(200)
                        .height(250);
                };

               reader.readAsDataURL(input.files[0]);
            }
  }*/
function readURL1(input) 
 {
  
            if (input.files &&input.files[0]) {
              var reader = new FileReader();
//alert("hi");
                reader.onload = function (e) {
                    $('#org_logo')
                        .attr('src', e.target.result)
                        .width(170)
                        .height(200);
                };

               reader.readAsDataURL(input.files[0]);
            }
  }  
    function readURL2(input) 
 {
  			if (input.files &&input.files[0]) {
              var reader = new FileReader();
   //alert("hi");         	
			  reader.onload = function (e) {
			  		$('#template_logo')
                        .attr('src', e.target.result)
                        .width(170)
                        .height(200);
			               
            	}
				reader.readAsDataURL(input.files[0]);
			}
  } 
</script>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/oa_brands');?>">Oa Brands </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST" enctype="multipart/form-data">
				<fieldset>

<!-- start of form controls -->  
					<!-- start of div - Oa Brand ID -->                  
					<!--<div class="control-group <?php // if(form_error('OaBrandID')) echo 'error';?>">
						<label class="control-label">OA BRAND ID</label>
						<div class="controls">
							<input class="input-xlarge" id="OaBrandID" name="OaBrandID" type="text" value="<?php // echo set_value('OaBrandID', $OaBrandID); ?>">
							<span class="help-inline">
								<?php //echo form_error('OaBrandID'); ?>
							</span>
                           
						</div>
					</div>-->
                    <!-- End of div - Oa Brand ID -->
					<!-- start of div - Oa Brand Code -->                  
					<div class="control-group <?php if(form_error('OaBrandCd')) echo 'error';?>">
						<label class="control-label">Organisation Account Brand Code</label>
						<div class="controls">
							<input readonly class="input-xlarge" id="OaBrandCd" name="OaBrandCd" type="text" value="<?php echo set_value('OaBrandCd', $OaBrandCd); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandCd'); ?>
							</span>
                           
						</div>
					</div>
                    <!-- End of div - Oa Brand Code -->
					<!-- start of div - Oa Brand Name -->
					<div class="control-group <?php if(form_error('OaBrandNm')) echo 'error';?>">
						<label class="control-label">Organisation Account Brand </label>
						<div class="controls">
							<input readonly class="input-xlarge" id="OaBrandNm" name="OaBrandNm" type="text" value="<?php echo set_value('OaBrandNm', $OaBrandNm); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandNm'); ?>
							</span>
						</div>
					</div>
                   <!-- start of div -OA ID-->
                  <div class="control-group <?php if(form_error('OaId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Organisation Account</label>
								<div class="controls">
                                <select name="OaId" data-rel="chosen" onchange="orgAccFunc(this.value)" disabled="disabled">
                                <option value="">Select an option</option>
                                <?php
									  foreach($organisationDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_ID==$OaId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_ID;?>" selected="selected"><?php echo $list->OA_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_ID;?>" ><?php echo $list->OA_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('OaId'); ?>
									</span>
								</div>
					</div>
                    
                       <!--end Of div OA ID -->
                    <!-- start of div - OA RefId -->
                    <div class="control-group <?php if(form_error('RefId')) echo 'error';?>">
						<label class="control-label">Ref Id</label>
						<div class="controls">
							<input readonly class="input-xlarge" id="RefId" name="RefId" type="text" value="<?php echo set_value('RefId', $RefId); ?>">
							<span class="help-inline">
								<?php echo form_error('RefId'); ?>
							</span>
						</div>
					</div>
                    <!-- End of div - OA RefId -->
                      <!-- start of div - OA Brand Logo -->
                      <!--<div class="control-group <?php if(form_error('OaBrandLogo')) echo 'error';?>">
						<label class="control-label">Oa Brand Logo</label>
						<div class="controls">
							<input readonly class="input-xlarge" id="OaBrandLogo" name="OaBrandLogo" type="text" value="<?php echo set_value('OaBrandLogo', $OaBrandLogo); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandLogo'); ?>
							</span>
						</div>
					 </div>-->
                     
                     <!-- start of div - OA Brand Invoice Template -->
                     
                    
                    <!-- <div class="control-group <?php if(form_error('OaBrandInvTmplt')) echo 'error';?>">
						<label class="control-label">Oa Brand Invoice Template</label>
						<div class="controls">
							<input readonly class="input-xlarge" id="name" name="OaBrandInvTmplt" type="text" value="<?php echo set_value('OaBrandInvTmplt', $OaBrandInvTmplt); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandInvTmplt'); ?>
							</span>
						</div>
					</div>-->
                   <!-- End of div - OA Brand Invoice Template -->
                   
                    <!-- start of div - OA Brand Logo -->
                     <div class="control-group" style="width:600px;float:left;">
                         <label class="control-label" for="typeahead">Organisation Account Brand Logo</label>
                         <div class="controls">
                             <input name="userfile" type="file" size="20" id="filepc1" onChange="document.getElementById('fakefilepc1').value = this.value;readURL1(this);"  value="<?php echo set_value('fakefilepc1', $OaBrandLogo); ?>"style="width:80px; margin-left:35px;" />
         <input name="fakefilepc1" type="hidden" id="fakefilepc1" class="file_object_class_new"  style="margin-left:175px;"/>                       
                        </div> 
                      </div>
                      <div style="float:left; width:170px;"><img id="org_logo"  style="display: inline-block; border:2px solid black;" src="<?php echo base_url();?>images/organisationLogo/<?php if($OaBrandLogo) echo @$OaBrandLogo; else echo "blank.jpg";?>" alt="<?php echo ucfirst(@$OaBrandLogo);?>" width="170px" height="200px">
 <h5  style=" position:relative; top:-184px; left:-151px;" align="center">Saved Logo</h5>
							
                       		<!-- <a class="btn btn-primary" style="position:relative; top:-170px; left:-107px;" href="<?php echo site_url('organisation/organisation/removeLogo/'.$this->session->userdata('OA_ID'));?>">
                        	<i style="" class="icon-edit icon-white"></i> Remove 
                        	</a>-->
 						</div>
                     
                     <!-- end of div - OA Brand Logo -->
                     
                     
                     
                     
                     
                     
                     
                     
                     <!-- start of div - OA Brand Invoice Template -->
                     <div class="control-group" style="width:600px;float:left;">
                         <label class="control-label" for="typeahead">Organisation Account Brand Invoice Template</label>
                         <div class="controls">
                             <input name="template" type="text" size="20" id="filepc2" onChange="document.getElementById('fakefilepc2').value = this.value;readURL2(this);"  value="<?php echo set_value('fakefilepc2', $OaBrandLogo); ?>"style="width:80px; margin-left:35px;" />
                           <input name="fakefilepc2" type="hidden" id="fakefilepc2" class="file_object_class_new"  style="margin-left:175px;"/>      
                        </div> 
                      </div>
                       <div style="float:left; width:170px;"><img id="template_logo"  style="display: inline-block; border:2px solid black;" src="<?php echo base_url();?>images/organisationLogo/<?php if($OaBrandInvTmplt) echo @$OaBrandInvTmplt; else echo "blank.jpg";?>" alt="<?php echo ucfirst(@$OaBrandInvTmplt);?>" width="170px" height="200px">
 <h5  style=" position:relative; top:-184px; left:-151px;" align="center">Saved Template</h5>

                       		<!-- <a class="btn btn-primary" style="position:relative; top:-170px; left:-107px;" href="<?php echo site_url('organisation/organisation/removeTemplate/'.$this->session->userdata('OA_ID'));?>">
                        	<i style="" class="icon-edit icon-white"></i> Remove 
                        	</a>-->
 						</div>
                     <!-- End of div - OA Brand Invoice Template -->

                   <!-- start of div - Is Active -->
                   <div class="control-group " style=" clear:both;">
                   <label class="control-label">Active</label>
                   <div class="controls">
                    <?php  if(($IsActive)==1){ ?>
                 <input readonly type="checkbox" name="isActive" id="isActive" disabled="disabled"  checked="checked">
                        <?php }else {?>
                          <input readonly type="checkbox" name="isActive" id="isActive" disabled="disabled"  ><?php } ?>
                                     <span class="help-inline">
                                                  <?php //echo form_error('inactive'); ?>
                             </span>  
                   </div>
                   </div>

                    <!-- end of div - Is Active -->
                    
                  
                    <!-- start of div - Is Primary -->
                   <div class="control-group ">
                   <label class="control-label">Primary</label>
                   <div class="controls">
                    <?php  if(($IsPrimary)==1){ ?>
                 <input readonly type="checkbox" name="isPrimary" id="isPrimary"   checked="checked" disabled="disabled">
                        <?php }else {?>
                          <input readonly type="checkbox" name="isPrimary" id="isPrimary"  disabled="disabled" ><?php } ?>
                                     <span class="help-inline">
                                                  <?php //echo form_error('inactive'); ?>
                             </span>  
                   </div>
                   </div>

                    <!-- end of div - Is Primary -->
<!-- end of form controls -->

                    <!-- start of hidden inputs -->
     				<input readonly class="input-xlarge" id="OaBrandID" name="OaBrandID" type="hidden" value="<?php echo set_value('OaBrandID', $OaBrandID); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<!--<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo $_SERVER['HTTP_REFERER'];?>">
						<button type="button" class="btn">Cancel</button>-->
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>