<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj_tmp');?>">
Entity Object Temp</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Typ')) echo 'error';?>">
						<label class="control-label">Object Type</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Typ" name="Obj_Typ" type="text" value="<?php echo set_value('Obj_Typ', $Obj_Typ); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Typ'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('Obj_Nm')) echo 'error';?>">
						<label class="control-label">Object Number</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Nm" name="Obj_Nm" type="text" value="<?php echo set_value('Obj_Nm', $Obj_Nm); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Nm'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Attrbt_Nm')) echo 'error';?>">
						<label class="control-label">Object Attribute Number</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Attrbt_Nm" name="Obj_Attrbt_Nm" type="text" value="<?php echo set_value('Obj_Attrbt_Nm', $Obj_Attrbt_Nm); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Attrbt_Nm'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div->
                    <div class="control-group <?php if(form_error('Obj_Attrbt_Dsply_Nm')) echo 'error';?>">
						<label class="control-label">Object Attribute Display Number</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Attrbt_Dsply_Nm" name="Obj_Attrbt_Dsply_Nm" type="text" value="<?php echo set_value('Obj_Attrbt_Dsply_Nm', $Obj_Attrbt_Dsply_Nm); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Attrbt_Dsply_Nm'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Attrbt_Dt_Typ')) echo 'error';?>">
						<label class="control-label">Object Attribute Details Type</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Attrbt_Dt_Typ" name="Obj_Attrbt_Dt_Typ" type="text" value="<?php echo set_value('Obj_Attrbt_Dt_Typ', $Obj_Attrbt_Dt_Typ); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Attrbt_Dt_Typ'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Sz')) echo 'error';?>">
						<label class="control-label">Object Size</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Sz" name="Obj_Sz" type="text" value="<?php echo set_value('Obj_Sz', $Obj_Sz); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Sz'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Prcsn')) echo 'error';?>">
						<label class="control-label">Object Prcsn</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Prcsn" name="Obj_Prcsn" type="text" value="<?php echo set_value('Obj_Prcsn', $Obj_Prcsn); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Prcsn'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Nw_Rcrd_Flg')) echo 'error';?>">
						<label class="control-label">Object New Record Flag</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Nw_Rcrd_Flg" name="Obj_Nw_Rcrd_Flg" type="text" value="<?php echo set_value('Obj_Nw_Rcrd_Flg', $Obj_Nw_Rcrd_Flg); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Nw_Rcrd_Flg'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                     <!-- start of hidden inputs -->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
 
                    <!-- end Of Form Controls   -->        
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('entity/entity_obj_tmp','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>