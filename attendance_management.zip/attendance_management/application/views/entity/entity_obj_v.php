<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj');?>">Entity Object</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Entity Object</h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/entity_obj'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
        <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('entity/entity_obj/addEntityObj/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
<br><br>

       
			<fieldset>
				
                  
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                          <?php if (validateColVisibility('OBJ_ID',$visibleCol)) {?>
                        	<th>Object ID</th>
                          <?php } ?>
						  <?php if (validateColVisibility('OBJ_TYP',$visibleCol)) {?>  
                        	<th>Object Type</th>
                          <?php } ?>
						  <?php if (validateColVisibility('OBJ_NM',$visibleCol)) {?>  
							<th>Object Name</th>
                          <?php } ?>
                           <th>Actions</th>

						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($lva_entity as $row) :?>
						<tr>
                          <?php if (validateColVisibility('OBJ_ID',$visibleCol)) {?>
                        	<td class="center"><?php echo $row->OBJ_ID; ?></td>
                          <?php } ?>
						  <?php if (validateColVisibility('OBJ_TYP',$visibleCol)) {?>  
                        	<td class="center"><?php echo $row->OBJ_TYP; ?></td>
                          <?php } ?>
						  <?php if (validateColVisibility('OBJ_NM',$visibleCol)) {?>  
							<td class="center"><?php echo $row->OBJ_NM; ?></td>
                          <?php } ?>  
                            <td class="center ">
								<a href="<?php echo site_url('entity/entity_obj/editEntityObj/'.$row->OBJ_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
									
								<a href="<?php echo site_url('entity/entity_obj/delete/'.$row->OBJ_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
									
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->