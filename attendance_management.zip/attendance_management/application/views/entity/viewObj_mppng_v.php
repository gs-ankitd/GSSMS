<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/obj_mppng');?>">Object Mapping Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    
					<!-- Start Of Form Controls   -->
                    
                     
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('SrcLyr')) echo 'error';?>">
						<label class="control-label">Source Layer</label>
						<div class="controls">
														
                            <select name="SrcLyr" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($layerDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->TYP_ID==$SrcLyr)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->TYP_ID;?>" selected="selected"><?php echo $list->TYP_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
                            <span class="help-inline">
								<?php echo form_error('SrcLyr'); ?>
							</span>
                         </div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('SrcobjId')) echo 'error';?>">
						<label class="control-label">Source Object ID</label>
						<div class="controls">
                        <select name="SrcobjId" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($objIDDropdown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ID==$SrcobjId)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->OBJ_ID;?>" selected="selected"><?php echo $list->OBJ_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OBJ_ID;?>" ><?php echo $list->OBJ_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
                    <!-- end of div-->
					<!-- start of div-->
                    <div class="control-group <?php if(form_error('TrgtLyr')) echo 'error';?>">
						<label class="control-label">Target Layer</label>
						<div class="controls">
							<select name="TrgtLyr" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($layerDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->TYP_ID==$TrgtLyr)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->TYP_ID;?>" selected="selected"><?php echo $list->TYP_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
                            <span class="help-inline">
								<?php echo form_error('TrgtLyr'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of div-->
                       <div class="control-group <?php if(form_error('TrgtObjId')) echo 'error';?>">
						<label class="control-label">Target Object ID</label>
						<div class="controls">
                        <select name="TrgtObjId" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($objIDDropdown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ID==$TrgtObjId)
                                          {//start of if($list->Obj_ID==$TrgtObjId)  ?>
                                              <option value="<?php echo $list->OBJ_ID;?>" selected="selected"><?php echo $list->OBJ_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OBJ_ID;?>" ><?php echo $list->OBJ_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$TrgtObjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of hidden inputs -->
                   <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->

                    <!-- End Of Form Controls   -->
                   
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						 <?php echo anchor('entity/obj_mppng','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>