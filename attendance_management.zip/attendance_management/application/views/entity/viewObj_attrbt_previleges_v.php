<script>
	function orgAccFunc(OAId){
		//alert(typeId);
		if(OAId){//if there is a typeId pressed and has a value
		
		$.ajax({
			url:"<?php echo site_url('user/user_domain/ajaxOrgLive/').'/';?>"+OAId, //here we are calling our user controller 
 			success: function(typeDropdown) //we're calling the response json array 'activities'
 			{
				 $("#OaBrandID > option").remove(); //first of all clear select items
				
 				$.each(typeDropdown,function(type_id,type_name) //here we're doing a foeach loop round each activity with id as the key and activity as the value
 				{
 					 opt = $('<option />'); // here we're creating a new select option with for each activity
 					opt.val(type_id);
					opt.text(type_name);
 					$('#OaBrandID').append(opt); //here we will append these new <span class="adtext" id="adtext_1">select options</span> to a dropdown 
 				});
 			}
 
 				});		
		}//if ends
	}
</script>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('user/permission_dtl/');?>">Permission Detail</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                
                     <div class="control-group <?php if(form_error('ObjectId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Object Id</label>
								<div class="controls">
                                <select name="ObjectId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php
									  foreach($ObjectDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OBJ_ID==$ObjectId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OBJ_ID;?>" selected="selected"><?php echo $list->OBJ_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OBJ_ID;?>" ><?php echo $list->OBJ_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('ObjectId'); ?>
									</span>
								</div>
					</div>
                    
                    
                     <div class="control-group <?php if(form_error('Obj_Attrbt_ID')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Object Attribute Id</label>
								<div class="controls">


							<select name="Obj_Attrbt_ID" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
								 foreach($ObjAttrbtDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OBJ_ATTRBT_ID==$Obj_Attrbt_ID)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OBJ_ATTRBT_ID;?>" selected="selected"><?php echo $list->OBJ_ATTRBT_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OBJ_ATTRBT_ID;?>" ><?php echo $list->OBJ_ATTRBT_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
									?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('Obj_Attrbt_ID'); ?>
									</span>
								</div>
							  </div>
                              
                              
                    <div class="control-group <?php if(form_error('OaId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Organisation Account</label>
								<div class="controls">
                                <select name="OaId" data-rel="chosen" onchange="orgAccFunc(this.value)">
                                <option value="">Select an option</option>
                                <?php
									  foreach($OrgAccDrop as $list)
									  {//start of foreach($OrgAccDrop as $list)
										  
									   if($list->OA_ID==$OaId)
									   {//start of ($list->OA_ID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_ID;?>" selected="selected"><?php echo $list->OA_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_ID;?>" ><?php echo $list->OA_NM;?></option><?php
									   }//end of ($list->OA_ID==$OaId)
									 }//end of foreach($OrgAccDrop as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('OaId'); ?>
									</span>
								</div>
							  </div>

                   
                   <div class="control-group <?php if(form_error('OaBrandId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Org Account Brand</label>
								<div class="controls">
							
							<select name="OaBrandId" id="OaBrandID" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($OrgBrandDrop as $list)
									  {//start of foreach($OrgBrandDrop as $list)
										  
									   if($list->OA_BRAND_ID==$OaBrandId)
									   {//start of ($list->OA_BRAND_ID==$OaBrandId)
										?>
                                        <option value="<?php echo $list->OA_BRAND_ID;?>" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
									   }//end of ($list->OA_BRAND_ID==$OaBrandId)
									 }//end of foreach($OrgBrandDrop as $list)
								 ?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('OaBrandId'); ?>
									</span>
								</div>
							  </div>
   
                   
                    <div class="control-group <?php if(form_error('UserId')) echo 'error';?>">
						<label class="control-label">User</label>
						<div class="controls">
							<select name="UserId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($UserDrop as $list)
									  {//start of foreach($UserDrop as $list)
										  
									   if($list->USER_ID==$User)
									   {//start of ($list->USER_ID==$UserId)
										?>
                                        <option value="<?php echo $list->USER_ID;?>" selected="selected"><?php echo $list->USER_NAME;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->USER_ID;?>" ><?php echo $list->USER_NAME;?></option><?php
									   }//end of ($list->USER_ID==$UserId)
									 }//end of foreach($UserDrop as $list)
								 ?>
                                </select>
							<span class="help-inline">
								<?php echo form_error('UserId');?>
							</span>
						</div>
					</div>
                    
                    
                   
<!-- end of form controls -->
                    
                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('entity/obj_attrbt_previleges');?>">
						<button type="button" class="btn">Cancel</button></a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>