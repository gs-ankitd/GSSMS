<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj_attrbt');?>">Entity Object Attribute</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> Entity Object Attribute Details</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
          					<li style=" list-style:none;">
                                <a class="ajax-link" href="<?php echo site_url('entity/entity_obj_attrbt/newEntityObjAttrbt');?>">
                                    <i class="icon-plus-sign"></i>
                                    <span class="hidden-tablet">  New Entity Object Attribute</span>
                                </a>
                            </li>
			<fieldset>
				
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<th>Object Attribute ID</th>
                        	<th>Object Attribute Name</th>
							<th>Object Attribute Display Name</th>
                            <th>Object Attribute Data Type</th>
                            <th>Object Size</th>
                            <th>Object Prcsn</th>
                             <th>Object Name</th>
                             <th>IsVisible</th>
   							<th>Actions</th>
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($entityObjAttrbt as $list) :?>
						<tr>
                        	<td class="center"><?php echo $list->Obj_Attrbt_ID; ?></td>
                        	<td class="center"><?php echo $list->Obj_Attrbt_Nm; ?></td>
							<td class="center"><?php echo $list->Obj_Attrbt_Dsply_Nm; ?></td>
                            <td class="center"><?php echo $list->Obj_Attrbt_Dt_Typ; ?></td>
                            <td class="center"><?php echo $list->Obj_Sz; ?></td>
                            <td class="center"><?php echo $list->Obj_Prcsn; ?></td>
                            <td class="center"><?php echo $list->Obj_Nm; ?></td>
                            <td class="center"><?php echo $list->Is_Visible; ?></td>
                            
                            
                            <td class="center ">
								<a class="btn btn-info" href="<?php echo site_url('entity/entity_obj_attrbt/editEntityObjAttrbt/'.$list->Obj_Attrbt_ID);?>">
									<i class="icon-edit icon-white"></i>  
									Edit                                            
								</a>
								<a class="btn btn-danger" href="<?php echo site_url('entity/entity_obj_attrbt/delete/'.$list->Obj_Attrbt_ID);?>">
									<i class="icon-trash icon-white"></i> 
									Delete
								</a>
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->