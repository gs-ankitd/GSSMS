<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj_attrbt');?>">Entity Object Attribute Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    
                    <!-- Start Of Form Controls   -->
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('id')) echo 'error';?>">
						<label class="control-label">Entity Obj Attrbt ID</label>
						<div class="controls">
							<input class="input-xlarge" id="id" name="id" type="text" value="<?php echo set_value('id',$id); ?>">
							<span class="help-inline">
								<?php echo form_error('id'); ?>
							</span>
                            
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjAttrbtNm')) echo 'error';?>">
						<label class="control-label">Object Attribute Name</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjAttrbtNm" name="ObjAttrbtNm" type="text" value="<?php echo set_value('ObjAttrbtNm',$ObjAttrbtNm); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjAttrbtNm'); ?>
							</span>
                            
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjAttrbtDsplyNm')) echo 'error';?>">
						<label class="control-label">Object Attribute Display Name</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjAttrbtDsplyNm" name="ObjAttrbtDsplyNm" type="text" value="<?php echo set_value('ObjAttrbtDsplyNm', $ObjAttrbtDsplyNm); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjAttrbtDsplyNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of div-->
					<div class="control-group <?php if(form_error('ObjAttrbtDtTyp')) echo 'error';?>">
						<label class="control-label">Object Attribute Data Type</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjAttrbtDtTyp" name="ObjAttrbtDtTyp" type="text" value="<?php echo set_value('ObjAttrbtDtTyp', $ObjAttrbtDtTyp); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjAttrbtDtTyp'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjSz')) echo 'error';?>">
						<label class="control-label">Object Size</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjSz" name="ObjSz" type="text" value="<?php echo set_value('ObjSz', $ObjSz); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjSz'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjPrcsn')) echo 'error';?>">
						<label class="control-label">Object Precission</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjPrcsn" name="ObjPrcsn" type="text" value="<?php echo set_value('ObjPrcsn', $ObjPrcsn); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjPrcsn'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                     <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjNm')) echo 'error';?>">
						<label class="control-label">Object Name</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjNm" name="ObjNm" type="text" value="<?php echo set_value('ObjNm', $ObjNm); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                     <!-- start of div-->
                    <div class="control-group <?php if(form_error('IsVisible')) echo 'error';?>">
						<label class="control-label">Is Visible</label>
						<div class="controls">
							<input class="input-xlarge" id="IsVisible" name="IsVisible" type="text" value="<?php echo set_value('IsVisible', $IsVisible); ?>">
							<span class="help-inline">
								<?php echo form_error('IsVisible'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    <!-- start of hidden inputs -->
                    <?php /*?><input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>"><?php */?>
                    <!-- end of hidden inputs -->

                    <!-- end Of Form Controls   -->      
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>