<!-- start of breadcrum-->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj_attrbt_mppng');?>">Entity Object Attribute Mapping Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- end of breadcrum-->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    
                    <!-- Start Of Form Controls   -->
                    
                  
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('ObjMppngId')) echo 'error';?>">
						<label class="control-label">Object Mapping ID</label>
						<div class="controls">
							<input class="input-xlarge" id="ObjMppngId" name="ObjMppngId" type="text" value="<?php echo set_value('ObjMppngId', $ObjMppngId); ?>">
							<span class="help-inline">
								<?php echo form_error('ObjMppngId'); ?>
							</span>
                           </div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('SrcObjNm')) echo 'error';?>">
						<label class="control-label">Source Object Name</label>
						<div class="controls">
							
							  <select name="SrcObjNm" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($objName as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ID==$SrcObjNm)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->OBJ_ID;?>" selected="selected"><?php echo $list->OBJ_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OBJ_ID;?>" ><?php echo $list->OBJ_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                       		</select>
                            <span class="help-inline">
								<?php echo form_error('SrcObjNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->

					<!-- start of div-->
                    <div class="control-group <?php if(form_error('TrgObjNm')) echo 'error';?>">
						<label class="control-label">Target Object Name </label>
						<div class="controls">
							
							 <select name="TrgObjNm" data-rel="chosen">
                                <option value="">Select an option</option>
                                 <?php foreach($objName as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ID==$TrgObjNm)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->OBJ_ID;?>" selected="selected"><?php echo $list->OBJ_NM;?></option>
                                  <?php
                                          }
                                          else
                                         {
                                  ?>
                                              <option value="<?php echo $list->OBJ_ID;?>" ><?php echo $list->OBJ_NM;?></option>
								  <?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                       		</select>
                            <span class="help-inline">
								<?php echo form_error('TrgObjNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('SrcObjAttrbtNm')) echo 'error';?>">
						<label class="control-label">Source Object Attribute Name</label>
						<div class="controls">
                            <select name="SrcObjAttrbtNm" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($objAttrbtName as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ATTRBT_ID==$SrcObjAttrbtNm)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->OBJ_ATTRBT_ID;?>" selected="selected"><?php echo $list->OBJ_ATTRBT_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OBJ_ATTRBT_ID;?>" ><?php echo $list->OBJ_ATTRBT_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                       		</select>
							<span class="help-inline">
								<?php echo form_error('SrcObjAttrbtNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of div-->
                    <div class="control-group <?php if(form_error('TrgObjAttrbtNm')) echo 'error';?>">
						<label class="control-label">Target Object Attribute Name</label>
						<div class="controls">
                            <select name="TrgObjAttrbtNm" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($objAttrbtName as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->OBJ_ATTRBT_ID==$TrgObjAttrbtNm)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->OBJ_ATTRBT_ID;?>" selected="selected"><?php echo $list->OBJ_ATTRBT_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OBJ_ATTRBT_ID;?>" ><?php echo $list->OBJ_ATTRBT_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                       		</select>
							<span class="help-inline">
								<?php echo form_error('TrgObjAttrbtNm'); ?>
							</span>
						</div>
					</div>
                    <!-- end of div-->
                    
                    <!-- start of hidden inputs -->
                   <input class="input-xlarge" id="id" name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->

                    
                    <!-- end Of Form Controls   -->
				    <div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('entity/entity_obj_attrbt_mppng','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>