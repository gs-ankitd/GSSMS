<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('entity/entity_obj');?>">
Entity Object</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                     
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Obj_Typ')) echo 'error';?>">
						<label class="control-label">Object Type</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Typ" name="Obj_Typ" type="text" value="<?php echo set_value('Obj_Typ', $obj_typ); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Typ'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('Obj_Nm')) echo 'error';?>">
						<label class="control-label">Object Name</label>
						<div class="controls">
							<input class="input-xlarge" id="Obj_Nm" name="Obj_Nm" type="text" value="<?php echo set_value('Obj_Nm', $obj_nm); ?>">
							<span class="help-inline">
								<?php echo form_error('Obj_Nm'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end Of Form Controls   -->        
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <?php echo anchor('entity/entity_obj','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>