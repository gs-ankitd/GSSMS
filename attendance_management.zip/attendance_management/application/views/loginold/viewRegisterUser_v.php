<!-- Start of Breadcrumb -->

<?php $this->load->view('include/login_header'); ?>


<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
	         <!--- Start of first Form Register User ----> 
 			<form action="" method="post" id="userregistration_form" style="display:none">
			 <div class="top_b">User Registration</div>
			  <div class="cnt_b">
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-user"></i></span><input type="text" id="username" name="username" value="" placeholder="Username"  oncopy="return false;" onpaste="return false;" oncut="return false;" />
				</div>
			   </div>
			   <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="reg_password" name="reg_password" placeholder="Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  value="" />
				</div>
               </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="con_password" name="con_password" placeholder="Confirm Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  value="" />
				</div>
               </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on">@</span><input name="email_address" id="email_address" type="text" placeholder="Your email id" value="" />
				</div>
			   </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on">@</span><input type="text" name="organisation" id="organisation" placeholder="organisation Code" oncopy="return false;" onpaste="return false;" oncut="return false;"   value="" />
				</div>
			   </div>
               <div class="formRow">
				<div class="input-prepend">
                 <span class="link_reg" style="margin-left:45px;"><a href="#org_form">Set Up a New Organisation Code</a></span>
				</div>
		       </div>
              </div>
              <div class="btm_b clearfix">
			   <input name="submit" type="submit" value="Create an Account" style="margin-left:95px; margin-top:0px;" /><br><br>
                <span class="link_reg" style="margin-left:60px;">Never mind, <a href="#login_form">send me back to the sign-in screen</a></span>
			  </div>         
              <div class="links_b links_btm clearfix"></div>

             </form>
             
             <!---- End of first form Register User ---->   
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           

             
<?php $this->load->view('include/login_footer'); ?>                