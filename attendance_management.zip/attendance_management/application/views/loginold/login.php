<?php //$this->load->view('include/login_header'); ?>

		
		   
			 <form method="post" id="login_form" name="login_form" action="">
			  <div class="top_b">Welcome to MyDMS</div>  
	           <div class="alert alert-info alert-login">
					Sign in to MyDMS.
			   </div>
               
			   <div class="cnt_b">
                <div class="formRow">
				 <div class="input-prepend">
                  <span class="add-on"><i class="icon-user"></i></span><input type="text" id="username" name="username" placeholder="Username" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
				 </div>
					</div>
				<div class="formRow">
				 <div class="input-prepend">
				  <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="password" name="password" placeholder="Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
				 </div>
				</div>
					
                  
				</div>
				<div class="btm_b clearfix">
                 <span class="link_reg"><a href="<?php  echo site_url('login/org_accounts/index')  ?>">Not registered? Sign up here</a></span>
               
                 <span class="link_reg"><a href="#forgotpassword_form">Forgot Your Password</a></span>
			
                  <?php
			
				    echo form_submit('submit', 'Login');
					 
			      ?>
          
         
				</div>
				
		  </form>
		    
            
            
<?php //$this->load->view('include/login_footer'); ?>            