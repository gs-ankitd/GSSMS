<!-- Start of Breadcrumb -->

<?php $this->load->view('include/login_header'); ?>
 
<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
	         <!--- Start of first Form Forgot Password ----> 
  
 
               <form action="" method="post" id="forgotpassword_form" name="forgotpassword_form" style="display:none">
                <div class="top_b">Can't sign in?</div>    
                <div class="alert alert-info alert-login">
                      Please enter your registered email id. You will receive a link to reset password via email.
                </div>
                <div class="cnt_b">
                <div class="formRow clearfix">
                 <div class="input-prepend"><span class="add-on">@</span>
                  <span id="sprytextfield1">
                   <label for="txtusername"></label>
                   <input type="text" name="txtusername" id="txtusername" placeholder="Your email id" style="margin-top:-5px;" />
                   <span class="textfieldRequiredMsg" style="border:0px;">A value is required.</span>
                   <span class="textfieldInvalidFormatMsg"  style="border:0px;">Invalid format.</span>
                  </span> 
                 </div>
                </div>
               </div>
               <div class="btm_b tac">
                <button class="btn btn-inverse" type="submit">Request New Password</button><br><br>
                <span class="link_reg" >Never mind, <a href="#login_form">send me back to the sign-in screen</a></span>
               </div>         
               <div class="links_b links_btm clearfix"></div>
              </form>
              
              <!---- End of first form Forgot Password ---->   
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           

              
<?php $this->load->view('include/login_footer'); ?>   
               
                