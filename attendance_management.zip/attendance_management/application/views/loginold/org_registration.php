<?php $this->load->view('include/login_header'); ?>          
          
          
            <form action="" method="post" id="org_account_setup">
             <div class="top_b">Sign up to MyDMS</div>
              <div class="cnt_b">
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on"><i class="icon-user"></i></span><input type="text" id="org_code" name="org_code"  placeholder="Organisation Code" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
                </div>
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on"><i class="icon-user"></i></span><input type="text" id="org_name" name="org_name"  placeholder="Organisation Name" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
                </div>
               </div>
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on"><i class="icon-lock"></i></span><input type="text" id="org_email" name="org_email" placeholder="Email Address"  />
                </div>
               </div>
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on"><i class="icon-lock"></i></span><input type="text" id="org_address" name="org_address" placeholder="Address" oncopy="return false;" onpaste="return false;" oncut="return false;"   />
                </div>
               </div>
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on">@</span><input name="org_contact_no" id="org_contact_no" type="text" placeholder="Contact No"  oncopy="return false;" onpaste="return false;" oncut="return false;"  />
                </div>
               </div>
               <div class="formRow">
                <div class="input-prepend">
                 <span class="add-on">@</span><input name="org_web_domain" id="web_domain" type="url" placeholder="http://www.yourwebsite.com" rel='imgtip[0]' />
                </div>
               </div>
                                
              </div>
              <div class="btm_b clearfix"  style="width:339px; margin-left:-63px; margin-top:15px; margin-bottom:-15px;">
               <input name="submit" type="submit" value="Create an Organisation" style="margin-left:95px; margin-top:0px;" /><br><br>
                <span class="link_reg" style="margin-left:50px;">Never mind, <a href="#reg_form">send me back to the Registration screen</a></span>
                <span class="link_reg" style="margin-left:62px;">Never mind, <a href="#login_form">send me back to the sign-in screen</a></span>
              </div>         
              <div class="links_b links_btm clearfix"> </div>
             </form>
             
             
             
<?php $this->load->view('include/login_footer'); ?>                