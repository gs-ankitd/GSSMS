<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/application_dtl');?>">Application Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
				
                    
                    <!-- Start Of Form Controls   -->
                 
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('App_ID')) echo 'error';?>">
						<label class="control-label">App ID</label>
						<div class="controls">
							
                              <select name="App_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($appIdDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->MSTR_ID==$App_ID)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
							<span class="help-inline">
								<?php echo form_error('App_ID'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('Function_ID')) echo 'error';?>">
						<label class="control-label">Module</label>
						<div class="controls">
							
                            
                             <select name="Function_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($moduleIdDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->MSTR_ID==$Function_ID)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
							<span class="help-inline">
								<?php echo form_error('Function_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Epic_ID')) echo 'error';?>">
						<label class="control-label">Epic ID</label>
						<div class="controls">
							
							<select name="Epic_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($epicIdDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->MSTR_ID==$Epic_ID)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
                            <span class="help-inline">
								<?php echo form_error('Epic_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Feature_ID')) echo 'error';?>">
						<label class="control-label">Feature ID</label>
						<div class="controls">
						
                            <select name="Feature_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($featureIdDropDown as $list){//start of foreach($ObjMppngDrop as $list)
                                        if($list->MSTR_ID==$Feature_ID)
                                          {//start of if($list->Obj_ID==$SrcobjId)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->Obj_ID==$SrcobjId)
                                      }//end of foreach($ObjMppngDrop as $list)
                                  ?>
                        </select>
							<span class="help-inline">
								<?php echo form_error('Feature_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Optional_Theme_ID')) echo 'error';?>">
						<label class="control-label">Optional Theme ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Optional_Theme_ID" name="Optional_Theme_ID" type="text" value="<?php echo set_value('Optional_Theme_ID', $Optional_Theme_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('Optional_Theme_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Enabled')) echo 'error';?>">
						<label class="control-label">Enabled</label>
						<div class="controls">
							
							
                            <?php  if(($Enabled)==1){ ?>
           					 <input type="checkbox" name="Enabled" id="Enabled"   checked="checked">
                      		<?php }else {?>
                       		 <input type="checkbox" name="Enabled" id="Enabled"  ><?php } ?>
                            <span class="help-inline">
								<?php echo form_error('Enabled'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                     <!-- start of hidden inputs -->
                    <!--<input name="id" type="hidden" value="<?php // echo set_value('id', $id); ?>"> -->
                    
                    
                             
                   
							<input class="input-xlarge" id="App_Detail_ID" name="App_Detail_ID" type="hidden" value="<?php echo set_value('App_Detail_ID', $App_Detail_ID);?>">
						
				
              
                    <!-- end of hidden inputs -->

                    <!-- end Of Form Controls   -->       
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('hrchyMngt/application_dtl','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>