<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/relationship_dtl');?>">Relationship Details</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Relationship Details</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
         <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('hrchyMngt/relationship_dtl/addRelationshipDetails/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
			<fieldset>
            	
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
						<tr>
                          <?php if (validateColVisibility('RelDetID',$visibleCol)) {?>
                        	<th>Relationship Details ID</th>
                          <?php } ?>  
                          <?php if (validateColVisibility('ChildID',$visibleCol)) {?>	
                            <th>Child ID</th>
						  <?php } ?>
						  <?php if (validateColVisibility('ParentID',$visibleCol)) {?>
                            <th>Parent ID</th>
                          <?php } ?>
						  <?php if (validateColVisibility('OA_ID',$visibleCol)) {?>  
							<th>OA ID</th>
                          <?php } ?>
						  <?php if (validateColVisibility('EntityID',$visibleCol)) {?>
                            <th>Entity ID</th>
                          <?php } ?>
						  <?php if (validateColVisibility('IsDeleted',$visibleCol)) {?>
                            <th>Is Deleted</th>
                          <?php } ?>
						  <?php if (validateColVisibility('CreatedBy',$visibleCol)) {?>
                            <th>Created By</th>
                          <?php } ?>
						  <?php if (validateColVisibility('UpdatedBy',$visibleCol)) {?>
                            <th>Updated By</th>
                          <?php } ?>
						  <?php if (validateColVisibility('CreatedOn',$visibleCol)) {?>
                            <th>Created On</th>
                          <?php } ?>
						  <?php if (validateColVisibility('UpdatedOn',$visibleCol)) {?>
                            <th>Updated On</th>  
                          <?php } ?>
                            <th>Actions</th>
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
                    	<?php foreach($lva_relationshipDetails as $row) :?>
						<tr>
                           <?php if (validateColVisibility('RelDetID',$visibleCol)) {?>
                        	<td class="center"><?php echo $row->RelDetID; ?></td>
                           <?php } ?>
                           <?php if (validateColVisibility('ChildID',$visibleCol)) {?> 
                        	<td class="center"><?php echo $row->ChildID; ?></td>
                           <?php } ?>
                           <?php if (validateColVisibility('ParentID',$visibleCol)) {?> 
							<td class="center"><?php echo $row->ParentID; ?></td>
                           <?php } ?> 
                           <?php if (validateColVisibility('OA_ID',$visibleCol)) {?>
                            <td class="center"><?php echo $row->OA_ID; ?></td>
						   <?php } ?>
                           <?php if (validateColVisibility('EntityID',$visibleCol)) {?>
                            <td class="center"><?php echo $row->EntityID; ?></td>
                           <?php } ?>
                           <?php if (validateColVisibility('IsDeleted',$visibleCol)) {?>
                            <td class="center"><?php echo $row->IsDeleted; ?></td>
                           <?php } ?>
						  <?php if (validateColVisibility('CreatedBy',$visibleCol)) {?>
                            <td class="center"><?php echo $row->CreatedBy; ?></td>
                          <?php } ?>
						  <?php if (validateColVisibility('UpdatedBy',$visibleCol)) {?>
                            <td class="center"><?php echo $row->UpdatedBy; ?></td>
                          <?php } ?>
						  <?php if (validateColVisibility('CreatedOn',$visibleCol)) {?>
                            <td class="center"><?php echo $row->CreatedOn; ?></td>
                          <?php } ?>
						  <?php if (validateColVisibility('UpdatedOn',$visibleCol)) {?>
                            <td class="center"><?php echo $row->UpdatedOn; ?></td>  
                          <?php } ?>
                            <td class="center ">
								<a href="<?php echo site_url('hrchyMngt/relationship_dtl/editRelationshipDetails/'.$row->RelDetID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
									
								<a href="<?php echo site_url('hrchyMngt/relationship_dtl/delete/'.$row->RelDetID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
									
							</td>
                      	</tr>	
                        <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->