<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/hier_lvl_config');?>">Hier Level Config</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Hier Level Config</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
        
			<fieldset>
				
           <a href="<?php echo site_url('hrchyMngt/hier_lvl_config/newHeirLevelConfig');?>"> <button   type="submit" class="btn btn-primary" >ADD</button></a>

				<table class="table table-striped table-bordered bootstrap-datatable datatable" >
              
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<th>HIER_TYPE_ID</th>
                            <th>HIER_TYPE_ENTITY_ID</th>
                        	<th>LEVEL_SEQ</th>
							<th>OA_ID</th>
							<th>OA_BRAND_ID</th>
                           
                          
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
        <tbody>
            <?php foreach($heir as $heirs) :?>
            <tr>
                <td class="center"><?php echo $heirs->HIER_TYPE_ID; ?></td>
                <td class="center"><?php echo $heirs->HIER_TYPE_ENTITY_ID; ?></td>
                <td class="center"><?php echo $heirs->LEVEL_SEQ;?></td>
                <td class="center"><?php echo $heirs->OA_ID;?></td>
                <td class="center"><?php echo $heirs->OA_BRAND_ID;?></td>


                <td class="center ">
                    <a class="btn btn-info" href="<?php echo site_url('hrchyMngt/hier_lvl_config/editHeirLevelConfig/'.$heirs->HIER_LEVEL_CONFIG_ID);?>">
                        <i class="icon-edit icon-white"></i>  
                        Edit                                            
                    </a>
                    <a class="btn btn-danger" href="<?php echo site_url('hrchyMngt/hier_lvl_config/delete/'.$heirs->HIER_LEVEL_CONFIG_ID);?>">
                        <i class="icon-trash icon-white"></i> 
                        Delete
                    </a>
                </td>
            </tr>	
            <?php endforeach; ?>						
        </tbody>
                    <!-- End of table body -->
				</table> 
                

                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->