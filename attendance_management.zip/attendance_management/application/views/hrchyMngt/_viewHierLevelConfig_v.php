
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/heir_lvl_config');?>">Hier Level Config</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
<!-- start of form controls -->
					<div class="control-group <?php if(form_error('HierTypeId')) echo 'error';?>">
						<label class="control-label">Hier Type Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="HierTypeId" type="text" value="<?php echo set_value('HierTypeId', $HierTypeId); ?>">
							<span class="help-inline">
								<?php echo form_error('HierTypeId'); ?>
							</span>
                           
						</div>
					</div>

					<div class="control-group <?php if(form_error('HierTypeEntityId')) echo 'error';?>">
						<label class="control-label">Hier Type Entity Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="HierTypeEntityId" type="text" value="<?php echo set_value('HierTypeEntityId', $HierTypeEntityId); ?>">
							<span class="help-inline">
								<?php echo form_error('HierTypeEntityId'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('LevelSeq')) echo 'error';?>">
						<label class="control-label">Level Seq</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="LevelSeq" type="text" value="<?php echo set_value('LevelSeq', $LevelSeq); ?>">
							<span class="help-inline">
								<?php echo form_error('LevelSeq'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('OaId')) echo 'error';?>">
						<label class="control-label">Oa Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaId" type="text" value="<?php echo set_value('OaId', $OaId); ?>">
							<span class="help-inline">
								<?php echo form_error('OaId'); ?>
							</span>
						</div>
					</div>
                     <div class="control-group <?php if(form_error('OaBrandID')) echo 'error';?>">
						<label class="control-label">Oa Brand ID</label>
						<div class="controls">
						<input class="input-xlarge" id="name" name="OaBrandID" type="text" value="<?php echo set_value('OaBrandID', $OaBrandID); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandID'); ?>
							</span>
						</div>
					</div>
<!-- end of form controls -->
                    
                 
                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>