<script>
	function hierFunc(typeId){
		//alert(typeId);
		if(typeId){//if there is a typeId pressed and has a value
		
		$.ajax({
			url:"<?php echo site_url('hrchyMngt/hier_lvl_config/ajaxLive/').'/';?>"+typeId, //here we are calling our user controller 
 			success: function(typeDropdown) //we're calling the response json array 'activities'
 			{
				 $("#HierTypeEntityId > option").remove(); //first of all clear select items
 				$.each(typeDropdown,function(type_id,type_name) //here we're doing a foeach loop round each activity with id as the key and activity as the value
 				{
 					 opt = $('<option />'); // here we're creating a new select option with for each activity
 					opt.val(type_id);
					opt.text(type_name);
 					$('#HierTypeEntityId').append(opt); //here we will append these new <span class="adtext" id="adtext_1">select options</span> to a dropdown 
 				});
 			}
 
 				});

		
		}//if ends
	}
	
	function orgAccFunc(typeId){
		//alert(typeId);
		if(typeId){//if there is a typeId pressed and has a value
		
		$.ajax({
			url:"<?php echo site_url('hrchyMngt/hier_lvl_config/ajaxOrgLive/').'/';?>"+typeId, //here we are calling our user controller 
 			success: function(typeDropdown) //we're calling the response json array 'activities'
 			{
				 $("#OaBrandID > option").remove(); //first of all clear select items
				
 				$.each(typeDropdown,function(type_id,type_name) //here we're doing a foeach loop round each activity with id as the key and activity as the value
 				{
 					 opt = $('<option />'); // here we're creating a new select option with for each activity
 					opt.val(type_id);
					opt.text(type_name);
 					$('#OaBrandID').append(opt); //here we will append these new <span class="adtext" id="adtext_1">select options</span> to a dropdown 
 				});
 			}
 
 				});		
		}//if ends
	}
</script>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/hier_lvl_config/');?>">Hier Level Config</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <div class="control-group <?php if(form_error('HierTypeId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Hier Type Id</label>
								<div class="controls">
                                <select name="HierTypeId" data-rel="chosen" onchange="hierFunc(this.value)">
                                <option value="">Select an option</option>
                                <?php
									  foreach($typename as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->TYP_ID==$HierTypeId)
									   {//start of ($list->TypeID==$HierTypeId)
										?>
                                        <option value="<?php echo $list->TYP_ID;?>" disabled="disabled" selected="selected"><?php echo $list->TYP_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
									   }//end of ($list->MasterID==$HierTypeId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('HierTypeId'); ?>
									</span>
								</div>
							  </div>


                    
                    
                    <div class="control-group <?php if(form_error('HierChildEntityTypId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Hier Child Entity Typ Id</label>
								<div class="controls">    
								<select name="HierChildEntityTypId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($HierTypeDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->TYP_ID==$HierChildEntityTypId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->TYP_ID;?>" disabled="disabled" selected="selected"><?php echo $list->TYP_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
								?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('HierChildEntityTypId'); ?>
									</span>
								</div>
							  </div>

					
                    <div class="control-group <?php if(form_error('HierParentEntityTypId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Hier Parent Entity Typ Id</label>
								<div class="controls">
								<select name="HierParentEntityTypId" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
									  foreach($HierTypeDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->TYP_ID==$HierParentEntityTypId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->TYP_ID;?>" disabled="disabled" selected="selected"><?php echo $list->TYP_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
								?>
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('HierParentEntityTypId'); ?>
									</span>
								</div>
							  </div>

                    
                    <div class="control-group <?php if(form_error('LevelSeq')) echo 'error';?>">
						<label class="control-label">Level Seq</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="LevelSeq" type="text" value="<?php echo set_value('LevelSeq', $LevelSeq); ?>">
							<span class="help-inline">
								<?php echo form_error('LevelSeq'); ?>
							</span>
						</div>
					</div>
                    

                    <div class="control-group <?php if(form_error('OaId')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Oa Id</label>
								<div class="controls">
                                <select name="OaId" data-rel="chosen" onchange="orgAccFunc(this.value)">
                                <option value="">Select an option</option>
                                <?php
									  foreach($organisationDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_ID==$OaId)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_ID;?>" disabled="disabled" selected="selected"><?php echo $list->OA_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_ID;?>" ><?php echo $list->OA_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
                                  ?>
								 
     							</select>
                                	<span class="help-inline">
										<?php echo form_error('OaId'); ?>
									</span>
								</div>
					</div>
                    
                    

                    
                     <div class="control-group <?php if(form_error('OaBrandID')) echo 'error';?>" id="parentID">
								<label class="control-label" for="focusedInput">Oa Brand ID</label>
								<div class="controls">
                        
							<select name="OaBrandID" data-rel="chosen" >
                                <option value="">Select an option</option>
                                <?php 
								 foreach($orgBrandsDrop as $list)
									  {//start of foreach($typename as $list)
										  
									   if($list->OA_BRAND_ID==$OaBrandID)
									   {//start of ($list->TypeID==$OaId)
										?>
                                        <option value="<?php echo $list->OA_BRAND_ID;?>" disabled="disabled" selected="selected"><?php echo $list->OA_BRAND_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->OA_BRAND_ID;?>" ><?php echo $list->OA_BRAND_NM;?></option><?php
									   }//end of ($list->MasterID==$OaId)
									 }//end of foreach($typename as $list)
								?>
							
                                </select>
                                	<span class="help-inline">
										<?php echo form_error('OaBrandID'); ?>
									</span>
								</div>
							  </div>
					
					
					<div class="control-group  <?php //if(form_error('IsEditable'))  echo 'error'; ?>">
					<label class="control-label" for="focusedInput">IS EDITABLE</label>
					<div class="controls">
						<?php  if(($IsEditable)==1){ ?>
						 <input type="checkbox" name="IsEditable" id="IsEditable"   checked="checked">
						<?php }else {?>

						<input type="checkbox" name="IsEditable" id="IsEditable"  ><?php } ?>
  <!--<input type="checkbox" name="IsEditable" id="IsEditable" value="<?php //if(isset($IsEditable)) echo $inactive; else echo set_value('IsEditable');?>" >--> 
							<span class="help-inline">
                            <?php //echo form_error('IsEditable'); ?>
							</span>  
					</div>
					</div>	


					<div class="control-group  <?php //if(form_error('IsPredefined'))  echo 'error'; ?>">
					<label class="control-label" for="focusedInput">IS PREDEFINED</label>
					<div class="controls">
						<?php  if(($IsPredefined)==1){ ?>
						 <input type="checkbox" name="IsPredefined" id="IsPredefined"   checked="checked">
						<?php }else {?>

						<input type="checkbox" name="IsPredefined" id="IsPredefined"  ><?php } ?>
  <!--<input type="checkbox" name="IsPredefined" id="IsPredefined" value="<?php //if(isset(IsPredefined)) echo $IsPredefined; else echo set_value('IsPredefined');?>" >--> 
							<span class="help-inline">
                            <?php //echo form_error('IsPredefined'); ?>
							</span>  
					</div>
					</div>
 
<!-- end of form controls -->
                    
                 
                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('hrchyMngt/hier_lvl_config/');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>