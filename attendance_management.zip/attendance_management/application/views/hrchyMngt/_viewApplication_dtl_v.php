<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/appliction_dtl');?>">
Application Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					<legend><?php echo $title;?></legend>
                    
                    <!-- Start Of Form Controls   -->
                     <!--start Of div-->                    
                    <div class="control-group <?php if(form_error('App_Detail_ID')) echo 'error';?>">
						<label class="control-label">Application Details ID</label>
						<div class="controls">
							<input class="input-xlarge" id="App_Detail_ID" name="App_Detail_ID" type="text" value="<?php echo set_value('App_Detail_ID',$App_Detail_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('App_Detail_ID'); ?>
							</span>
                            <p class="help-block">
                            	<!--Like, GEE01-->
							</p>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('App_ID')) echo 'error';?>">
						<label class="control-label">App ID</label>
						<div class="controls">
							<input class="input-xlarge" id="App_ID" name="App_ID" type="text" value="<?php echo set_value('App_ID', $App_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('App_ID'); ?>
							</span>
						</div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					<div class="control-group <?php if(form_error('Function_ID')) echo 'error';?>">
						<label class="control-label">Function ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Function_ID" name="Function_ID" type="text" value="<?php echo set_value('Function_ID', $Function_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('Function_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Epic_ID')) echo 'error';?>">
						<label class="control-label">Epic ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Epic_ID" name="Epic_ID" type="text" value="<?php echo set_value('Epic_ID', $Epic_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('Epic_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Feature_ID')) echo 'error';?>">
						<label class="control-label">Feature ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Feature_ID" name="Feature_ID" type="text" value="<?php echo set_value('Feature_ID', $Feature_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('Feature_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Optional_Theme_ID')) echo 'error';?>">
						<label class="control-label">Optional Theme ID</label>
						<div class="controls">
							<input class="input-xlarge" id="Optional_Theme_ID" name="Optional_Theme_ID" type="text" value="<?php echo set_value('Optional_Theme_ID', $Optional_Theme_ID); ?>">
							<span class="help-inline">
								<?php echo form_error('Optional_Theme_ID'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('Enabled')) echo 'error';?>">
						<label class="control-label">Enabled</label>
						<div class="controls">
							<input class="input-xlarge" id="Enabled" name="Enabled" type="text" value="<?php echo set_value('Enabled', $Enabled); ?>">
							<span class="help-inline">
								<?php echo form_error('Enabled'); ?>
							</span>
						</div>
					</div>
                    <!--end Of div-->
                    
                     <!-- start of hidden inputs -->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->

                    <!-- end Of Form Controls   -->       
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>