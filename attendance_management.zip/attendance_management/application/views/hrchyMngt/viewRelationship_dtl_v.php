<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('hrchyMngt/relationship_dtl');?>">
Relationship Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
                    
                    <!-- Start Of Form Controls   -->
                    
                    <!--start Of div-->
                    
                    <div class="control-group <?php if(form_error('ChildID')) echo 'error';?>">
						<label class="control-label">Child ID</label>
						<div class="controls">
                        <select name="ChildID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($masterNameDropDown as $list){//start of foreach($RelDtl1Drop as $list)
                                        if($list->MSTR_ID==$ChildID)
                                          {//start of if($list->MasterID==$ChildID)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->MasterID==$ChildID)
                                      }//end of foreach($RelDtl1Drop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
					<!--end Of div-->
                    
                    <!--start Of div-->
					
                    <div class="control-group <?php if(form_error('ParentID')) echo 'error';?>">
						<label class="control-label">Parent ID</label>
						<div class="controls">
                        <select name="ParentID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($masterNameDropDown as $list){//start of foreach($RelDtl1Drop as $list)
                                        if($list->MSTR_ID==$ParentID)
                                          {//start of if($list->MasterID==$ParentID)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->MasterID==$ParentID)
                                      }//end of foreach($RelDtl1Drop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
                    <!--end Of div-->
                    <!--start Of div-->
                    <div class="control-group <?php if(form_error('OA_ID')) echo 'error';?>">
						<label class="control-label">OA ID</label>
						<div class="controls">
                        <select name="OA_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($RelDtl2Drop as $list){//start of foreach($RelDtl2Drop as $list)
                                        if($list->OA_ID==$OA_ID)
                                          {//start of if($list->OA_ID==$OA_ID)  ?>
                                              <option value="<?php echo $list->OA_ID;?>" selected="selected"><?php echo $list->OA_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->OA_ID;?>" ><?php echo $list->OA_NM;?></option><?php
                                         }//end of if($list->OA_ID==$OA_ID)
                                      }//end of foreach($RelDtl2Drop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
                    <!--end Of div-->
                    
                    <!--start Of div-->
                    
                    <div class="control-group <?php if(form_error('EntityID')) echo 'error';?>">
						<label class="control-label">Entity ID</label>
						<div class="controls">
                        <select name="EntityID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php foreach($RelDtl1Drop as $list){//start of foreach($RelDtl1Drop as $list)
                                        if($list->MasterID==$EntityID)
                                          {//start of if($list->MasterID==$EntityID)  ?>
                                              <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                                             <?php
                                          }
                                          else
                                         {
                                              ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                                         }//end of if($list->MasterID==$EntityID)
                                      }//end of foreach($RelDtl1Drop as $list)
                                  ?>
                        </select>
                        </div>
					</div>
                    <!--end Of div-->
                    
                 
                    
                     <!-- start of hidden inputs -->
                    <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
 
                    <!-- end Of Form Controls   -->        
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
                        <a href="<?php echo site_url('hrchyMngt/relationship_dtl');?>">
						<button type="button" class="btn">Cancel</button>
                        </a>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>