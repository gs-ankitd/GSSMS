<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/oa_brands');?>">Oa Brands</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i>Oa Brands</h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
           <li style=" list-style:none;">
                                <a class="ajax-link" href="<?php echo site_url('systmMngt/oa_brands/newOaBrands');?>">
                                    <i class="icon-plus-sign"></i>
                                    <span class="hidden-tablet"> New OA Brand</span>
                                </a>
                            </li>   
			<fieldset>
			
             <legend></legend>
				<table class="table table-striped table-bordered bootstrap-datatable datatable" >
              
                	<!-- Start of table head -->
					<thead>
						<tr>
                        	<th>OA_BRAND_CD</th>
                            <th>OA_BRAND_NM</th>
                        	<th>OA_ID</th>
							<th>REF_ID</th>
							<th>OA_BRAND_LOGO</th>
                            <th>OA_BRAND_INV_TMPLT</th>
						</tr>
					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
        <tbody>
            <?php foreach($oabrand as $oabrands) :?>
            <tr>
            <?php
//var_dump($visi);
if(validateColVisibility('OA_BRAND_CD',$visi))
{
?>
                <td class="center"><?php echo $oabrands->OA_BRAND_CD; ?></td>
                
   <?php } ?>
                <td class="center"><?php echo $oabrands->OA_BRAND_NM; ?></td>
                <td class="center"><?php echo $oabrands->OA_ID;?></td>
                <td class="center"><?php echo $oabrands->REF_ID; ?></td>
                <td class="center"><?php echo $oabrands->OA_BRAND_LOGO; ?></td>
                <td class="center"><?php echo $oabrands->OA_BRAND_INV_TMPLT; ?></td>
                <td class="center ">
                    <a class="btn btn-info" href="<?php echo site_url('systmMngt/oa_brands/editOaBrands/'.$oabrands->OA_BRAND_ID);?>">
                        <i class="icon-edit icon-white"></i>  
                        Edit                                            
                    </a>
                    <a class="btn btn-danger" href="<?php echo site_url('systmMngt/oa_brands/delete/'.$oabrands->OA_BRAND_ID);?>">
                        <i class="icon-trash icon-white"></i> 
                        Delete
                    </a>
                </td>
            </tr>	
            <?php endforeach; ?>						
        </tbody>
                    <!-- End of table body -->
				</table> 
                

                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<!-- End of main body -->