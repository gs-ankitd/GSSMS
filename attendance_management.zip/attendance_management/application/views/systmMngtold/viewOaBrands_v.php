<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/oa_brands');?>">Oa Brands </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>

<!-- start of form controls -->                    
					<div class="control-group <?php if(form_error('OaBrandCd')) echo 'error';?>">
						<label class="control-label">OA BRAND CD</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaBrandCd" type="text" value="<?php echo set_value('OaBrandCd', $OaBrandCd); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandCd'); ?>
							</span>
                           
						</div>
					</div>

					<div class="control-group <?php if(form_error('OaBrandNm')) echo 'error';?>">
						<label class="control-label">Oa Brand Nm</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaBrandNm" type="text" value="<?php echo set_value('OaBrandNm', $OaBrandNm); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandNm'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('OaId')) echo 'error';?>">
						<label class="control-label">Oa Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaId" type="text" value="<?php echo set_value('OaId', $OaId); ?>">
							<span class="help-inline">
								<?php echo form_error('OaId'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('RefId')) echo 'error';?>">
						<label class="control-label">Ref Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="RefId" type="text" value="<?php echo set_value('RefId', $RefId); ?>">
							<span class="help-inline">
								<?php echo form_error('RefId'); ?>
							</span>
						</div>
					</div>
                    <div class="control-group <?php if(form_error('OaBrandLogo')) echo 'error';?>">
						<label class="control-label">Oa Brand Logo</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaBrandLogo" type="text" value="<?php echo set_value('OaBrandLogo', $OaBrandLogo); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandLogo'); ?>
							</span>
						</div>
					</div>
                     <div class="control-group <?php if(form_error('OaBrandInvTmplt')) echo 'error';?>">
						<label class="control-label">Oa Brand Inv Tmplt</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaBrandInvTmplt" type="text" value="<?php echo set_value('OaBrandInvTmplt', $OaBrandInvTmplt); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandInvTmplt'); ?>
							</span>
						</div>
					</div>
<!-- end of form controls -->

                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>