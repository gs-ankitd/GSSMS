<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/org_accounts');?>">Oa Accounts </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>

<!-- start of form controls -->                    
					<div class="control-group <?php if(form_error('oaCd')) echo 'error';?>">
						<label class="control-label">OA CD</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="oaCd" type="text" value="<?php echo set_value('oaCd', $oaCd); ?>">
							<span class="help-inline">
								<?php echo form_error('oaCd'); ?>
							</span>
                           
						</div>
					</div>

					<div class="control-group <?php if(form_error('oaName')) echo 'error';?>">
						<label class="control-label">Oa Name</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="oaName" type="text" value="<?php echo set_value('oaName', $oaName); ?>">
							<span class="help-inline">
								<?php echo form_error('oaName'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('oaEmail')) echo 'error';?>">
						<label class="control-label">Oa Email</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="oaEmail" type="text" value="<?php echo set_value('oaEmail', $oaEmail); ?>">
							<span class="help-inline">
								<?php echo form_error('oaEmail'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('oaWebDomain')) echo 'error';?>">
						<label class="control-label">Oa WebDomain</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="oaWebDomain" type="text" value="<?php echo set_value('oaWebDomain', $oaWebDomain); ?>">
							<span class="help-inline">
								<?php echo form_error('oaWebDomain'); ?>
							</span>
						</div>
					</div>
                    <div class="control-group <?php if(form_error('oaContactNo')) echo 'error';?>">
						<label class="control-label">Oa Brand Logo</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="oaContactNo" type="text" value="<?php echo set_value('oaContactNo', $oaContactNo); ?>">
							<span class="help-inline">
								<?php echo form_error('oaContactNo'); ?>
							</span>
						</div>
					</div>
                   
<!-- end of form controls -->

                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>