<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('systmMngt/oa_brand_settings');?>">Oa Brands </a> 
            <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
          

			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>

<!-- start of form controls -->                    
					<div class="control-group <?php if(form_error('OabsAttributeId')) echo 'error';?>">
						<label class="control-label">OABS ATTRIBUTE ID</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OabsAttributeId" type="text" value="<?php echo set_value('OabsAttributeId', $OabsAttributeId); ?>">
							<span class="help-inline">
								<?php echo form_error('OabsAttributeId'); ?>
							</span>
                           
						</div>
					</div>

					<div class="control-group <?php if(form_error('OabsSettingValue')) echo 'error';?>">
						<label class="control-label">OABS SETTING VALUE</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OabsSettingValue" type="text" value="<?php echo set_value('OabsSettingValue', $OabsSettingValue); ?>">
							<span class="help-inline">
								<?php echo form_error('OabsSettingValue'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('OaBrandId')) echo 'error';?>">
						<label class="control-label">OA BRAND ID</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="OaBrandId" type="text" value="<?php echo set_value('OaBrandId', $OaBrandId); ?>">
							<span class="help-inline">
								<?php echo form_error('OaBrandId'); ?>
							</span>
						</div>
					</div>
                    
                    <div class="control-group <?php if(form_error('RefId')) echo 'error';?>">
						<label class="control-label">Ref Id</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="RefId" type="text" value="<?php echo set_value('RefId', $RefId); ?>">
							<span class="help-inline">
								<?php echo form_error('RefId'); ?>
							</span>
						</div>
					</div>
                    <div class="control-group <?php if(form_error('Description')) echo 'error';?>">
						<label class="control-label">DESCRIPTION</label>
						<div class="controls">
							<input class="input-xlarge" id="Description" name="Description" type="text" value="<?php echo set_value('Description', $Description); ?>">
							<span class="help-inline">
								<?php echo form_error('Description'); ?>
							</span>
						</div>
					</div>
                     <div class="control-group <?php if(form_error('Validation')) echo 'error';?>">
						<label class="control-label">VALIDATION</label>
						<div class="controls">
							<input class="input-xlarge" id="name" name="Validation" type="text" value="<?php echo set_value('Validation', $Validation); ?>">
							<span class="help-inline">
								<?php echo form_error('Validation'); ?>
							</span>
						</div>
					</div>
<!-- end of form controls -->

                    <!-- start of hidden inputs -->
       <input name="id" type="hidden" value="<?php echo set_value('id', $id); ?>">
                    <!-- end of hidden inputs -->
                            
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>