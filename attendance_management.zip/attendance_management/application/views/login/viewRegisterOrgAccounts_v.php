<!-- Start of Breadcrumb -->

<?php $this->load->view('include/login_header'); ?>          

<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->
     <div class="login_box">	
	         <!--- Start of first Form Organisation Registration ---->
            
   			 <form  method="post" id="org_account_setup" action="<?php if(isset($action)) echo $action; ?>">
                 <div class="top_b">Register Organisation Accounts</div>
                  <div class="cnt_b">
				<!-- Start of alert to display the form messages -->
					<?php if($this->session->flashdata('success')) {?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
				<!-- End of alert to display the form messages -->
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on"><i class="icon-user"></i></span><input type="text" id="org_code" name="org_code"  placeholder="Organisation Code" oncopy="return false;" onpaste="return false;" oncut="return false;"  /> <?php echo form_error('org_code'); ?>
                    </div>
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on"><i class="icon-user"></i></span><input type="text" id="org_name" name="org_name"  placeholder="Organisation Name" oncopy="return false;" onpaste="return false;" oncut="return false;"  /><?php echo form_error('org_name'); ?>
                    </div>
                   </div>
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on"><i class="icon-lock"></i></span><input type="text" id="org_email" name="org_email" placeholder="Email Address"  />  <?php echo form_error('org_email'); ?>
                    </div>
                   </div>
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on"><i class="icon-lock"></i></span><input type="text" id="org_address" name="org_address" placeholder="Address" oncopy="return false;" onpaste="return false;" oncut="return false;"   />
                    </div>
                   </div>
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on">@</span><input name="org_contact_no" id="org_contact_no" type="text" placeholder="Contact No"  oncopy="return false;" onpaste="return false;" oncut="return false;"  />
                    </div>
                   </div>
                   <div class="formRow">
                    <div class="input-prepend">
                     <span class="add-on">@</span><input name="org_web_domain" id="org_web_domain" type="url" placeholder="http://www.yourwebsite.com" rel='imgtip[0]' />
                    </div>
                   </div>
                                    
                  </div>
                  <div class="btm_b clearfix"  style="width:339px; margin-left:-63px; margin-top:15px; margin-bottom:-15px;">
                   <input name="submit" type="submit" value="Create an Organisation" style="margin-left:95px; margin-top:0px;" /><br><br>
                    <span class="link_reg" style="margin-left:50px;">Never mind, <a href="<?php echo site_url('login/user_registration_c/index'); ?>" data-ftrans="slide">send me back to the Registration screen</a></span>
                    <span class="link_reg" style="margin-left:62px;">Never mind, <a href="<?php echo site_url('login/login/index'); ?>" data-ftrans="slide">send me back to the sign-in screen</a></span>
                  </div>         
                  
                 </form>
             
             <!---- End of first form Organisation Registration ---->
     </div>   
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           
             
<?php $this->load->view('include/login_footer'); ?>                