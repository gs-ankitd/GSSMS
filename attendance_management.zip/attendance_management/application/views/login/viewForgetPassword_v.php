<!-- Start of Breadcrumb -->

<?php // $this->load->view('include/login_header'); ?>
 
<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
        <div class="login_box">
	         <!--- Start of first Form Forgot Password ----> 
  
 
               <form action="<?php if(isset($action)) echo $action; ?>" method="post" id="forgotpassword_form" name="forgotpassword_form" >
                <div class="top_b">Can't sign in?</div>    
                <div class="alert alert-info alert-login">
                      Please enter your registered email id. You will receive a link to reset password via email.
                </div>
                <div class="cnt_b">
				 <!-- Start of alert to display the form messages -->
					<?php if($this->session->flashdata('success')) {?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">�</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
				<!-- End of alert to display the form messages -->
                <div class="formRow">
				 <div class="input-prepend">
				  <span class="add-on">@</span><input type="text" id="txtuseremail" name="txtuseremail" placeholder="Your Email Id" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
				 </div>
				</div>
			 </div>
               
               <div class="btm_b tac">
                <button class="btn btn-inverse" type="submit">Request New Password</button><br><br>
                <span class="link_reg" >Never mind, <a href="<?php echo site_url('login/login/index'); ?>">send me back to the sign-in screen</a></span>
               </div>         
               <div class="links_b links_btm clearfix"></div>
              </form>
              
              <!---- End of first form Forgot Password ---->   
              </div>
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           

              

               
                