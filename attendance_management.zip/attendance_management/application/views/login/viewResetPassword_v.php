<!-- Start of Breadcrumb -->

<?php // $this->load->view('include/login_header'); ?>
 
<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
        <div class="login_box">
	         <!--- Start of first Form Forgot Password ----> 
				<form method="post" id="login_form" name="loginform" action="<?php if(isset($action)) echo $action;?>">
					<div class="top_b">Welcome to Mydocs</div>  
	
        
                      <div class="alert alert-info alert-login">
                            Reset your password.
        
                        </div>
				<div class="cnt_b">
					 <!-- Start of alert to display the form messages -->
					<?php if($this->session->flashdata('success')) {?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">�</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
				    <!-- End of alert to display the form messages -->
					<div class="formRow">
						<div class="input-prepend">
							<span class="add-on"><i class="icon-lock"></i></span>
                            <input type="password" name="txtPass"  placeholder="Enter password" />
						</div>
					</div>
					<div class="formRow">
						<div class="input-prepend">
							<span class="add-on"><i class="icon-lock"></i></span>
                            <input type="password" name="txtconpass" placeholder="Re-enter your password" />
						</div>
					</div>
                    </div>
                    <div class="btm_b tac">
					<button class="btn btn-inverse" name="btnsub" type="submit">Reset Password</button>
				</div>  
             
                    </form>
                    
</div>