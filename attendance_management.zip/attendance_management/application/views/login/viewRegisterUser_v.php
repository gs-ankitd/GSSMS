<!-- Start of Breadcrumb -->

<?php $this->load->view('include/login_header'); ?>


<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
     <div class="login_box">
	         <!--- Start of first Form Register User ----> 
 			<form  method="post" id="userregistration_form" action="<?php if(isset($action)) echo $action; ?>" >
			 <div class="top_b">User Registration</div>
			  <div class="cnt_b">
				 <!-- Start of alert to display the form messages -->
					<?php if($this->session->flashdata('success')) {?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
				<!-- End of alert to display the form messages -->
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-user"></i></span><input type="text" id="username" name="username" value="" placeholder="Username"  oncopy="return false;" onpaste="return false;" oncut="return false;" /><?php echo form_error('username'); ?>
				</div>
			   </div>
			   <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="reg_password" name="reg_password" placeholder="Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  value="" /><?php echo form_error('reg_password'); ?>
				</div>
               </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="con_password" name="con_password" placeholder="Confirm Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  value="" /><?php echo form_error('con_password'); ?>
				</div>
               </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on">@</span><input name="email_address" id="email_address" type="text" placeholder="Your email id" value="" /><?php echo form_error('email_address'); ?>
				</div>
			   </div>
               <div class="formRow">
				<div class="input-prepend">
				 <span class="add-on">@</span><input type="text" name="org_code" id="org_code" placeholder="organisation Code" oncopy="return false;" onpaste="return false;" oncut="return false;"   value="" /><?php echo form_error('org_code'); ?>
				</div>
			   </div>
               <div class="formRow">
				<div class="input-prepend">
                 <span class="link_reg" style="margin-left:45px;"><a data-ftrans="slide" href="<?php echo site_url('login/org_registration_c/index'); ?>">Set Up a New Organisation Code</a></span>
				</div>
		       </div>
              </div>
              <div class="btm_b clearfix">
			   <input name="submit" type="submit" value="Create an Account" style="margin-left:95px; margin-top:0px;" /><br><br>
                <span class="link_reg" style="margin-left:60px;">Never mind, <a data-ftrans="slide" href="<?php  echo site_url('login/login/index'); ?>" >send me back to the sign-in screen</a></span>
			  </div>         
            

             </form>
             
             <!---- End of first form Register User ----> 
     </div>  
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           

             
<?php $this->load->view('include/login_footer'); ?>                