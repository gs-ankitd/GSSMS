<!-- Start of Breadcrumb -->

<?php //$this->load->view('include/login_header'); ?>          
 
<!-- End of Breadcrumb -->

<!---- Start of Content Body div ---->
	 <!---- Start of Content Body header div ---->
     
     <!---- End of Content Body header div ---->	
		  
     
     <!---- Start of Page Content div ---->	
     <div class="login_box">
	         <!--- Start of first Form Login ---->
			 <form method="post" id="login_form" name="login_form" action="<?php if(isset($action)) echo $action; ?>">
             <!----Title of the form ---->
			  <div class="top_b">Welcome</div>  
	          <div class="alert alert-info alert-login">
					Sign in.
			  </div>
               
			  <div class="cnt_b">
             	 <!-- Start of alert to display the form messages -->
					<?php if($this->session->flashdata('success')) {?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php } ?>
				<!-- End of alert to display the form messages -->

                <div class="formRow">
				 <div class="input-prepend">
                  <span class="add-on"><i class="icon-user"></i></span>
                  <input type="text" id="username" name="username" placeholder="Username" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
				 </div>
				</div>
				<div class="formRow">
				 <div class="input-prepend">
				  <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="password" name="password" placeholder="Password" oncopy="return false;" onpaste="return false;" oncut="return false;"  />
				 </div>
				</div>
			 </div>
			 <div class="btm_b clearfix">
                 <span class="link_reg"><a data-ftrans="slide" href="<?php  echo site_url('login/user_registration_c/index');  ?>">Not registered? Sign up here</a></span>
               
                 <span class="link_reg"><a data-ftrans="slide" href="<?php  echo site_url('login/forgot_pass/index');  ?>">Forgot Your Password</a></span>
			
                  <?php
			
				    echo form_submit('submit', 'Login');
					 
			      ?>
          
         
			</div>
				
		  </form>
           <!---- End of first form Login ----> 
     </div>       
	 <!---- End of Page Content div ---->   
            
<!---- End of Content Body div ---->           


<?php $this->load->view('include/login_footer'); ?>      