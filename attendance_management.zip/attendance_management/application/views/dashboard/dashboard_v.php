<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('dashboard/dashboard');?>">Dashboard</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->
<div class="sortable row-fluid">
				<a data-rel="tooltip" title="<?php //echo $tot_user;?> Total users." class="well span3 top-block" href="#">
					<span class="icon32 icon-red icon-user"></span>
					<div>Total Users</div>
					<div><?php //echo $tot_user;?></div>
					<span class="notification"><?php //echo $tot_user;?></span>
				</a>

				<a data-rel="tooltip" title="<?php //echo $tot_task;?> Total tasks." class="well span3 top-block" href="">
					<span class="icon32 icon-color icon-star-on"></span>
					<div>Total Tasks</div>
					<div><?php //echo $tot_task;?></div>
					<span class="notification green"><?php //echo $tot_task;?></span>
				</a>

				<a data-rel="tooltip" title="<?php //echo $total_projects;?> total projects." class="well span3 top-block" href="<?php //echo site_url('desktop_c/index');?>">
					<span class="icon32 icon-color icon-cart"></span>
					<div>Total Projects</div>
					<div><?php //echo $total_projects;?></div>
					<span class="notification yellow"><?php //echo $total_projects;?></span>
				</a>
				
				<a data-rel="tooltip" title="<?php //echo $tot_milestone;?> Total Milestones." class="well span3 top-block" href="#">
					<span class="icon32 icon-color icon-envelope-closed"></span>
					<div>Total Milestones</div>
					<div><?php //echo $tot_milestone;?></div>
					<span class="notification red"><?php //echo $tot_milestone;?></span>
				</a>
			</div>
<!-- Start of main body -->
<div class="row-fluid sortable">
				<div class="box span4">
					<div class="box-header well">
						<h2><i class="icon-user"></i> Users</h2>
						<div class="box-icon">
                        <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content toggleDiv">
						<ul class="dashboard-list">
							<!--<li class="active"><a href="#info">Info</a></li>
							<li><a href="#custom">Custom</a></li>
							<li><a href="#messages">Messages</a></li>-->
                            <?php //echo $usertable;?>
						</ul>
                        <div id="userpiechart" style="height:275px"></div>
                        
	
					</div>
				</div><!--/span-->
						
				<div class="box span4">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-list"></i> Project Status</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content  toggleDiv">
                        <div id="projectpiechart"  style="height:275px"></div>
					</div>
				</div><!--/span-->
						
				<div class="box span4">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-list"></i> Milestones Status</h2>
						<div class="box-icon">
                        	<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content toggleDiv">
						<!--<div id="realtimechart" style="height:190px;"></div>
							<p class="clearfix">You can update a chart periodically to get a real-time effect by using a timer to insert the new data in the plot and redraw it.</p>
							<p>Time between updates: <input id="updateInterval" type="text" value="" style="text-align: right; width:5em"> milliseconds</p>-->
                            
                            <div id="milestonepiechart" style="height:275px"></div>
					</div>
				</div><!--/span-->
			</div>
            
            <div class="row-fluid sortable">
				<div class="box span4">
					<div class="box-header well">
						<h2><i class="icon-user"></i> Users</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content toggleDiv">
						<ul class="dashboard-list">
							<!--<li class="active"><a href="#info">Info</a></li>
							<li><a href="#custom">Custom</a></li>
							<li><a href="#messages">Messages</a></li>-->
                            <?php //echo $usertable;?>
						</ul>
                        <div id="userpiechart" style="height:275px"></div>
                        
	
					</div>
				</div><!--/span-->
						
				<div class="box span4">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-list"></i> Project Status</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content  toggleDiv">
                        <div id="projectpiechart"  style="height:275px"></div>
					</div>
				</div><!--/span-->
						
				<div class="box span4">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-list"></i> Milestones Status</h2>
						<div class="box-icon">
                        	<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					<div class="box-content toggleDiv">
						<!--<div id="realtimechart" style="height:190px;"></div>
							<p class="clearfix">You can update a chart periodically to get a real-time effect by using a timer to insert the new data in the plot and redraw it.</p>
							<p>Time between updates: <input id="updateInterval" type="text" value="" style="text-align: right; width:5em"> milliseconds</p>-->
                            
                            <div id="milestonepiechart" style="height:275px"></div>
					</div>
				</div><!--/span-->
			</div>
<!-- End of main body -->