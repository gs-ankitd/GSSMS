<!DOCTYPE html>
 <html lang="en">
  <head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <title>Login Page</title>
      <script src="<?php echo base_url();?>/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>/js/jquery.actual.min.js"></script>
      <!-- <script src="<?php echo base_url();?>/js/login/main.js"></script>
       <script src="<?php echo base_url();?>/js/login/registration_form_validate.js"></script>
        <script src="<?php echo base_url();?>/js/login/organisation_registration_form_validate.js"></script>
         <script src="<?php echo base_url();?>/js/login/login_form_validate.js"></script> -->   
     
      	<link rel="stylesheet" href="<?php echo base_url();?>/css/blue.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url();?>/css/brown.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url();?>/css/dark.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo base_url();?>/css/eastern_blue.css" type="text/css" media="screen" />
     <link rel="stylesheet" href="<?php echo base_url();?>/css/green.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="<?php echo base_url();?>/css/ie.css" type="text/css" media="screen" />
       <link rel="stylesheet" href="<?php echo base_url();?>/css/style.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo base_url();?>/css/tamarillo.css" type="text/css" media="screen" />
         <link rel="stylesheet" href="<?php echo base_url();?>/css/bootstrap.css" type="text/css" media="screen" />
          <link rel="stylesheet" href="<?php echo base_url();?>/css/bootstrap.min.css" type="text/css" media="screen" />
           <link rel="stylesheet" href="<?php echo base_url();?>/css/bootstrap-responsive.css" type="text/css" media="screen" />
            <link rel="stylesheet" href="<?php echo base_url();?>/css/bootstrap-responsive.min.css" type="text/css" media="screen" />
	<link href="<?php echo base_url();?>/css/transition.css" rel="stylesheet" type="text/css"/>
    		<script type="text/javascript" src="<?php echo base_url();?>/js/fasw.transitions.min.js"></script>

<script type="text/javascript">
(function inittrans() 
{
	var params =	//All params are optional, you can just assign {} 
		{ 
			"navB" : "slide",	//Effect for navigation button, leave it empty to disable it
			"but" : true,				//Flag to enable transitions on button, false by default
			"cBa" : onTransitionFinished // function() { alert("Done!"); }	//callback function
		};
	new ft(params);
})();

function onTransitionFinished()
{
	//Do anything you want 
}

</script>
  </head>

  <body class="login_page">
   