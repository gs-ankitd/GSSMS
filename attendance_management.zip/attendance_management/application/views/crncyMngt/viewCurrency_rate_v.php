<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                             */
/*   Date         		: Feb 2013                                                 */
/*   Synopsis     		: Code for
							1)Edit of Currency						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/

?>

<script type="text/javascript">
	function confirmDialog() {
    return confirm("Are you sure you want to delete this message?")
	}
$(document).ready(function(){
    $('#Eff_From').datepicker('option', 'onSelect', function(selectedDate) { 
		$('#Eff_To').datepicker('option', 'minDate', selectedDate);
	 });
	 
	$('#Eff_To').datepicker('option', 'onSelect', function(selectedDate) { 
		$('#Eff_From').datepicker('option', 'maxDate', selectedDate);
	 });
  });

  $(function() {
    $('#Ex_Rate').keyup(function() {
        $(this).val($(this).val().toUpperCase());
    });
});
</script>			
		  
	
          
			
			<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Currency Rate</a>
					</li>
				</ul>
			</div>
            <!-- breadcrumb ends -->
                    
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

					  <div class="row-fluid sortable">
				<div class="box span12" >
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i><?php echo $title; ?></h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                   
						<form class="form-horizontal" action="<?php if(isset($action)) echo $action;?>" method="post" >
							<fieldset>
                            
							  <div class="control-group  <?php if(form_error('Src_Curr_ID'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Source Currency<span style="color:red;">*</span> </label>
									<div class="controls">
										 <select name="Src_Curr_ID" data-rel="chosen"> 
											<option value="">Select an option</option>
											<?php
												foreach($CurrencyDrop as $list)
												{
													//Start of for loop
									
												if($list->CURR_ID==$Src_Curr_ID)
												{
													//start of if statement
											?>
												<option value="<?php echo $list->CURR_ID;?>" selected="selected"><?php echo $list->CURR_NAME;?></option>
											<?php
												}//end of if statement
												else
												{ //Start of else statement
											?><option value="<?php echo $list->CURR_ID;?>" ><?php echo $list->CURR_NAME;?></option><?php
												}//end of else statment
												}//end of for loop
											?>
									
										</select> 
										
                       					 <span class="help-inline">
                                          <?php echo form_error('Src_Curr_ID'); ?>
          								</span>		
									</div>
							  </div>
                              
                              <div class="control-group  <?php if(form_error('Trg_Curr_ID'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Target Currency<span style="color:red;">*</span> </label>
									<div class="controls">
										<select name="Trg_Curr_ID" data-rel="chosen"> 
											<option value="">Select an option</option>
											<?php
												foreach($CurrencyDrop as $list)
												{
													//Start of for loop
									
												if($list->CURR_ID==$Trg_Curr_ID)
												{
													//start of if statement
											?>
												<option value="<?php echo $list->CURR_ID;?>" selected="selected"><?php echo $list->CURR_NAME;?></option>
											<?php
												}//end of if statement
												else
												{ //Start of else statement
											?><option value="<?php echo $list->CURR_ID;?>" ><?php echo $list->CURR_NAME;?></option><?php
												}//end of else statment
												}//end of for loop
											?>
									
										</select>
										
                       					 <span class="help-inline">
                                          <?php echo form_error('Trg_Curr_ID'); ?>
          								</span>		
									</div>
							  </div>
                              
                              <div class="control-group  <?php if(form_error('Ex_Rate'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Exachange Rate<span style="color:red;">*</span> </label>
									<div class="controls">
		<input type="text"  name="Ex_Rate" maxlength="4" id="Ex_Rate" value="<?php if(isset($Ex_Rate)) echo $Ex_Rate; else echo set_value('Ex_Rate');?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('Ex_Rate'); ?>
          								</span>		
									</div>
							  </div>
                              
                              <div class="control-group  <?php if(form_error('Eff_From'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Effective From<span style="color:red;">*</span> </label>
									<div class="controls">
	<input type="text" class="input-xlarge datepicker" id="Eff_From" name="Eff_From" value="<?php if(isset($Eff_From)) echo set_value('Eff_From', date('m/d/Y',strtotime($Eff_From))); ?>">
                           
                       					 <span class="help-inline">
                                          <?php echo form_error('Eff_From'); ?>
          								</span>		
									</div>
							  </div>
                              
                              <div class="control-group  <?php if(form_error('Eff_To'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Effective To<span style="color:red;">*</span> </label>
									<div class="controls">
										<input type="text" class="input-xlarge datepicker" id="Eff_To" name="Eff_To" value="<?php if(isset($Eff_To))  echo set_value('Eff_To', date('m/d/Y',strtotime($Eff_To))); ?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('Eff_To'); ?>
          								</span>		
									</div>
							  </div>
                              
                              
                             
                              
      
     								<!-- start of hidden inputs -->
                    <input name="Curr_Rate_ID" type="hidden" value="<?php echo set_value('Curr_Rate_ID',$Curr_Rate_ID); ?>">
                   						 <!-- end of hidden inputs -->
     
    
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								 <?php echo anchor('crncyMngt/currency_rate','Cancel',array('class'=>'btn')); ?>
							  </div>
							</fieldset>
						  </form>
					
					</div><!--/class="box-content"-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
       
    
</div><!--/fluid-row-->
				
	
        
		
		
	</div>

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

		
	</div><!--/.fluid-container-->

		

</body>
</html>
