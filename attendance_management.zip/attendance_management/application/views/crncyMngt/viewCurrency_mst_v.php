<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                               */
/*   Date         		: Feb 2013                                                 */
/*   Synopsis     		: Code for
							1)Edit of Currency						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/

?>


<body>


		<!-- topbar starts -->
		<!-- topbar ends -->
		
			<!-- left menu starts -->
			<?php 
			//$this->load->view('include/left_menu.php');
			?><!--/span-->
			<!-- left menu ends -->
			
		  
	
        
			<!-- content starts -->
			
			<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">Currency</a>
					</li>
				</ul>
			</div>
            <!-- breadcrumb ends -->
                    
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

					  <div class="row-fluid sortable">
				<div class="box span12" >
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i><?php echo $title; ?></h2>
                        <div class="box-icon">
							<!--<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>-->
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<!--<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>-->
						</div>
                  </div>
					
					<div class="box-content">
                  
     
      
						<form class="form-horizontal" action="<?php if(isset($action)) echo $action;?>" method="post" >
							<fieldset>
                            
							  <div class="control-group  <?php if(form_error('Curr_Code'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Currency Code<span style="color:red;">*</span> </label>
									<div class="controls">
										<input type="text" name="Curr_Code" maxlength="4" id="Curr_Code" value="<?php if(isset($Curr_Code)) echo $Curr_Code; else echo set_value('Curr_Code');?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('Curr_Code'); ?>
          								</span>		
									</div>
							  </div>
							  
                              
                              <div class="control-group  <?php if(form_error('Curr_Name'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Currency Name<span style="color:red;">*</span> </label>
									<div class="controls">
										<input type="text" name="Curr_Name"  id="Curr_Name" value="<?php if(isset($Curr_Name)) echo $Curr_Name; else echo set_value('Curr_Name');?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('Curr_Name'); ?>
          								</span>		
									</div>
							  </div>
                              
                              <div class="control-group  <?php if(form_error('Curr_Symbol'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Currency Symbol<span style="color:red;">*</span> </label>
									<div class="controls">
										<input type="text" name="Curr_Symbol" maxlength="4" id="Curr_Symbol" value="<?php if(isset($Curr_Symbol)) echo $Curr_Symbol; else echo set_value('Curr_Symbol');?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('Curr_Symbol'); ?>
          								</span>		
									</div>
							  </div>
                              
                              
                              
                               <div class="control-group" id="parentID">
								<label class="control-label" for="focusedInput">Country </label>
								<div class="controls">
                                <select name="Country_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($CountryDrop as $list)
									  {//start of foreach($CountryDrop as $list)
										  
									   if($list->MSTR_ID==$Country_ID)
									   {//start of ($list->MSTR_ID==$Country_ID)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									   }//end of ($list->MSTR_ID==$Country_ID)
									 }//end of foreach($CountryDrop as $list)
                                  ?>
								 
     							</select>
								</div>
							  </div>

     								<!-- start of hidden inputs -->
                    <input name="Curr_ID" type="hidden" value="<?php echo set_value('Curr_ID', $Curr_ID); ?>">
                   						 <!-- end of hidden inputs -->
     
    
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								 <?php echo anchor('crncyMngt/currency_mst','Cancel',array('class'=>'btn')); ?>
							  </div>
							</fieldset>
						  </form>
					
					</div><!--/class="box-content"-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
       
    
</div><!--/fluid-row-->
				
	
        
		
		
	</div>

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

		
	</div><!--/.fluid-container-->

		

</body>
</html>
