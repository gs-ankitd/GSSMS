<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('crncyMngt/currency_mst');?>">Currency</a> 
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

<!-- Start of main body -->
<div class="row-fluid sortable">
	<div class="box span12">
    	<!-- Start of title bar -->
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-home"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="<?php echo site_url('entity/entity_obj_attrbt/index/currency_mst'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
         
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
    	<!-- End of title bar -->
		
        <!-- Start of content -->
        <div class="box-content">
        
			<fieldset>
				
               
                  <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('crncyMngt/currency_mst/newCurrency/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
				<table class="table table-striped table-bordered bootstrap-datatable datatable">
                	<!-- Start of table head -->
					<thead>
<tr>

						<?php
                        //var_dump($visibleCol);
                        if(validateColVisibility('CURR_ID',$visibleCol))
                        {
                        ?>
                        			<th>ID</th>
                        <?php
                        }
                        ?>
                        <?php
                        if (validateColVisibility('CURR_CODE',$visibleCol)) {
                        
                        ?>
                        			<th>Code</th>
                        <?php
                        }
                        ?>
                        
                        <?php
                        if (validateColVisibility('CURR_NAME',$visibleCol)) {
                        
                        ?>
                        			<th>Name</th>
                        <?php
                        }
                        ?>
                        
                        
                        
                        <?php
                        if(validateColVisibility('CURR_SYMBOL',$visibleCol))
                        {
                        ?>
                        
                        			<th>Symbol</th>
                        <?php
                        }
                        ?>
                        
                        <?php
                        if (validateColVisibility('OA_ID',$visibleCol)) {
                        
                        ?>
                        			<th>Organisation ID</th>
                        <?php
                        }
                        ?>
                        <?php
                        if (validateColVisibility('Country_ID',$visibleCol)) {
                        
                        ?>
                        			<th>Country</th>
                        <?php
                        }
                        ?>
                        <?php
                        if (validateColVisibility('Ref_ID',$visibleCol)) {
                        
                        ?>
                        			<th>RefID</th>
                        <?php
                        }
                        ?>
                        
                        <?php
                        if (validateColVisibility('CREATEDBY',$visibleCol)) {
                        
                        ?>
                        			<th>Created By</th>
                        <?php
                        }
                        ?>
                        
                        <?php
                        if (validateColVisibility('UPDATEDBY',$visibleCol)) {
                        
                        ?>
                        			<th>Updated By</th>
                        <?php
                        }
                        ?>
                        
                        
                        
                        <?php
                        if (validateColVisibility('Created_On',$visibleCol)) {
                        
                        ?>
                        			<th>Created On</th>
                        <?php
                        }
                        ?>
                        
                        <?php
                        if (validateColVisibility('Updated_On',$visibleCol)) {
                        
                        ?>
                        			<th>Updated On</th>
                        <?php
                        }
                        
                        ?>
                        			<th>Actions</th>
                        </tr>

					</thead>
                    <!-- End of table head -->
                    <!-- Start of table body -->
					<tbody>
							<?php foreach($currency as $curr):
                             ?>
                                
                            <tr>
                            <?php
                            if(validateColVisibility('CURR_ID',$visibleCol))
                            {
                                
                            ?>
                                	<td class="center"><?php echo $curr->CURR_ID; ?></td>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('CURR_CODE',$visibleCol))
                            {
                            ?>
                                	<td class="center"><?php echo $curr->CURR_CODE; ?></td>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('CURR_NAME',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->CURR_NAME; ?></td>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('CURR_SYMBOL',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->CURR_SYMBOL; ?></td>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('OA_ID',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->OA_NM; ?></td>
                            <?php
                            }
                            ?>
                            
                            <?php
                            if(validateColVisibility('Country_ID',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->MasterName; ?></td>
                            <?php
                            }
                            ?>
                            
                            <?php
                            if(validateColVisibility('Ref_ID',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->Ref_ID; ?></td>
                            <?php
                            }
                            ?>
                            
                            <?php
                            if(validateColVisibility('CREATEDBY',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->Created_By_Name; ?></td>
                            <?php
                            }
                            ?>
                            
                            <?php
                            if(validateColVisibility('UPDATEDBY',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->Updated_By_Name; ?></td>
                            <?php
                            }
                            ?>
                            <?php
                            if(validateColVisibility('Created_On',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->Created_On; ?></td>
                            <?php
                            }
                            ?>
                            
                            <?php
                            if(validateColVisibility('Updated_On',$visibleCol))
                            {
                            ?>
                            
                                	<td class="center"><?php echo $curr->Updated_On; ?></td>
                            <?php
                            }
                            ?>
                                    <td class="center ">

                                     <a href="<?php echo site_url('crncyMngt/currency_mst/editCurrency/'.$curr->CURR_ID);?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('crncyMngt/currency_mst/delete/'.$curr->CURR_ID);?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
                                    </td>
                                    
                            </tr>	
                            
                            <?php endforeach; ?>						
					</tbody>
                    <!-- End of table body -->
				</table> 
                
                
			</fieldset>   
		</div>
    	<!-- End of content -->
	</div><!--/span-->

</div>
<?php


 /*function validateColVisibility($colNm,$visibleColbleArrayList) {
		
		 foreach ($visibleColbleArrayList as $element) {
        if ( ($element->Obj_Attrbt_Nm == $colNm) ){
            return true;
        }
		 }
							
                        			
                           
	}*/
?>
<!-- End of main body -->