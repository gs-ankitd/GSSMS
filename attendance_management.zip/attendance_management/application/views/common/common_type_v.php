<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)CommonType/System Entity View						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/
?>
<body>
<script>
function confirmDialog() {
    return confirm("Are you sure you want to delete this record?")
}
</script>
<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">System Entity</a>
					</li>
				</ul>
			</div>

<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->  
            
			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class=""></i> System Entity</h2>
						<div class="box-icon">
						<a href="<?php echo site_url('entity/entity_obj_attrbt/index/common_type'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
                      </div>
                    </div>
                    
 
                
                    <div class="box-content">
                    
                     <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('common/common_type/addCommonType/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  <br><br>
                   
                    <table class="table table-striped table-bordered bootstrap-datatable datatable">
                   
                    <thead>
                    	<tr>
                       		<?php
							if (validateColVisibility('TYP_ID',$visibleCol)) 
							{
							?>
                       					<th>Type ID</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('TYP_CD',$visibleCol)) 
							{
							?>
                    					<th>Type Code</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('TYP_NM',$visibleCol)) 
							{
							?>
                           				<th>Type Name</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('VIEW_NM',$visibleCol)) 
							{
							?>
                            			<th>View Name</th>
                            <?php
							}
							?>
                            
                            
							<?php
							if (validateColVisibility('PARENT_TYP_ID',$visibleCol)) 
							{
							?>
                    					<th>Parent Type </th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('CREATED_BY',$visibleCol)) 
							{
							?>
                            			<th>Created By</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('UPDATED_BY',$visibleCol)) 
							{
							?>
                            			<th>Updated By</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('CREATED_ON',$visibleCol)) 
							{
							?>
                           				<th>Created On</th>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('UPDATED_ON',$visibleCol)) 
							{
							?>
                            			<th>Updated On</th>
                            <?php
							}
							?>
                            
                            
                            			<th>Actions</th>
                    	</tr>
                    </thead>
                    <tbody>
                    <?php
					foreach($c_type as $list)
					{
						?>
                        <tr><?php
							if (validateColVisibility('TYP_ID',$visibleCol)) 
							{
							?>
                       					<td><?php echo $list->TYP_ID;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('TYP_CD',$visibleCol)) 
							{
							?>
                    					<td><?php echo $list->TYP_CD;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('TYP_NM',$visibleCol)) 
							{
							?>
                           				<td><?php echo $list->TYP_NM;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('VIEW_NM',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->VIEW_NM;?></td>
                            <?php
							}
							?>
                            
                            
							<?php
							if (validateColVisibility('PARENT_TYP_ID',$visibleCol)) 
							{
							?>
                    					<td><?php echo $list->ParentTypeName;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('CREATED_BY',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->Created_by_name;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('UPDATED_BY',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->Updated_by_name;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('CREATED_ON',$visibleCol)) 
							{
							?>
                           				<td><?php echo $list->CREATED_ON;?></td>
                            <?php
							}
							?>
                            
                            
                            <?php
							if (validateColVisibility('UPDATED_ON',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->UPDATED_ON;?></td>
                            <?php
							}
							?>
                        <td width="180">
                           <a  href="<?php echo site_url('common/common_type/editCommonType/'.$list->TYP_ID); ?>"> <span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    <a  href="<?php echo site_url('common/common_type/deleteCommonType/'.$list->TYP_ID); ?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
                           </td>
                      </tr>
						<?php	
						
					}
                    ?>
                    </tbody>
                    </table>
                    
                    </div><!--content -->
                </div><!--span -->
            </div>   <!--row -->

            
	  
       
			<!-- content ends -->
			</div><!--/#content.span10-->
			</div><!--/fluid-row-->
				
		


		
	</div><!--/.fluid-container-->
	
</body>
</html>
