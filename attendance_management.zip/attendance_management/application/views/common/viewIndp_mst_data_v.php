<!--  Start of MENU CHECKBOX-->

<script>
	$( document ).ready(function() { 
		if ($("#chkMenu").is(':checked')){
		$("#menu").show();
		}
		$('#chkMenu').click(function(){
		var thisCheck = $('#chkMenu');
		if (thisCheck.is (':checked'))
		{
		// Do stuff
		$('#menu').show();
		}else
		{
		$('#menu').hide();
		}
		});
	});

</script>

<!--  End of MENU CHECKBOX-->			   
			   
<!--  Start Global Setting Checkbox -->                   
<script>
	$( document ).ready(function() { 
		if ($("#link").is(':checked')){
		$("#globalSettings").show();
		}
		$('#link').click(function(){
		var thisCheck = $('#link');
		if (thisCheck.is (':checked')){
		// Do stuff
		$('#globalSettings').show();
		}else
		{
 		 $('#globalSettings').hide();
		}
		});
	});
</script>               						 								
<!--  End of Global Setting Checkbox --> 

<!-- Start of Parent Checkbox -->                   
<script>
	$( document ).ready(function() { 
		if ($("#chkParentID").is(':checked')){
		$("#parentID").show();
		}else{
		$("#parentID").hide();
		}
		$('#chkParentID').click(function(){
	 	 var thisCheck = $('#chkParentID');
		if (thisCheck.is (':checked')){
		// Do stuff
		$('#parentID').show();
		}else
		{
	    $('#parentID').hide();
		}
	 	});
	});

	$(function() {
    $('#master_code').keyup(function() {
        $(this).val($(this).val().toUpperCase());
    });
});
</script>               						 								
 <!-- End of Parent Checkbox -->			

	<!-- content starts -->
            <div>
            <!-- Start of Breadcrumb div -->
                <ul class="breadcrumb">
                    <li>
                        <a href="#">Home</a> <span class="divider">/</span>
                    </li>
                    <li>
                        <a href="<?php echo site_url('settings/indp_mst_data');?>"><?php echo $title; ?></a>
                    </li>
                </ul>
        </div> <!--End of breadcrumb  div-->
    
        <!-- Start of alert to display the form messages -->
        <?php if($this->session->flashdata('success')) {?>
              <div class="alert alert-success">
              <!--Start of alert -->
             <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo $this->session->flashdata('success'); ?>
             </div><!--End of alert -->
        <?php } ?>
        <!-- End of alert to display the form messages -->
        
        <div class="row-fluid sortable">
        <!-- Start of row fluid sortable -->
            <div class="box span12" style="margin-left:1px;">
             <!-- Start of box span -->
                <div class="box-header well" data-original-title>
                 <!-- Start of box header well -->
                    <h2><i class="icon-picture"></i><?php echo $title; ?></h2> <!-- Display of title sent from controller -->
                        <div class="box-icon">
                         <!-- Start of box icon -->
                           <a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
                            <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
                            <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
                        </div> <!-- end of box icon -->
                </div> <!-- end of box header well -->
                    
            <div class="box-content">
             <!-- Start of box content -->
                <form class="form-horizontal" action="<?php if(isset($action)) echo $action;?>" method="post" name="form1">
                <!-- Start of Form -->
                <fieldset>
                <!-- Start of fieldset -->
                <div class="control-group <?php if(form_error('master_code'))  echo 'error'; ?>">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Master Code<span style="color:red;">*</span> </label><!-- label Name -->
                <div class="controls">
                 <!-- Start of controls -->
                    <input type="text" name="master_code" id="master_code" maxlength="4" value="<?php if(isset($master_code)) echo $master_code; else echo set_value('master_code');?>" > <!-- Display The value while editing,and emty form while inserting -->
                    <span class="help-inline">
                     <!--Start of span class-->
                    <?php echo form_error('master_code'); ?> <!--Display Error if not validates -->
                    </span> <!--end of span class-->
                </div> <!-- End of controls -->
                </div> <!-- Start of control group -->
                                      
                <div class="control-group <?php if(form_error('master_name'))  echo 'error'; ?>">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Master Name<span style="color:red;">*</span> </label><!-- label Name -->
                <div class="controls">
                 <!-- Start of control  -->
                    <input type="text" name="master_name" id="master_name" value="<?php if(isset($master_name)) echo $master_name; else echo set_value('master_name');?>"><!-- Display The value while editing,and emty form while inserting -->							       
                     <span class="help-inline">
                     <!--Start of span class-->
                    <?php echo form_error('master_name'); ?><!--Display Error if not validates -->
                    </span><!--End of span class -->
                </div> <!-- End of control group -->
                </div> <!-- End of control -->
                                      
                                      
                <div class="control-group <?php if(form_error('type_id'))  echo 'error'; ?>"><!--Display Error if not validates -->
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Parent Type<span style="color:red;">*</span> </label><!-- label Name -->
                    <div class="controls">
                     <!-- Start of control  -->
                    <select name="type_id" data-rel="chosen">  <!--Dropdown box for parentid-->
                    <option value="">Select an option</option>
                    <?php
                        foreach($typename as $list)
                        {
                            //Start of for loop
            
                        if($list->TYP_ID==$type_id)
                        {
                            //start of if statement
                    ?>
                        <option value="<?php echo $list->TYP_ID;?>" selected="selected"><?php echo $list->TYP_NM;?></option>
                    <?php
                        }//end of if statement
                        else
                        { //Start of else statement
                    ?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
                        }//end of else statment
                        }//end of for loop
                    ?>
            
                    </select> <!--End of drop down box for parentid-->
                        <span class="help-inline">
                        <!--Start of span class -->
                        <?php echo form_error('type_id'); ?><!--Display Error if not validates -->
                        <!--End of span class -->
                        </span>
                    </div> <!--Endof control group -->
                </div> <!--End of control -->
                    <?php if($lvs_parentID->num_rows() > 0) 
                    //Start of If statement to check parentid
                          {
                    ?>
        
                <div class="control-group ">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Set Parent Type</label>
                <div class="controls">
                 <!-- Start of control  -->
                    <input type="checkbox" name="chkParentID"  value="" id="chkParentID"  checked>	
                </div> <!-- End of control group -->
                </div> <!-- End of control  -->
                                      
                    <?php
                    }//end of if statemnt to check parent id
                    else
                    //Start of else statement
                    {?>
        
                <div class="control-group ">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Set Parent Type</label> <!--Label for set parent type-->
                <div class="controls">
                 <!-- Start of control  -->
                    <input type="checkbox" name="chkParentID"  value="" id="chkParentID"  >	 <!--Setting input type as checkbox-->
            
                </div> <!-- End of control group -->
                </div> <!-- End of control  -->
        
                    <?php
                    }//End of else statement
                    ?>
                                      
        
                <div class="control-group" id="parentID">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Parent ID </label> <!--Label for Parent Id-->
                <div class="controls">
                 <!-- Start of control -->
                    <select name="parent_id" data-rel="chosen">  <!--Dropdown box for parentid-->
                    <option value="">Select an option</option>
                    <?php
                        foreach($parentName as $list)
                        {
                            //Start of for loop
            
                        if($list->MSTR_ID==$parent_id->PARENT_ID)
                        {
                            //start of if statement
                    ?>
                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
                    <?php
                        }//end of if statement
                        else
                        { //Start of else statement
                    ?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
                        }//end of else statment
                        }//end of for loop
                    ?>
            
                    </select> <!--End of drop down box for parentid-->
            
                </div> <!-- End of control group -->
                </div> <!-- End of controls -->
        
                                      
                <?php if($lvs_getGlobalSettingsDetails ==  true) 
                        //Start for if statement to check globalsetting details
                    {
                ?>
                <div class="control-group ">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Link to Global Settings</label>
                <div class="controls">
                 <!-- Start of controls -->
                    <input type="checkbox" name="chkGlobalSettings"  value="" id="link"  checked>	
                </div> <!-- End of control group -->
                </div> <!--End of controls -->
                <?php 
                    }//end of if statement to check globalsetting details
                    else
                    { //start of else statement 
                ?>
            
                <div class="control-group">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Link to Global Settings</label> <!--Label for link to Global Settings-->
                <div class="controls">
                 <!-- Start of control group -->
                    <input type="checkbox" name="chkGlobalSettings"  value="" id="link"  >	 <!--Settinf checkbox for link to global settings-->
            
                </div><!-- End of control group -->
                </div> <!--End of controls -->
            
                <?php 
                    }//end of else statement
                ?>
            
                <div class="control-group" id="globalSettings" style="display:none;" >
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Global Settings </label>
                <div class="controls">
                 <!-- Start of control group -->
                    <select id="global_settings" name="global_settings" data-rel="chosen"> <!--Start of drop down box for global settings-->
                    <option value="">Select an Option</option>
                    <?php
            
                    foreach($lva_globalSettings as $gs)
                    { //Start of For loop for globalsettings
            
                        if($gs->MSTR_ID == $lvs_repopulateGlobalSettings->TRGT_ENTTY_ID)
                        { //Start of if statements
                    ?><option value="<?php echo $gs->MSTR_ID;?>" selected="selected"><?php echo $gs->MSTR_NM;?></option><?php
                        }//End of if statements
                        else
                        { //Start of else statement
                    ?><option value="<?php echo $gs->MSTR_ID;?>"><?php echo $gs->MSTR_NM;?></option><?php
                        }//end of else statement
                        } //End of for loop
                    ?>
                    </select> <!--end of drop down box for global settings-->
                </div><!-- End of control group -->
                </div> <!--End of controls -->
            
                                                                                                        
                    <?php if($lvs_getMenuDetails ==  true) 
                          { //Start for if statement to verify for menudetails
                    ?>
                <div class="control-group">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Link to Menu</label> <!--label for Link to Menu-->
                    <div class="controls">
                     <!-- Start of control group -->
                    <input type="checkbox" name="chkMenu"  value="" id="chkMenu"  checked >	 <!--set Input type as checkbox-->
                   </div><!-- End of control group -->
                 </div> <!--End of controls -->
            
                  <?php 
                    }//ebd of if statement for menudetails
                    else
                    { //start of else statement
                    ?>          
            
                <div class="control-group">
                 <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Link to Menu</label> <!--Label for Link to menu-->
                    <div class="controls">
                     <!-- Start of control -->
                    <input type="checkbox" name="chkMenu"  value="" id="chkMenu"  >	 <!--Set input type as Checkbox-->
                                 
                    </div><!-- End of control group -->
                 </div> <!--End of controls -->
                <?php 
                    }// end of else statement
                ?>
            
                <div class="control-group" id="menu" style="display:none;">
                <!-- Start of control group -->
                    <label class="control-label" for="focusedInput">Menu </label> <!--label for Menu-->
                <div class="controls">
                <!-- Start of control group -->
                    <select id="menuID" name="menuID" data-rel="chosen"> <!--Drop down for Menu-->
                    <option value="">Select an Option</option>
                <?php
                    echo $lvs_repopulateMenu->target_entity;//Diplay Menu
                    foreach($lva_menuName as $m)
                    {//Start of for loop for menu
            
                    if($m->MSTR_ID == $lvs_repopulateMenu->TRGT_ENTTY_ID)
                    { //start of if statement for menu
                ?><option value="<?php echo $m->MSTR_ID;?>" selected="selected"><?php echo $m->MSTR_NM;?></option><?php
                    } //end of if statement for menu
                    else
                    { //start of else
                    ?><option value="<?php echo $m->MSTR_ID;?>"><?php echo $m->MSTR_NM;?></option><?php
                    } //end of else
                    } // end of for loop for menu
                ?>
                    </select>  <!--end of drop down for menu-->
                    <!-- Start of hidden inputs -->
                    <input  name='master_id' type='hidden' readonly value="<?php echo set_value('master_id',$master_id);?>"  />
                    <!--end of hidden input-->
                </div><!--End of control group -->
                </div><!-- End of control -->
                 
                
                                          
            
                <div class="form-actions">
                <!-- Start of Form Actions -->
                    <input type="submit" class="btn btn-primary" value="Saves Changes"> <!--Button for submit-->
                   <?php echo anchor('common/indp_mst_data','Cancel',array('class'=>'btn')); ?>
                </div><!-- End of form Actions -->
                </fieldset><!-- End of field set-->
                </form><!-- End of form -->
        
        </div>
        </div><!--/span-->
        </div>
           
        
        </div><!--/fluid-row-->
        </div><!--/row-->

    </div><!--End of content.span10-->
    </div><!--/fluid-row-->
	<hr>
	</div><!--/.fluid-container-->

		
</body><!-- end of body-->
</html><!-- end of HTMl tag-->
