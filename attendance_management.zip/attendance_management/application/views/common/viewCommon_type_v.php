<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)Edit CommonType/System Entity View						*/
/*   Code Modifications	:                                                             */
/*----------------------------------------------------------------------------------------*/

?>

<script>
 $( document ).ready(function() { 
 if ($("#chkParentID").is(':checked')){
    $("#parentID").show();
}else{
	$("#parentID").hide();
}
  
     $('#chkParentID').click(function(){
		 
		 var thisCheck = $('#chkParentID');
if (thisCheck.is (':checked'))

{
// Do stuff
 $('#parentID').show();
}else
{
	 $('#parentID').hide();
}
         
     
    });
 });


$(function() {
    $('#type_code').keyup(function() {
        $(this).val($(this).val().toUpperCase());
    });
});
</script> 
		<!-- topbar starts -->
		<!-- topbar ends -->
		
			<!-- left menu starts -->
			<?php 
			//$this->load->view('include/left_menu.php');
			?><!--/span-->
			<!-- left menu ends -->

			<!-- content starts -->
			
			<!-- breadcrumb starts -->
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="#">Home</a> <span class="divider">/</span>
					</li>
					<li>
						<a href="#">System Entity</a>
					</li>
				</ul>
			</div>
            <!-- breadcrumb ends -->
                    
<!-- Start of alert to display the form messages -->
<?php if($this->session->flashdata('success')) {?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">×</button>
	<?php echo $this->session->flashdata('success'); ?>
</div>
<?php } ?>
<!-- End of alert to display the form messages -->

					  <div class="row-fluid sortable">
				<div class="box span12" >
					<div class="box-header well" data-original-title>
						<h2><i class="icon-picture"></i><?php echo $title; ?></h2>
                        <div class="box-icon">
							<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
                  </div>
					
					<div class="box-content">
      
						<form class="form-horizontal" action="<?php if(isset($action)) echo $action;?>" method="post" >
							<fieldset>
                            
							  <div class="control-group  <?php if(form_error('type_code'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Type Code<span style="color:red;">*</span> </label>
									<div class="controls">
										<input type="text" name="type_code" maxlength="4" id="type_code" value="<?php if(isset($type_code)) echo $type_code; else echo set_value('type_code');?>" > 
                       					 <span class="help-inline">
                                          <?php echo form_error('type_code'); ?>
          								</span>		
									</div>
							  </div>
							  
                              
                              <div class="control-group <?php if(form_error('type_name'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">Type Name<span style="color:red;">*</span> </label>
									<div class="controls">
 										<input type="text" name="type_name" id="type_name" value="<?php if(isset($type_name)) echo $type_name; else echo set_value('type_name');?>">	
 										<span class="help-inline">
                                          <?php echo form_error('type_name'); ?>
          								</span>											 																		 								
 									</div>
							  </div>
                              
                              
                              <div class="control-group <?php if(form_error('view_name'))  echo 'error'; ?>">
								<label class="control-label" for="focusedInput">View Name<span style="color:red;">*</span> </label>
										<div class="controls">
								  			 <input type="text" name="view_name" id="view_name" value="<?php if(isset($view_name)) echo $view_name; else echo set_value('view_name');?>"  >
                                        <span class="help-inline">
                                              <?php echo form_error('view_name'); ?>
                                        </span>
										</div>
							  </div>
                              
                              <?php  
							  if($parentTypeID > 0 )
							  {//start of if($parentTypeID > 0 ) 
							  
							  ?>
                              
                                   <div class="control-group ">
                                    <label class="control-label" for="focusedInput">Set Parent Type</label>
                                        <div class="controls">
                                            <input type="checkbox" name="chkParentID"  value="" id="chkParentID" checked >	
                                                                            
                                        </div>
                                  </div>
                                  
                              <?php 
							  }
							  else
							  {
								  				  
							  
							  
							  ?>
                               <div class="control-group ">
								<label class="control-label" for="focusedInput">Set Parent Type</label>
									<div class="controls">
 										<input type="checkbox" name="chkParentID"  value="" id="chkParentID"  >	
 										 								
 									</div>
							  </div>
                              <?php
							  //End of else($parentTypeID > 0 )
							  } ?>
                              
                                          <div class="control-group" id="parentID">
								<label class="control-label" for="focusedInput">Parent Type </label>
								<div class="controls">
      
								  
                               
                               
                                <select name="parent_id" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($typename as $list)
									  {//start of foreach($TYP_NM as $list)
										  
									   if($list->TYP_ID==$parentTypeID)
									   {//start of if($list->TYP_ID==$parentTypeID)
										?>
                                        <option value="<?php echo $list->TYP_ID;?>" selected="selected"><?php echo $list->TYP_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->TYP_ID;?>" ><?php echo $list->TYP_NM;?></option><?php
									   }//end of if($list->TYP_ID==$parentTypeID)
									 }//end of foreach($TYP_NM as $list)
                                  ?>
								 
     							</select>
								</div>
							  </div>
                              
      
     				<!-- start of hidden inputs -->
                    <input name="type_id" type="hidden" value="<?php echo set_value('type_id', $type_id); ?>">
                   	<!-- end of hidden inputs -->
     
    
                              
                              
							  <div class="form-actions">
								<input type="submit" class="btn btn-primary" value="Saves Changes">
								 <?php echo anchor('common/common_type','Cancel',array('class'=>'btn')); ?>
							  </div>
							</fieldset>
						  </form>
					
					</div><!--/class="box-content"-->
				</div><!--/span-->
			
			</div><!--/class="row-fluid sortable"-->
       
    
</div><!--/fluid-row-->
				
	
        
		
		
	</div>

			<!--/row-->

			<!--/row-->
				  

		  
       
					<!-- content ends -->
			</div><!--/#content.span10-->
				</div><!--/fluid-row-->
				
		<hr>

		
	</div><!--/.fluid-container-->

		
</body>
</html>
