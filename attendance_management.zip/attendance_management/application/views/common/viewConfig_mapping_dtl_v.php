<!-- Start of Breadcrumb -->
<div>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo site_url('common/config_mapping_dtl');?>">
Config Mapping Details</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="#"><?php echo $title;?></a>
		</li>
	</ul>
</div>
<!-- End of Breadcrumb -->

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title="">
			<h2><i class="icon-plus"></i> <?php echo $title;?></h2>
			<div class="box-icon">
			<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
			<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
			<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
			</div>
		</div>
		<div class="box-content">
        	<form class="form-horizontal" action="<?php echo $action;?>" method="POST">
				<fieldset>
					
                    
                    <!-- Start Of Form Controls   -->
                                        
                    <!--start Of div-->
                  
                     <div class="control-group" id="parentID">
								<label class="control-label" for="focusedInput">Module Name </label>
								<div class="controls">
                                <select name="SRC_ENTTY_ID" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($sourceEntityDropDown as $list)
									  {//start of foreach($CountryDrop as $list)
										  
									   if($list->MSTR_ID==$SRC_ENTTY_ID)
									   {//start of ($list->MSTR_ID==$Country_ID)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?><option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option><?php
									   }//end of ($list->MSTR_ID==$Country_ID)
									 }//end of foreach($CountryDrop as $list)
                                  ?>
								 
     							</select>
								</div>
						</div>
                    <!--end Of div-->
                    <!--start Of div-->
                    
                   <div class="control-group">
						<label class="control-label">Menu</label>
						<div class="controls">
                                <select name="menu" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($menuDropdown as $list)
									  {//start of foreach($CountryDrop as $list)
										  
									   if($list->MSTR_ID==$TRGT_ENTTY_ID)
									   {//start of ($list->MSTR_ID==$Country_ID)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option>
										<?php
									   }//end of ($list->MSTR_ID==$Country_ID)
									 }//end of foreach($CountryDrop as $list)
                                  ?>
								 
     							</select>
								</div>
						</div>
					
                    <!--end Of div-->
                    
                    
                     <!--start Of div-->
                    
                   <div class="control-group">
						<label class="control-label">Global Settings</label>
						<div class="controls">
                                <select name="gs" data-rel="chosen">
                                <option value="">Select an option</option>
                                <?php
									  foreach($gsDropdown as $list)
									  {//start of foreach($CountryDrop as $list)
										  
									   if($list->MSTR_ID==$TRGT_ENTTY_ID)
									   {//start of ($list->MSTR_ID==$Country_ID)
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" selected="selected"><?php echo $list->MSTR_NM;?></option>
										<?php
									   }
									   else
									   {
										?>
                                        <option value="<?php echo $list->MSTR_ID;?>" ><?php echo $list->MSTR_NM;?></option>
										<?php
									   }//end of ($list->MSTR_ID==$Country_ID)
									 }//end of foreach($CountryDrop as $list)
                                  ?>
								 
     							</select>
								</div>
						</div>
					
                    <!--end Of div-->
                    
                     <!-- start of hidden inputs -->
                    <input name="CNFG_MPPNG_DTL_ID" type="hidden" value="<?php echo set_value('CNFG_MPPNG_DTL_ID', $CNFG_MPPNG_DTL_ID); ?>"> 
                    <!-- end of hidden inputs -->
 
                    <!-- end Of Form Controls   -->       
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<?php echo anchor('common/config_mapping_dtl','Cancel',array('class'=>'btn')); ?>
					</div>
				</fieldset> 
			</form>  
		</div>
	</div><!--/span-->

</div>