<?php 
/*---------------------------------------------------------------------------------------*/
/*   Author       		: Ankit Dedhia                                                */
/*   Date         		: Oct 2013                                                 */
/*   Synopsis     		: Code for
							1)Idependent Master View						*/
/*   Code Modifications	:  Modified on 06-12-12 -Celine M Rodrigues                                                       */
/*----------------------------------------------------------------------------------------*/
?>
		<!-- content starts -->
		<div>
        <!-- Start of breadcrumb div -->
			<ul class="breadcrumb">
				<li>
					<a href="#">Home</a> <span class="divider">/</span>
				</li>
				<li>
					<a href="#"><?php echo $title; ?></a><!-- Diplay of title from controller -->
				</li>
			</ul>
		</div><!-- End of breadcrumb div-->

 		<!-- Start of alert to display the form messages -->
		<?php if($this->session->flashdata('success')) {?>
		<div class="alert alert-success">
        <!-- Start of Alert div -->
			<button type="button" class="close" data-dismiss="alert">×</button>
			<?php echo $this->session->flashdata('success'); ?>
		</div><!-- End of alert div -->
		<?php } ?>
		<!-- End of alert to display the form messages -->          
            
		<div class="row-fluid sortable">	
        <!-- Start of row fluid sortable -->	
			<div class="box span12">
            <!-- Start of box span -->
				<div class="box-header well" data-original-title>
                <!-- Start of box header well-->
					<h2><i class=""></i> <?php echo $title; ?></h2>
					<div class="box-icon">
                    <!-- Start of box icon -->
						<a href="<?php echo site_url('entity/entity_obj_attrbt/index/independent_mst'); ?>" class="btn btn-round-new"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
					</div> <!-- Start of box icon -->
				</div> <!-- Start of box header well-->
                      
                 <div class="box-content">
                   <!-- Start of Box Content-->  

                 <!-- Start of Script of Type Id/Search-->
					<script>
						$(document).ready(function(){
 						$('#typeID').change(function(){
					    var vIntTypeID=document.getElementById("typeID").value;
	 					var base_url= "<?php echo site_url('common/indp_mst_data/changeType	');?>";
						base_url += "/"+vIntTypeID;
  						//alert(base_url);
  						 window.location.href = base_url;
						 });
						 });
					</script> <!-- End of Script of Type ID/Search-->

					<p style = "display: inline-block;vertical-align: super;">System Entity</p>
    
    
					<select id="typeID" name="typeID" data-rel="chosen" > <!-- Start of Drop Down box for Type id/Search-->
    					<option value="0">Select an Option</option>
							<?php
								foreach($lva_getAllCommonTypeValue as $lvs_type)
								{ //start of for loop 
									if($lvs_type->TYP_ID == $this->session->userdata('typeID')){//start of if statement
									?><option value="<?php echo $lvs_type->TYP_ID;?>" selected="selected"><?php echo $lvs_type->TYP_NM;?></option					 									><?php
									}//end of if statement
									else
									{//start of else statement
									?><option value="<?php echo $lvs_type->TYP_ID;?>"><?php echo $lvs_type->TYP_NM;?></option><?php
									}//end of else statement
								}//end of for loop
           					 ?>
					</select>
             <!-- End of Drop Down box for typeid/Search-->
                    <div style="float:right"><a class="btn btn-info" href="<?php echo site_url('common/indp_mst_data/addIndependentData/'); ?>"><i class="icon-edit icon-white"></i> Add New</a></div>
                  	<br><br>
                   <table class="table table-striped table-bordered bootstrap-datatable datatable"> <!-- Start of diplay Table-->
                  	 <thead> <!-- Start of titles-->
                    	<tr>
           					<?php
							if (validateColVisibility('MSTR_ID',$visibleCol)) 
							{
							?>
                            			<th>Master ID</th>
                            <?php
							}
							?>
							
							<?php
							if (validateColVisibility('MSTR_CD',$visibleCol)) 
							{
							?>
                            			<th>Master Code</th>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('MSTR_NM',$visibleCol)) 
							{
							?>
                            			<th>Master Name</th>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('TYP_ID',$visibleCol)) 
							{
							?>
                          				<th>System Entity </th>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('RECORD_TYP',$visibleCol)) 
							{
							?>                      	
                          				<th>Record Type </th>
                            <?php
							}
							?>
                            
                            <?php
							if (validateColVisibility('OA_ID',$visibleCol)) 
							{
							?>
                          				<th>Organisation Code </th>
                            <?php
							}
							?>
                            
                            <?php
							if (validateColVisibility('IS_DELETED',$visibleCol)) 
							{
							?>
                          				<th>Deleted</th>
                            <?php
							}
							?>
                            
                            <?php
							if (validateColVisibility('CREATED_BY',$visibleCol)) 
							{
							?>
                          				<th>Created By</th>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('UPDATED_BY',$visibleCol)) 
							{
							?>
                          				<th>Updated By</th>
                            <?php
							}
							?>
                            
                            <?php
							if (validateColVisibility('CREATED_ON',$visibleCol)) 
							{
							?>
                          				<th>Created On</th>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('UPDATED_ON',$visibleCol)) 
							{
							?>
                          				<th>Updated On</th>
                            <?php
							}
							?>
                         	<th>Actions</th>
                    	</tr>
                    </thead> <!--End of title-->
                    <tbody>
                    <?php
					foreach($idp_type as $list)
					{
					?>
                        <tr>
                        
                        
                        	<?php
							if (validateColVisibility('MSTR_ID',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->MSTR_ID;?></td>
                            <?php
							}
							?>
							<?php
							if (validateColVisibility('MSTR_CD',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->MSTR_CD ;?></td>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('MSTR_NM',$visibleCol)) 
							{
							?>
                        				<td><?php echo $list->MSTR_NM;?></td>
                            <?php
							}
							?>
                       		<?php
							if (validateColVisibility('TYP_ID',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->system_entity;?></td>
                            <?php
							}
							?>
                             <?php
							if (validateColVisibility('RECORD_TYP',$visibleCol)) 
							{
							?>
                          				<td><?php if($list->RECORD_TYP) echo "User"; else echo "System";?></td>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('OA_ID',$visibleCol)) 
							{
							?>
                          				<td><?php echo $list->OA_NM;?></td>
                            <?php
							}
							?>
                            
                             <?php
							if (validateColVisibility('IS_DELETED',$visibleCol)) 
							{
							?>
                          				<td><?php if($list->IS_DELETED =='1') echo "Yes"; else "No";?></td>
                            <?php
							}
							?>
                            
                            <?php
							if (validateColVisibility('CREATED_BY',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->Created_by_name;?></td>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('UPDATED_BY',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->Updated_by_name;?></td>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('CREATED_ON',$visibleCol)) 
							{
							?>
                            			<td><?php echo $list->CREATED_ON;?></td>
                            <?php
							}
							?>
                            <?php
							if (validateColVisibility('UPDATED_ON',$visibleCol)) 
							{
							?>
                           			  <td><?php echo $list->UPDATED_ON;?></td>
                        	<?php
							}
							?>
                            <td width="180">
                            <a href="<?php echo site_url('common/indp_mst_data/editIndependentData/'.$list->MSTR_ID); ?>"><span title="Edit" class="icon icon-color icon-edit"></span></a>&nbsp;
    						<a  href="<?php echo site_url('common/indp_mst_data/deleteIndpMstData/'.$list->MSTR_ID); ?>" onClick="return confirmDialog();"><span title="Delete" class="icon icon-color icon-trash"></span></a>
                       </td>
                      </tr>
					<?php	
						}
					?>
                    </tbody>
                    </table>
                    
				</div> <!-- End of box content-->
		</div><!--span -->
	</div>   <!--row -->
	 <?php
	 //start of message display
		if((isset($msg))&&($msg!=''))
		{
      	 echo '<script> javascript:alert("'.str_replace(array("\r","\n"), '', $msg).'"); 
			   </script>';
		}
	 //End of display message
	?>
		  
       
			<!-- content ends -->
            </div><!--/#content.span10-->
			</div><!--/fluid-row-->
			<hr>
			</div><!--/.fluid-container-->

		
	</body>

	</html>
