-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2014 at 04:31 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mf3`
--

-- --------------------------------------------------------

--
-- Table structure for table `address_mst`
--

CREATE TABLE IF NOT EXISTS `address_mst` (
  `ADDRESS_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Address id is primary key of this table',
  `FLAT_NO` varchar(10) DEFAULT NULL COMMENT 'Flat number',
  `HOUSE_NO` varchar(10) NOT NULL COMMENT 'House number ',
  `HOUSE_NAME` varchar(10) NOT NULL COMMENT 'House name',
  `ADDRESS_LINE_1` varchar(40) NOT NULL COMMENT 'Address line 1',
  `ADDRESS_LINE_2` varchar(40) DEFAULT NULL COMMENT 'Address line 2',
  `ADDRESS_LINE_3` varchar(40) DEFAULT NULL COMMENT 'Address line 3',
  `DWELLING_TYPE_ID` int(10) DEFAULT NULL COMMENT 'Type id of dwell',
  `STREET_ID` int(10) DEFAULT NULL COMMENT 'Street id',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation id',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`ADDRESS_ID`),
  KEY `FK_ADDRESSMST_DWELLINGTYPEID` (`DWELLING_TYPE_ID`),
  KEY `FK_ADDRESSMST_STREETID` (`STREET_ID`),
  KEY `FK_ADDRESSMST_OAID` (`OA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Addresses' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `application_dtl`
--

CREATE TABLE IF NOT EXISTS `application_dtl` (
  `APP_DETAIL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key auto generated unique running sequence number',
  `APP_ID` int(10) NOT NULL COMMENT 'Application ',
  `FUNCTION_ID` int(10) DEFAULT NULL COMMENT 'Module',
  `EPIC_ID` int(10) DEFAULT NULL COMMENT 'Functional Area',
  `FEATURE_ID` int(10) DEFAULT NULL COMMENT 'Functional Section',
  `OPTIONAL_THEME_ID` int(10) DEFAULT NULL COMMENT 'Theme',
  `ENABLED` tinyint(1) DEFAULT '1' COMMENT 'Flag to enable or disable the hierarchy element',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'Created by user name',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'updated by user name',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was updated',
  PRIMARY KEY (`APP_DETAIL_ID`),
  KEY `FK_APPLICATIONDTL_APPID` (`APP_ID`),
  KEY `FK_APPLICATIONDTL_FUNCTIONID` (`FUNCTION_ID`),
  KEY `FK_APPLICATIONDTL_EPICID` (`EPIC_ID`),
  KEY `FK_APPLICATIONDTL_FEATUREID` (`FEATURE_ID`),
  KEY `FK_APPLICATIONDTL_OPTIONALTHEMEID` (`OPTIONAL_THEME_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This is an redundant table. The information stored in this table will be managed in relatioship details table under application hierarchy' AUTO_INCREMENT=27 ;

--
-- Dumping data for table `application_dtl`
--

INSERT INTO `application_dtl` (`APP_DETAIL_ID`, `APP_ID`, `FUNCTION_ID`, `EPIC_ID`, `FEATURE_ID`, `OPTIONAL_THEME_ID`, `ENABLED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 474, 498, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(2, 474, 499, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(3, 474, 500, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(4, 474, 501, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(5, 474, 502, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(6, 474, 503, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(7, 474, 504, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(8, 474, 505, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(9, 474, 506, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(10, 474, 507, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(11, 474, 508, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(12, 474, 509, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(13, 474, 510, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(14, 474, 511, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(15, 474, 512, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(16, 474, 513, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(17, 474, 514, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(18, 474, 515, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(19, 474, 516, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(20, 474, 517, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(21, 474, 518, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(22, 474, 525, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(23, 474, 528, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),
(26, 474, 543, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `appl_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `appl_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `area_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `area_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `board_of_dirs_mst_vw`
--
CREATE TABLE IF NOT EXISTS `board_of_dirs_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `buss_layer_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `buss_layer_obj_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `cast_mst_vw`
--
CREATE TABLE IF NOT EXISTS `cast_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `city_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `city_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `cntrllr_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `cntrllr_obj_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `common_type`
--

CREATE TABLE IF NOT EXISTS `common_type` (
  `TYP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'System Entity type identifier. Its a Auto number primary key sequence',
  `TYP_CD` varchar(5) NOT NULL COMMENT 'System entity type code. This is a not null field',
  `TYP_NM` varchar(40) NOT NULL COMMENT 'System entity type Name. This is a not null field',
  `VIEW_NM` varchar(40) DEFAULT NULL COMMENT 'System entity view name',
  `PARENT_TYP_ID` int(10) DEFAULT NULL COMMENT 'Parent Type identifier. This is an optional Field.',
  `IS_EDITABLE` tinyint(1) DEFAULT '1' COMMENT 'Flag to mark the record editable. True means editable, false means non editable',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark the record for soft delete. Once Spft deleted the record willnot be visible to non admin users. Non editable records cannnot be deleted',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Optional Organisation account identifier',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who crrated this record',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated the record',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record is created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'date and time when the record was editable',
  `IS_PREDEFINED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark that the role is a predefined system value',
  PRIMARY KEY (`TYP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores all the types used in the system. This typically holds system defined data types and is referred by most of the system entities' AUTO_INCREMENT=197 ;

--
-- Dumping data for table `common_type`
--

INSERT INTO `common_type` (`TYP_ID`, `TYP_CD`, `TYP_NM`, `VIEW_NM`, `PARENT_TYP_ID`, `IS_EDITABLE`, `IS_DELETED`, `OA_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`, `IS_PREDEFINED`) VALUES
(1, 'SPT', 'System Permission Type', 'SYSTEMPERMISIONTYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(2, 'GSDVT', 'Global Setting Data value Type', 'GSDATAVALUETYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(6, 'EMT', 'Exception Message Type', 'EXCEPTION_MESSAGE_TYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(7, 'EMTSI', 'System Information', 'EMT_SYS_INFO_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(8, 'EMTSW', 'System Warning', 'EMT_SYS_WARN_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(9, 'EMTSE', 'System Errors', 'EMT_SYS_ERR_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(10, 'EMTUI', 'User Information', 'EMT_USR_INFO_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(11, 'EMTUW', 'User Warning', 'EMT_USR_WARN_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(12, 'EMTUE', 'User Errors', 'EMT_USR_ERR_MST_VW', 6, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(17, 'OLT', 'Object Layer Type', 'OBJ_LAYER_TYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(18, 'BLO', 'BusinessLayerObjects', 'BUSS_LAYER_OBJ_MST_VW', 17, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(19, 'DLO', 'DataLayerObjects', 'DATA_LAYER_OBJ_MST_VW', 17, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(20, 'PLO', 'PresentationLayerObjects', 'PRSNTTN_LAYER_OBJ_MST_VW', 17, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(21, 'MO', 'ModelObjects', 'MODEL_OBJ_MST_VW', 18, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(22, 'VO', 'ViewObjects', 'VIEW_OBJ_MST_VW', 19, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(23, 'CO', 'ControllerObjects', 'CNTRLLR_OBJ_MST_VW', 20, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(24, 'EOT', 'Entity Object Type', 'ENTITY_OBJ_TYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(25, 'IOT', 'InterfaceObjectType', 'INFACE_OBJ_TYPE_MST_VW', 24, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(26, 'DOT', 'DBObjectType', 'DB_OBJ_TYPE_MST_VW', 24, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(27, 'POT', 'ProcessObjectType', 'PRCSS_OBJ_TYPE_MST_VW', 24, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(28, 'IOTF', 'Forms', 'FORM_MST_VW', 25, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(29, 'IOTT', 'Toolbars', 'TOOLBAR_MST_VW', 25, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(30, 'IOTMI', 'Menu item', 'MENU_ITEM_MST_VW', 25, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(31, 'DOTTB', 'DBTables', 'DB_TABLES_MST_VW', 26, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(32, 'DOTVW', 'DBViews', 'DB_VIEWS_MST_VW', 26, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(33, 'DOTTR', 'DBTriggers', 'DB_TRIGGERS_MST_VW', 26, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(34, 'DOTFN', 'DBFunctions', 'DB_FUNCATIONS_MST_VW', 26, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(35, 'DOTPR', 'DBProcedures', 'DB_PROCS_MST_VW', 26, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(36, 'POTGS', 'Global Setting item', 'GLOBAL_SETTING_ITEM_MST_VW', 27, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(41, 'OAST', 'Organisation Account Setting Attributes', 'ORGACCT_SETTINGS_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(42, 'OAST', 'Organisation Status', 'ORGACCT_STATUS_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(46, 'US', 'User Status', 'USER_STATUS_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(47, 'UCT', 'User Contact Type', 'USER_CONTACT_TYPE_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(51, 'HT', 'HierarchyType', 'HIERARCHY_TYPE_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(52, 'HTCH', 'CompanyHierarchy', 'COMP_HIER_MST_VW', 51, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(53, 'HTCHG', 'Group', 'GROUP_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(54, 'HTCHC', 'Company', 'COMPANY_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(55, 'HTCHD', 'Division', 'DIVISION_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(56, 'HTCHL', 'Location', 'LOCATION_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(57, 'HTCHD', 'Department', 'DEPT_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(58, 'HTCHS', 'SubDepartment', 'SUBDEPT_NAME_MST_VW', 52, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(59, 'HTGH', 'GeographicalHierarchy', 'GEO_HIER_MST_VW', 51, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(60, 'HTGHC', 'Continent', 'CONTINENT_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(61, 'HTGHC', 'Country', 'COUNTRY_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(62, 'HTGHS', 'State', 'STATE_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(63, 'HTGHC', 'County', 'COUNTY_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(64, 'HTGHD', 'District', 'DISTRICT_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(65, 'HTGHC', 'City', 'CITY_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(66, 'HTGHT', 'Town', 'TOWN_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(67, 'HTGHA', 'Area', 'AREA_NAME_MST_VW', 59, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(68, 'GHTMH', 'ManagementHiearahcy', 'MNGT_HIER_MST_VW', 51, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(69, 'GHTMH', 'Executive Management', 'EXE_MNGMNT_MST_VW', 68, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(70, 'GHTMH', 'Board of Directors', 'BOARD_OF_DIRS_MST_VW', 68, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(71, 'GHTMH', 'Directors', 'DIRECTORS_MST_VW', 68, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(72, 'GHTMH', 'Head of Department', 'HOD_MST_VW', 68, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(73, 'GHTMH', 'Manager', 'MANAGER_MST_VW', 68, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(74, 'HTSWA', 'SW Application Hiearchy', 'SW_APP_HIER_MST_VW', 51, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(75, 'HTSWA', 'Application', 'APPL_NAME_MST_VW', 74, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(76, 'HTSWA', 'Module Function', 'MODULE_NAME_MST_VW', 74, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(77, 'HTSWA', 'Functional Epic', 'EPIC_NAME_MST_VW', 74, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(78, 'HTSWA', 'Functional Feature', 'FEATURE_NAME_MST_VW', 74, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(79, 'HTSWA', 'Funcational Theme', 'THEME_NAME_MST_VW', 74, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(80, 'HTMH', 'MenuHierarchy', 'MENU_HIER_VW', 51, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(101, 'MT', 'Mail Type', 'MAIL_TYPE_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(102, 'EN', 'Email Notification', 'EML_NOTIFICATION_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(121, 'CONT', 'Continent', 'CONTINENT_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(122, 'COUN', 'Country', 'COUNTRYNAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(123, 'STAT', 'State', 'STATNAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(124, 'DIST', 'District', 'DISTRICTNAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(125, 'CITY', 'City', 'CITINAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(126, 'TOWN', 'Town', 'TOWNNAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(127, 'SUBE', 'suburb', 'SUBURBNAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(128, 'AIRP', 'Airport', 'AIRPORT_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(131, 'Curr', 'Currency', 'CURRENCY_NAME_MST_VW', NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(132, 'SLTT', 'Salutation', 'SALUTATION_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(133, 'GNDR', 'Gender', 'GENDER_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(134, 'MSTT', 'Marrital Status', 'MARRITAL_STATUS_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(135, 'CAST', 'Cast', 'CAST_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(136, 'RACE', 'Race', 'RACE_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(137, 'CRT', 'Contact Relationship Type', 'CONTACT_RELATION_TYPE_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(138, 'NPCT', 'Non Personal Contact Type', 'NON_PERSONAL_CONTACT_TYPE_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(139, 'NTNLT', 'Nationality', 'NATIONALITY_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(140, 'PNT', 'Phone Number Type', 'PHONE_NUMBER_TYPE_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(141, 'EAUT', 'Email Account Use Type', 'EMAIL_ACCOUNT_USE_TYPE_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(142, 'CAT', 'Contact Address Type', 'CONTACT_ADDRESS_TYPE_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(143, 'RLGN', 'Religion', 'RELEGION_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(144, 'ETHN', 'Ethinicity', 'ETHINICITY_MST_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(186, 'LT', 'Leave Type', 'LEAVE_TYPE_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(196, 'PS', 'Performance Status ', 'PERFORMANCE_STATUS_VW', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `company_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `company_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `comp_hier_mst_vw`
--
CREATE TABLE IF NOT EXISTS `comp_hier_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `config_mapping_dtl`
--

CREATE TABLE IF NOT EXISTS `config_mapping_dtl` (
  `CNFG_MPPNG_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'A',
  `SRC_ENTTY_ID` int(10) NOT NULL COMMENT 'A',
  `TRGT_ENTTY_ID` int(10) NOT NULL COMMENT 'A',
  `CNFG_MPPNG_TYP_ID` int(10) NOT NULL COMMENT 'A',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'A',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'A',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'A',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  PRIMARY KEY (`CNFG_MPPNG_DTL_ID`),
  KEY `FK_CONFIGMAPPINGDTL_SRCENTTYID` (`SRC_ENTTY_ID`),
  KEY `FK_CONFIGMAPPINGDTL_TRGTENTTYID` (`TRGT_ENTTY_ID`),
  KEY `FK_CONFIGMAPPINGDTL_CNFGMPPNGTYPID` (`CNFG_MPPNG_TYP_ID`),
  KEY `FK_CONFIGMAPPINGDTL_OABRANDID` (`OA_BRAND_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='A' AUTO_INCREMENT=80 ;

--
-- Dumping data for table `config_mapping_dtl`
--

INSERT INTO `config_mapping_dtl` (`CNFG_MPPNG_DTL_ID`, `SRC_ENTTY_ID`, `TRGT_ENTTY_ID`, `CNFG_MPPNG_TYP_ID`, `OA_BRAND_ID`, `CREATED_ON`, `UPDATED_ON`, `CREATED_BY`, `UPDATED_BY`) VALUES
(52, 498, 477, 30, NULL, '2014-04-05 05:29:32', '0000-00-00 00:00:00', NULL, NULL),
(53, 499, 478, 30, NULL, '2014-04-05 05:30:30', '0000-00-00 00:00:00', NULL, NULL),
(54, 500, 479, 30, NULL, '2014-04-05 05:31:06', '0000-00-00 00:00:00', NULL, NULL),
(55, 501, 480, 30, NULL, '2014-04-05 05:32:03', '0000-00-00 00:00:00', NULL, NULL),
(56, 502, 497, 30, NULL, '2014-04-05 05:32:32', '0000-00-00 00:00:00', NULL, NULL),
(57, 503, 481, 30, NULL, '2014-04-05 05:33:10', '0000-00-00 00:00:00', NULL, NULL),
(58, 504, 482, 30, NULL, '2014-04-05 05:33:40', '0000-00-00 00:00:00', NULL, NULL),
(59, 505, 483, 30, NULL, '2014-04-05 05:34:57', '0000-00-00 00:00:00', NULL, NULL),
(60, 506, 484, 30, NULL, '2014-04-05 05:35:22', '0000-00-00 00:00:00', NULL, NULL),
(61, 507, 485, 30, NULL, '2014-04-05 05:35:48', '0000-00-00 00:00:00', NULL, NULL),
(62, 508, 496, 30, NULL, '2014-04-05 05:36:16', '0000-00-00 00:00:00', NULL, NULL),
(63, 509, 486, 30, NULL, '2014-04-05 05:36:40', '0000-00-00 00:00:00', NULL, NULL),
(64, 510, 487, 30, NULL, '2014-04-05 05:37:17', '0000-00-00 00:00:00', NULL, NULL),
(65, 511, 488, 30, NULL, '2014-04-05 05:37:45', '0000-00-00 00:00:00', NULL, NULL),
(66, 512, 489, 30, NULL, '2014-04-05 05:38:17', '0000-00-00 00:00:00', NULL, NULL),
(67, 513, 490, 30, NULL, '2014-04-05 05:38:46', '0000-00-00 00:00:00', NULL, NULL),
(68, 514, 491, 30, NULL, '2014-04-05 05:39:14', '0000-00-00 00:00:00', NULL, NULL),
(69, 515, 492, 30, NULL, '2014-04-05 05:39:56', '0000-00-00 00:00:00', NULL, NULL),
(70, 516, 493, 30, NULL, '2014-04-05 05:40:23', '0000-00-00 00:00:00', NULL, NULL),
(71, 517, 494, 30, NULL, '2014-04-05 05:40:50', '0000-00-00 00:00:00', NULL, NULL),
(72, 518, 495, 30, NULL, '2014-04-05 05:41:15', '0000-00-00 00:00:00', NULL, NULL),
(75, 525, 524, 30, NULL, '2014-04-05 07:06:12', '0000-00-00 00:00:00', NULL, NULL),
(76, 528, 527, 36, NULL, '2014-04-05 09:26:30', '0000-00-00 00:00:00', NULL, NULL),
(77, 528, 526, 30, NULL, '2014-04-05 09:26:30', '0000-00-00 00:00:00', NULL, NULL),
(79, 543, 536, 30, NULL, '2014-04-08 05:35:01', '0000-00-00 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact_address`
--

CREATE TABLE IF NOT EXISTS `contact_address` (
  `CNTCT_ADD_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key  of the contact address table  ',
  `CNTCT_ID` int(10) NOT NULL COMMENT 'Contact id is identifier represents the respective id of the contact address',
  `CNTCT_ADD_TYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from independent master table',
  `ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from address master table',
  `CNTCT_ADD_START_DATE` datetime DEFAULT NULL COMMENT 'Contact add start date',
  `CNTCT_ADD_END_DATE` datetime DEFAULT NULL COMMENT 'Contact add end date',
  `OA_ID_ORIGINATED` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation accounts table',
  `IS_CURRENT_ADD` tinyint(1) DEFAULT '0' COMMENT 'Flag to check whether it is current address or not',
  `IS_PRIMARY_ADD` tinyint(1) DEFAULT '0' COMMENT 'Flag to check whether it is primary address or not',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`CNTCT_ADD_ID`),
  KEY `FK_CONTACTADDRESS_CNTCTID` (`CNTCT_ID`),
  KEY `FK_CONTACTADDRESS_CNTCTADDTYPEID` (`CNTCT_ADD_TYPE_ID`),
  KEY `FK_CONTACTADDRESS_ADDID` (`ADD_ID`),
  KEY `FK_CONTACTADDRESS_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTADDRESS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTADDRESS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Contact Address definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `contact_address_type_vw`
--
CREATE TABLE IF NOT EXISTS `contact_address_type_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `contact_add_phoneno`
--

CREATE TABLE IF NOT EXISTS `contact_add_phoneno` (
  `CNTCT_ADD_PHONENO_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key  of the  contact address phone number table  ',
  `CNTCT_ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact address table',
  `CNTCT_NBR_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact number table',
  `OA_ID_ORIGINATED` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation account table',
  `IS_PRIMARY_TELNO` tinyint(1) DEFAULT '0' COMMENT 'Flag to check whether it is primary telephone number or not',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`CNTCT_ADD_PHONENO_ID`),
  KEY `FK_CONTACTADDPHONENO_CNTCTADDID` (`CNTCT_ADD_ID`),
  KEY `FK_CONTACTADDPHONENO_CNTCTNBRID` (`CNTCT_NBR_ID`),
  KEY `FK_CONTACTADDPHONENO_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTADDPHONENO_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTADDPHONENO_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Contact Add Phone Number definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contact_emails`
--

CREATE TABLE IF NOT EXISTS `contact_emails` (
  `CNTCT_EML_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Contact persons email id',
  `CNTCT_ID` int(10) NOT NULL COMMENT 'Contact id is identifier represents the respective id of the contact',
  `EMAIL_ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from email address  management table',
  `OA_ID_ORIGINATED` int(10) NOT NULL COMMENT 'Organisation account id ',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'Is primary',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`CNTCT_EML_ID`),
  KEY `FK_CONTACTEMAILS_CNTCTID` (`CNTCT_ID`),
  KEY `FK_CONTACTEMAILS_EMAILADDID` (`EMAIL_ADD_ID`),
  KEY `FK_CONTACTEMAILS_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTEMAILS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTEMAILS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Contact Emails definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contact_mst`
--

CREATE TABLE IF NOT EXISTS `contact_mst` (
  `CNTCT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Contact id is identifier represents the respective id of the contact',
  `CNTCT_SALUTATION_ID` int(10) NOT NULL COMMENT 'Contact salutation',
  `CNTCT_FRST_NM` varchar(40) DEFAULT NULL COMMENT 'Contact person first name',
  `CNTCT_LST_NM` varchar(40) DEFAULT NULL COMMENT 'Contact person last name',
  `CNTCT_MDDL_NM` varchar(40) DEFAULT NULL COMMENT 'Contact person middle name',
  `CNTCT_OTHER_NM` varchar(40) DEFAULT NULL COMMENT 'Contact persons other name',
  `CNTCT_PRFRD_NM` varchar(40) DEFAULT NULL COMMENT 'Preferred name of the contact person',
  `CNTCT_DOB` varchar(40) DEFAULT NULL COMMENT 'Contact person date of birth',
  `CNTCT_SMOKER` tinyint(1) DEFAULT NULL COMMENT 'Flag to mark that the contact person is smoker or not',
  `CNTCT_GENDER_ID` int(10) DEFAULT NULL COMMENT ' Contact person gender',
  `MARRITAL_STATUS_ID` int(10) DEFAULT NULL COMMENT 'Marital status of the contact person',
  `CAST_ID` int(10) DEFAULT NULL COMMENT 'Contact person cast id',
  `RASE_ID` int(10) DEFAULT NULL COMMENT 'Contact person raise id',
  `OA_ID_ORIGINATED` int(10) DEFAULT NULL COMMENT 'Organisation originated id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`CNTCT_ID`),
  KEY `FK_CONTACTMST_CNTCTSALUTATIONID` (`CNTCT_SALUTATION_ID`),
  KEY `FK_CONTACTMST_CNTCTGENDERID` (`CNTCT_GENDER_ID`),
  KEY `FK_CONTACTMST_MARRITALSTATUSID` (`MARRITAL_STATUS_ID`),
  KEY `FK_CONTACTMST_CASTID` (`CAST_ID`),
  KEY `FK_CONTACTMST_RASEID` (`RASE_ID`),
  KEY `FK_CONTACTMST_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contact_nationality`
--

CREATE TABLE IF NOT EXISTS `contact_nationality` (
  `CNTCT_NATIONALITY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Contact nationality id is identifier represents the respective id of the contact nationality',
  `CNTCT_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact master table',
  `NATIONALITY_ID` int(10) DEFAULT NULL COMMENT ' Nationality id is identifier represents the respective id of the nationality',
  `OA_ID_ORIGINATED` int(10) DEFAULT NULL COMMENT 'Organisation account id ',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`CNTCT_NATIONALITY_ID`),
  KEY `FK_CONTACTNATIONALITY_CNTCTID` (`CNTCT_ID`),
  KEY `FK_CONTACTNATIONALITY_NATIONALITYID` (`NATIONALITY_ID`),
  KEY `FK_CONTACTNATIONALITY_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTNATIONALITY_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTNATIONALITY_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Contact Nationality definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contact_phones`
--

CREATE TABLE IF NOT EXISTS `contact_phones` (
  `CNTCT_PHONE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Contact phone id is identifier represents the respective id of the contact phone',
  `CNTCT_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact master table',
  `PHONE_NBR_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact phone master table',
  `OA_ID_ORIGINATED` int(10) NOT NULL COMMENT 'Organisation account id ',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'Is primary',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Created on',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Updated on',
  PRIMARY KEY (`CNTCT_PHONE_ID`),
  KEY `FK_CONTACTPHONES_CNTCTID` (`CNTCT_ID`),
  KEY `FK_CONTACTPHONES_PHONENBRID` (`PHONE_NBR_ID`),
  KEY `FK_CONTACTPHONES_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_CONTACTPHONES_CREATEDBY` (`CREATED_BY`),
  KEY `FK_CONTACTPHONES_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Contact Phones definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `contact_relation_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `contact_relation_type_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `continent_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `continent_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `country_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `country_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `county_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `county_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `currency_mst`
--

CREATE TABLE IF NOT EXISTS `currency_mst` (
  `CURR_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Currency Identifier of thr organisation',
  `CURR_CODE` varchar(5) NOT NULL COMMENT 'Organisation Specific Currency Code',
  `CURR_NAME` varchar(40) DEFAULT NULL COMMENT 'Organisation Specific Currency Name',
  `CURR_SYMBOL` varchar(5) DEFAULT NULL COMMENT 'Currency Symbol',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation Account ',
  `COUNTRY_ID` int(10) DEFAULT NULL COMMENT 'Organisation Specific Country',
  `REF_NBR` varchar(10) DEFAULT NULL COMMENT 'Reference Number to integrate with third party systems',
  `CURR_COMMENTS` varchar(255) DEFAULT NULL COMMENT 'Additional Remarks if required',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`CURR_ID`),
  UNIQUE KEY `UK_CURRENCYMST_CURRCODEOAID` (`CURR_CODE`,`OA_ID`),
  KEY `FK_CURRENCYMST_OAID` (`OA_ID`),
  KEY `FK_CURRENCYMST_COUNTRYID` (`COUNTRY_ID`),
  KEY `FK_CURRENCYMST_CREATEDBY` (`CREATEDBY`),
  KEY `FK_CURRENCYMST_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores all the currency details of an organisation. This currency has two set of details. The one without any Org Account ID are the default system currency details and are having one to one relation with independent master currency id. And the other user selected currencies are the one with Org Account ID in it. A organisation admin will be able to choose the currencies required by a an organisation and users of those organisations will be using those currencies in their transactions' AUTO_INCREMENT=788 ;

--
-- Dumping data for table `currency_mst`
--

INSERT INTO `currency_mst` (`CURR_ID`, `CURR_CODE`, `CURR_NAME`, `CURR_SYMBOL`, `OA_ID`, `COUNTRY_ID`, `REF_NBR`, `CURR_COMMENTS`, `CREATEDBY`, `UPDATEDBY`, `CREATEDON`, `UPDATEDON`) VALUES
(604, 'AED', 'United Arab Emirates dirham', NULL, NULL, NULL, NULL, 'United Arab Emirates', NULL, NULL, NULL, NULL),
(605, 'AFN', 'Afghani', NULL, NULL, NULL, NULL, 'Afghanistan', NULL, NULL, NULL, NULL),
(606, 'ALL', 'Lek', NULL, NULL, NULL, NULL, 'Albania', NULL, NULL, NULL, NULL),
(607, 'AMD', 'Armenian Dram', NULL, NULL, NULL, NULL, 'Armenia', NULL, NULL, NULL, NULL),
(608, 'ANG', 'Netherlands Antillian Guilder', NULL, NULL, NULL, NULL, 'Netherlands Antilles', NULL, NULL, NULL, NULL),
(609, 'AOA', 'Kwanza', NULL, NULL, NULL, NULL, 'Angola', NULL, NULL, NULL, NULL),
(610, 'ARS', 'Argentine Peso', NULL, NULL, NULL, NULL, 'Argentina', NULL, NULL, NULL, NULL),
(611, 'AUD', 'Australian Dollar', NULL, NULL, NULL, NULL, 'Australia, Australian Antarctic Territory, Christmas Island, Cocos (Keeling) Islands, Heard and McDonald Islands, Kiribati, Nauru, Norfolk Island, Tuvalu', NULL, NULL, NULL, NULL),
(612, 'AWG', 'Aruban Guilder', NULL, NULL, NULL, NULL, 'Aruba', NULL, NULL, NULL, NULL),
(613, 'AZN', 'Azerbaijanian Manat', NULL, NULL, NULL, NULL, 'Azerbaijan', NULL, NULL, NULL, NULL),
(614, 'BAM', 'Convertible Marks', NULL, NULL, NULL, NULL, 'Bosnia and Herzegovina', NULL, NULL, NULL, NULL),
(615, 'BBD', 'Barbados Dollar', NULL, NULL, NULL, NULL, 'Barbados', NULL, NULL, NULL, NULL),
(616, 'BDT', 'Bangladeshi Taka', NULL, NULL, NULL, NULL, 'Bangladesh', NULL, NULL, NULL, NULL),
(617, 'BGN', 'Bulgarian Lev', NULL, NULL, NULL, NULL, 'Bulgaria', NULL, NULL, NULL, NULL),
(618, 'BHD', 'Bahraini Dinar', NULL, NULL, NULL, NULL, 'Bahrain', NULL, NULL, NULL, NULL),
(619, 'BIF', 'Burundian Franc', NULL, NULL, NULL, NULL, 'Burundi', NULL, NULL, NULL, NULL),
(620, 'BMD', 'Bermudian Dollar (customarily known as B', NULL, NULL, NULL, NULL, 'Bermuda', NULL, NULL, NULL, NULL),
(621, 'BND', 'Brunei Dollar', NULL, NULL, NULL, NULL, 'Brunei', NULL, NULL, NULL, NULL),
(622, 'BOB', 'Boliviano', NULL, NULL, NULL, NULL, 'Bolivia', NULL, NULL, NULL, NULL),
(623, 'BOV', 'Bolivian Mvdol (Funds code)', NULL, NULL, NULL, NULL, 'Bolivia', NULL, NULL, NULL, NULL),
(624, 'BRL', 'Brazilian Real', NULL, NULL, NULL, NULL, 'Brazil', NULL, NULL, NULL, NULL),
(625, 'BSD', 'Bahamian Dollar', NULL, NULL, NULL, NULL, 'Bahamas', NULL, NULL, NULL, NULL),
(626, 'BTN', 'Ngultrum', NULL, NULL, NULL, NULL, 'Bhutan', NULL, NULL, NULL, NULL),
(627, 'BWP', 'Pula', NULL, NULL, NULL, NULL, 'Botswana', NULL, NULL, NULL, NULL),
(628, 'BYR', 'Belarussian Ruble', NULL, NULL, NULL, NULL, 'Belarus', NULL, NULL, NULL, NULL),
(629, 'BZD', 'Belize Dollar', NULL, NULL, NULL, NULL, 'Belize', NULL, NULL, NULL, NULL),
(630, 'CAD', 'Canadian Dollar', NULL, NULL, NULL, NULL, 'Canada', NULL, NULL, NULL, NULL),
(631, 'CDF', 'Franc Congolais', NULL, NULL, NULL, NULL, 'Democratic Republic of Congo', NULL, NULL, NULL, NULL),
(632, 'CHE', 'WIR Euro (complementary currency)', NULL, NULL, NULL, NULL, 'Switzerland', NULL, NULL, NULL, NULL),
(633, 'CHF', 'Swiss Franc', NULL, NULL, NULL, NULL, 'Switzerland, Liechtenstein', NULL, NULL, NULL, NULL),
(634, 'CHW', 'WIR Franc (complementary currency)', NULL, NULL, NULL, NULL, 'Switzerland', NULL, NULL, NULL, NULL),
(635, 'CLF', 'Unidades de formento (Funds code)', NULL, NULL, NULL, NULL, 'Chile', NULL, NULL, NULL, NULL),
(636, 'CLP', 'Chilean Peso', NULL, NULL, NULL, NULL, 'Chile', NULL, NULL, NULL, NULL),
(637, 'CNY', 'Yuan Renminbi', NULL, NULL, NULL, NULL, 'Mainland China', NULL, NULL, NULL, NULL),
(638, 'COP', 'Colombian Peso', NULL, NULL, NULL, NULL, 'Colombia', NULL, NULL, NULL, NULL),
(639, 'COU', 'Unidad de Valor Real', NULL, NULL, NULL, NULL, 'Colombia', NULL, NULL, NULL, NULL),
(640, 'CRC', 'Costa Rican Colon', NULL, NULL, NULL, NULL, 'Costa Rica', NULL, NULL, NULL, NULL),
(641, 'CUP', 'Cuban Peso', NULL, NULL, NULL, NULL, 'Cuba', NULL, NULL, NULL, NULL),
(642, 'CVE', 'Cape Verde Escudo', NULL, NULL, NULL, NULL, 'Cape Verde', NULL, NULL, NULL, NULL),
(643, 'CYP', 'Cyprus Pound', NULL, NULL, NULL, NULL, 'Cyprus', NULL, NULL, NULL, NULL),
(644, 'CZK', 'Czech Koruna', NULL, NULL, NULL, NULL, 'Czech Republic', NULL, NULL, NULL, NULL),
(645, 'DJF', 'Djibouti Franc', NULL, NULL, NULL, NULL, 'Djibouti', NULL, NULL, NULL, NULL),
(646, 'DKK', 'Danish Krone', NULL, NULL, NULL, NULL, 'Denmark, Faroe Islands, Greenland', NULL, NULL, NULL, NULL),
(647, 'DOP', 'Dominican Peso', NULL, NULL, NULL, NULL, 'Dominican Republic', NULL, NULL, NULL, NULL),
(648, 'DZD', 'Algerian Dinar', NULL, NULL, NULL, NULL, 'Algeria', NULL, NULL, NULL, NULL),
(649, 'EEK', 'Kroon', NULL, NULL, NULL, NULL, 'Estonia', NULL, NULL, NULL, NULL),
(650, 'EGP', 'Egyptian Pound', NULL, NULL, NULL, NULL, 'Egypt', NULL, NULL, NULL, NULL),
(651, 'ERN', 'Nakfa', NULL, NULL, NULL, NULL, 'Eritrea', NULL, NULL, NULL, NULL),
(652, 'ETB', 'Ethiopian Birr', NULL, NULL, NULL, NULL, 'Ethiopia', NULL, NULL, NULL, NULL),
(653, 'EUR', 'Euro', NULL, NULL, NULL, NULL, 'European Union, see eurozone', NULL, NULL, NULL, NULL),
(654, 'FJD', 'Fiji Dollar', NULL, NULL, NULL, NULL, 'Fiji', NULL, NULL, NULL, NULL),
(655, 'FKP', 'Falkland Islands Pound', NULL, NULL, NULL, NULL, 'Falkland Islands', NULL, NULL, NULL, NULL),
(656, 'GBP', 'Pound Sterling', NULL, NULL, NULL, NULL, 'United Kingdom', NULL, NULL, NULL, NULL),
(657, 'GEL', 'Lari', NULL, NULL, NULL, NULL, 'Georgia', NULL, NULL, NULL, NULL),
(658, 'GHS', 'Cedi', NULL, NULL, NULL, NULL, 'Ghana', NULL, NULL, NULL, NULL),
(659, 'GIP', 'Gibraltar pound', NULL, NULL, NULL, NULL, 'Gibraltar', NULL, NULL, NULL, NULL),
(660, 'GMD', 'Dalasi', NULL, NULL, NULL, NULL, 'Gambia', NULL, NULL, NULL, NULL),
(661, 'GNF', 'Guinea Franc', NULL, NULL, NULL, NULL, 'Guinea', NULL, NULL, NULL, NULL),
(662, 'GTQ', 'Quetzal', NULL, NULL, NULL, NULL, 'Guatemala', NULL, NULL, NULL, NULL),
(663, 'GYD', 'Guyana Dollar', NULL, NULL, NULL, NULL, 'Guyana', NULL, NULL, NULL, NULL),
(664, 'HKD', 'Hong Kong Dollar', NULL, NULL, NULL, NULL, 'Hong Kong Special Administrative Region', NULL, NULL, NULL, NULL),
(665, 'HNL', 'Lempira', NULL, NULL, NULL, NULL, 'Honduras', NULL, NULL, NULL, NULL),
(666, 'HRK', 'Croatian Kuna', NULL, NULL, NULL, NULL, 'Croatia', NULL, NULL, NULL, NULL),
(667, 'HTG', 'Haiti Gourde', NULL, NULL, NULL, NULL, 'Haiti', NULL, NULL, NULL, NULL),
(668, 'HUF', 'Forint', NULL, NULL, NULL, NULL, 'Hungary', NULL, NULL, NULL, NULL),
(669, 'IDR', 'Rupiah', NULL, NULL, NULL, NULL, 'Indonesia', NULL, NULL, NULL, NULL),
(670, 'ILS', 'New Israeli Shekel', NULL, NULL, NULL, NULL, 'Israel', NULL, NULL, NULL, NULL),
(671, 'INR', 'Indian Rupee', NULL, NULL, NULL, NULL, 'Bhutan, India', NULL, NULL, NULL, NULL),
(672, 'IQD', 'Iraqi Dinar', NULL, NULL, NULL, NULL, 'Iraq', NULL, NULL, NULL, NULL),
(673, 'IRR', 'Iranian Rial', NULL, NULL, NULL, NULL, 'Iran', NULL, NULL, NULL, NULL),
(674, 'ISK', 'Iceland Krona', NULL, NULL, NULL, NULL, 'Iceland', NULL, NULL, NULL, NULL),
(675, 'JMD', 'Jamaican Dollar', NULL, NULL, NULL, NULL, 'Jamaica', NULL, NULL, NULL, NULL),
(676, 'JOD', 'Jordanian Dinar', NULL, NULL, NULL, NULL, 'Jordan', NULL, NULL, NULL, NULL),
(677, 'JPY', 'Japanese yen', NULL, NULL, NULL, NULL, 'Japan', NULL, NULL, NULL, NULL),
(678, 'KES', 'Kenyan Shilling', NULL, NULL, NULL, NULL, 'Kenya', NULL, NULL, NULL, NULL),
(679, 'KGS', 'Som', NULL, NULL, NULL, NULL, 'Kyrgyzstan', NULL, NULL, NULL, NULL),
(680, 'KHR', 'Riel', NULL, NULL, NULL, NULL, 'Cambodia', NULL, NULL, NULL, NULL),
(681, 'KMF', 'Comoro Franc', NULL, NULL, NULL, NULL, 'Comoros', NULL, NULL, NULL, NULL),
(682, 'KPW', 'North Korean Won', NULL, NULL, NULL, NULL, 'North Korea', NULL, NULL, NULL, NULL),
(683, 'KRW', 'South Korean Won', NULL, NULL, NULL, NULL, 'South Korea', NULL, NULL, NULL, NULL),
(684, 'KWD', 'Kuwaiti Dinar', NULL, NULL, NULL, NULL, 'Kuwait', NULL, NULL, NULL, NULL),
(685, 'KYD', 'Cayman Islands Dollar', NULL, NULL, NULL, NULL, 'Cayman Islands', NULL, NULL, NULL, NULL),
(686, 'KZT', 'Tenge', NULL, NULL, NULL, NULL, 'Kazakhstan', NULL, NULL, NULL, NULL),
(687, 'LAK', 'Kip', NULL, NULL, NULL, NULL, 'Laos', NULL, NULL, NULL, NULL),
(688, 'LBP', 'Lebanese Pound', NULL, NULL, NULL, NULL, 'Lebanon', NULL, NULL, NULL, NULL),
(689, 'LKR', 'Sri Lanka Rupee', NULL, NULL, NULL, NULL, 'Sri Lanka', NULL, NULL, NULL, NULL),
(690, 'LRD', 'Liberian Dollar', NULL, NULL, NULL, NULL, 'Liberia', NULL, NULL, NULL, NULL),
(691, 'LSL', 'Loti', NULL, NULL, NULL, NULL, 'Lesotho', NULL, NULL, NULL, NULL),
(692, 'LTL', 'Lithuanian Litas', NULL, NULL, NULL, NULL, 'Lithuania', NULL, NULL, NULL, NULL),
(693, 'LVL', 'Latvian Lats', NULL, NULL, NULL, NULL, 'Latvia', NULL, NULL, NULL, NULL),
(694, 'LYD', 'Libyan Dinar', NULL, NULL, NULL, NULL, 'Libya', NULL, NULL, NULL, NULL),
(695, 'MAD', 'Moroccan Dirham', NULL, NULL, NULL, NULL, 'Morocco, Western Sahara', NULL, NULL, NULL, NULL),
(696, 'MDL', 'Moldovan Leu', NULL, NULL, NULL, NULL, 'Moldova', NULL, NULL, NULL, NULL),
(697, 'MGA', 'Malagasy Ariary', NULL, NULL, NULL, NULL, 'Madagascar', NULL, NULL, NULL, NULL),
(698, 'MKD', 'Denar', NULL, NULL, NULL, NULL, 'Former Yugoslav Republic of Macedonia', NULL, NULL, NULL, NULL),
(699, 'MMK', 'Kyat', NULL, NULL, NULL, NULL, 'Myanmar', NULL, NULL, NULL, NULL),
(700, 'MNT', 'Tugrik', NULL, NULL, NULL, NULL, 'Mongolia', NULL, NULL, NULL, NULL),
(701, 'MOP', 'Pataca', NULL, NULL, NULL, NULL, 'Macau Special Administrative Region', NULL, NULL, NULL, NULL),
(702, 'MRO', 'Ouguiya', NULL, NULL, NULL, NULL, 'Mauritania', NULL, NULL, NULL, NULL),
(703, 'MTL', 'Maltese Lira', NULL, NULL, NULL, NULL, 'Malta', NULL, NULL, NULL, NULL),
(704, 'MUR', 'Mauritius Rupee', NULL, NULL, NULL, NULL, 'Mauritius', NULL, NULL, NULL, NULL),
(705, 'MVR', 'Rufiyaa', NULL, NULL, NULL, NULL, 'Maldives', NULL, NULL, NULL, NULL),
(706, 'MWK', 'Kwacha', NULL, NULL, NULL, NULL, 'Malawi', NULL, NULL, NULL, NULL),
(707, 'MXN', 'Mexican Peso', NULL, NULL, NULL, NULL, 'Mexico', NULL, NULL, NULL, NULL),
(708, 'MXV', 'Mexican Unidad de Inversion (UDI) (Funds', NULL, NULL, NULL, NULL, 'Mexico', NULL, NULL, NULL, NULL),
(709, 'MYR', 'Malaysian Ringgit', NULL, NULL, NULL, NULL, 'Malaysia', NULL, NULL, NULL, NULL),
(710, 'MZN', 'Metical', NULL, NULL, NULL, NULL, 'Mozambique', NULL, NULL, NULL, NULL),
(711, 'NAD', 'Namibian Dollar', NULL, NULL, NULL, NULL, 'Namibia', NULL, NULL, NULL, NULL),
(712, 'NGN', 'Naira', NULL, NULL, NULL, NULL, 'Nigeria', NULL, NULL, NULL, NULL),
(713, 'NIO', 'Cordoba Oro', NULL, NULL, NULL, NULL, 'Nicaragua', NULL, NULL, NULL, NULL),
(714, 'NOK', 'Norwegian Krone', NULL, NULL, NULL, NULL, 'Norway', NULL, NULL, NULL, NULL),
(715, 'NPR', 'Nepalese Rupee', NULL, NULL, NULL, NULL, 'Nepal', NULL, NULL, NULL, NULL),
(716, 'NZD', 'New Zealand Dollar', NULL, NULL, NULL, NULL, 'Cook Islands, New Zealand, Niue, Pitcairn, Tokelau', NULL, NULL, NULL, NULL),
(717, 'OMR', 'Rial Omani', NULL, NULL, NULL, NULL, 'Oman', NULL, NULL, NULL, NULL),
(718, 'PAB', 'Balboa', NULL, NULL, NULL, NULL, 'Panama', NULL, NULL, NULL, NULL),
(719, 'PEN', 'Nuevo Sol', NULL, NULL, NULL, NULL, 'Peru', NULL, NULL, NULL, NULL),
(720, 'PGK', 'Kina', NULL, NULL, NULL, NULL, 'Papua New Guinea', NULL, NULL, NULL, NULL),
(721, 'PHP', 'Philippine Peso', NULL, NULL, NULL, NULL, 'Philippines', NULL, NULL, NULL, NULL),
(722, 'PKR', 'Pakistan Rupee', NULL, NULL, NULL, NULL, 'Pakistan', NULL, NULL, NULL, NULL),
(723, 'PLN', 'Zloty', NULL, NULL, NULL, NULL, 'Poland', NULL, NULL, NULL, NULL),
(724, 'PYG', 'Guarani', NULL, NULL, NULL, NULL, 'Paraguay', NULL, NULL, NULL, NULL),
(725, 'QAR', 'Qatari Rial', NULL, NULL, NULL, NULL, 'Qatar', NULL, NULL, NULL, NULL),
(726, 'RON', 'Romanian New Leu', NULL, NULL, NULL, NULL, 'Romania', NULL, NULL, NULL, NULL),
(727, 'RSD', 'Serbian Dinar', NULL, NULL, NULL, NULL, 'Serbia', NULL, NULL, NULL, NULL),
(728, 'RUB', 'Russian Ruble', NULL, NULL, NULL, NULL, 'Russia, Abkhazia, South Ossetia', NULL, NULL, NULL, NULL),
(729, 'RWF', 'Rwanda Franc', NULL, NULL, NULL, NULL, 'Rwanda', NULL, NULL, NULL, NULL),
(730, 'SAR', 'Saudi Riyal', NULL, NULL, NULL, NULL, 'Saudi Arabia', NULL, NULL, NULL, NULL),
(731, 'SBD', 'Solomon Islands Dollar', NULL, NULL, NULL, NULL, 'Solomon Islands', NULL, NULL, NULL, NULL),
(732, 'SCR', 'Seychelles Rupee', NULL, NULL, NULL, NULL, 'Seychelles', NULL, NULL, NULL, NULL),
(733, 'SDG', 'Sudanese Pound', NULL, NULL, NULL, NULL, 'Sudan', NULL, NULL, NULL, NULL),
(734, 'SEK', 'Swedish Krona', NULL, NULL, NULL, NULL, 'Sweden', NULL, NULL, NULL, NULL),
(735, 'SGD', 'Singapore Dollar', NULL, NULL, NULL, NULL, 'Singapore', NULL, NULL, NULL, NULL),
(736, 'SHP', 'Saint Helena Pound', NULL, NULL, NULL, NULL, 'Saint Helena', NULL, NULL, NULL, NULL),
(737, 'SKK', 'Slovak Koruna', NULL, NULL, NULL, NULL, 'Slovakia', NULL, NULL, NULL, NULL),
(738, 'SLL', 'Leone', NULL, NULL, NULL, NULL, 'Sierra Leone', NULL, NULL, NULL, NULL),
(739, 'SOS', 'Somali Shilling', NULL, NULL, NULL, NULL, 'Somalia', NULL, NULL, NULL, NULL),
(740, 'SRD', 'Surinam Dollar', NULL, NULL, NULL, NULL, 'Suriname', NULL, NULL, NULL, NULL),
(741, 'STD', 'Dobra', NULL, NULL, NULL, NULL, 'S', NULL, NULL, NULL, NULL),
(742, 'SYP', 'Syrian Pound', NULL, NULL, NULL, NULL, 'Syria', NULL, NULL, NULL, NULL),
(743, 'SZL', 'Lilangeni', NULL, NULL, NULL, NULL, 'Swaziland', NULL, NULL, NULL, NULL),
(744, 'THB', 'Baht', NULL, NULL, NULL, NULL, 'Thailand', NULL, NULL, NULL, NULL),
(745, 'TJS', 'Somoni', NULL, NULL, NULL, NULL, 'Tajikistan', NULL, NULL, NULL, NULL),
(746, 'TMM', 'Manat', NULL, NULL, NULL, NULL, 'Turkmenistan', NULL, NULL, NULL, NULL),
(747, 'TND', 'Tunisian Dinar', NULL, NULL, NULL, NULL, 'Tunisia', NULL, NULL, NULL, NULL),
(748, 'TOP', 'Paanga', NULL, NULL, NULL, NULL, 'Tonga', NULL, NULL, NULL, NULL),
(749, 'TRY', 'New Turkish Lira', NULL, NULL, NULL, NULL, 'Turkey', NULL, NULL, NULL, NULL),
(750, 'TTD', 'Trinidad and Tobago Dollar', NULL, NULL, NULL, NULL, 'Trinidad and Tobago', NULL, NULL, NULL, NULL),
(751, 'TWD', 'New Taiwan Dollar', NULL, NULL, NULL, NULL, 'Taiwan and other islands that are under the effective control of the Republic of China (ROC)', NULL, NULL, NULL, NULL),
(752, 'TZS', 'Tanzanian Shilling', NULL, NULL, NULL, NULL, 'Tanzania', NULL, NULL, NULL, NULL),
(753, 'UAH', 'Hryvnia', NULL, NULL, NULL, NULL, 'Ukraine', NULL, NULL, NULL, NULL),
(754, 'UGX', 'Uganda Shilling', NULL, NULL, NULL, NULL, 'Uganda', NULL, NULL, NULL, NULL),
(755, 'USD', 'US Dollar', NULL, NULL, NULL, NULL, 'American Samoa, British Indian Ocean Territory, Ecuador, El Salvador, Guam, Haiti, Marshall Islands, Micronesia, Northern Mariana Islands, Palau, Panama, Puerto Rico, East Timor, Turks and Caicos Islands, United States, Virgin Islands', NULL, NULL, NULL, NULL),
(756, 'USN', 'USN', NULL, NULL, NULL, NULL, 'United States', NULL, NULL, NULL, NULL),
(757, 'USS', 'USS', NULL, NULL, NULL, NULL, 'United States', NULL, NULL, NULL, NULL),
(758, 'UYU', 'Peso Uruguayo', NULL, NULL, NULL, NULL, 'Uruguay', NULL, NULL, NULL, NULL),
(759, 'UZS', 'Uzbekistan Som', NULL, NULL, NULL, NULL, 'Uzbekistan', NULL, NULL, NULL, NULL),
(760, 'VEB', 'Venezuelan bol', NULL, NULL, NULL, NULL, 'Venezuela', NULL, NULL, NULL, NULL),
(761, 'VND', 'Vietnamese d?ng', NULL, NULL, NULL, NULL, 'Vietnam', NULL, NULL, NULL, NULL),
(762, 'VUV', 'Vatu', NULL, NULL, NULL, NULL, 'Vanuatu', NULL, NULL, NULL, NULL),
(763, 'WST', 'Samoan Tala', NULL, NULL, NULL, NULL, 'Samoa', NULL, NULL, NULL, NULL),
(764, 'XAF', 'CFA Franc BEAC', NULL, NULL, NULL, NULL, 'Cameroon, Central African Republic, Congo, Chad, Equatorial Guinea, Gabon', NULL, NULL, NULL, NULL),
(765, 'XAG', 'Silver (one Troy ounce)', NULL, NULL, NULL, NULL, 'A', NULL, NULL, NULL, NULL),
(766, 'XAU', 'Gold (one Troy ounce)', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(767, 'XPD', 'Palladium (one Troy ounce)', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(768, 'XPF', 'CFP franc', NULL, NULL, NULL, NULL, 'French Polynesia, New Caledonia, Wallis and Futuna', NULL, NULL, NULL, NULL),
(769, 'XPT', 'Platinum (one Troy ounce)', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(770, 'XTS', 'Code reserved for testing purposes', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(771, 'XXX', 'No currency', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(772, 'YER', 'Yemeni Rial', NULL, NULL, NULL, NULL, 'Yemen', NULL, NULL, NULL, NULL),
(773, 'ZAR', 'South African Rand', NULL, NULL, NULL, NULL, 'South Africa', NULL, NULL, NULL, NULL),
(774, 'ZMK', 'Kwacha', NULL, NULL, NULL, NULL, 'Zambia', NULL, NULL, NULL, NULL),
(775, 'ZWD', 'Zimbabwe Dollar', NULL, NULL, NULL, NULL, 'Zimbabwe', NULL, NULL, NULL, NULL),
(776, 'XBA', 'European Composite Unit (EURCO) (Bonds m', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(777, 'XBB', 'European Monetary Unit (E.M.U.-6) (Bonds', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(778, 'XBC', 'European Unit of Account 9 (E.U.A.-9) (B', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(779, 'XBD', 'European Unit of Account 17 (E.U.A.-17) ', NULL, NULL, NULL, NULL, 'a', NULL, NULL, NULL, NULL),
(780, 'XCD', 'East Caribbean Dollar', NULL, NULL, NULL, NULL, 'Anguilla, Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines', NULL, NULL, NULL, NULL),
(781, 'XDR', 'Special Drawing Rights', NULL, NULL, NULL, NULL, 'International Monetary Fund', NULL, NULL, NULL, NULL),
(782, 'XFO', 'Gold franc (special settlement currency)', NULL, NULL, NULL, NULL, 'Bank for International Settlements', NULL, NULL, NULL, NULL),
(783, 'XFU', 'UIC franc (special settlement currency)', NULL, NULL, NULL, NULL, 'International Union of Railways', NULL, NULL, NULL, NULL),
(784, 'XOF', 'CFA Franc BCEAO', NULL, NULL, NULL, NULL, 'Benin, Burkina Faso, Cote dIvoire, Guinea-Bissau, Mali, Niger, Senegal, Togo', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currency_rate`
--

CREATE TABLE IF NOT EXISTS `currency_rate` (
  `CURR_RATE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Currency Rate Identifier',
  `SRC_CURR_ID` int(10) NOT NULL COMMENT 'Source Currency ID from Currency Master Table',
  `TRG_CURR_ID` int(10) NOT NULL COMMENT 'Target Currency ID from Currency Master Table',
  `EX_RATE` decimal(10,5) NOT NULL COMMENT 'Exchange Rate',
  `EFF_FROM` datetime NOT NULL COMMENT 'Effective start date of the exchange rate',
  `EFF_TO` datetime DEFAULT NULL COMMENT 'Effective End date of the exchange rate',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`CURR_RATE_ID`),
  KEY `FK_CURRENCYRATE_SRCCURRID` (`SRC_CURR_ID`),
  KEY `FK_CURRENCYRATE_TRGCURRID` (`TRG_CURR_ID`),
  KEY `FK_CURRENCYRATE_CREATEDBY` (`CREATEDBY`),
  KEY `FK_CURRENCYRATE_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the currency rate of a time period for a organisation' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `currency_rate`
--

INSERT INTO `currency_rate` (`CURR_RATE_ID`, `SRC_CURR_ID`, `TRG_CURR_ID`, `EX_RATE`, `EFF_FROM`, `EFF_TO`, `CREATEDBY`, `UPDATEDBY`, `CREATEDON`, `UPDATEDON`) VALUES
(1, 604, 610, '12.00000', '2014-04-02 00:00:00', '2014-04-23 00:00:00', 2, 2, '2014-04-07 05:37:48', '2014-04-07 05:49:55'),
(2, 611, 604, '11.00000', '2014-04-14 00:00:00', '2014-04-29 00:00:00', 2, NULL, '2014-04-07 06:21:10', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `data_layer_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `data_layer_obj_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_funcations_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_funcations_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_obj_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_obj_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_procs_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_procs_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_tables_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_tables_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_triggers_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_triggers_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `db_views_mst_vw`
--
CREATE TABLE IF NOT EXISTS `db_views_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `dependent_dtl`
--

CREATE TABLE IF NOT EXISTS `dependent_dtl` (
  `DEPENDENT_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'dependence detail id  id is identifier represents the respective id of the dependence detail',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `OA_DEP_CNTCTS_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Contact master table',
  `RELATION_TYPE_ID` int(10) NOT NULL COMMENT 'Relation type id. This is a master data driven from independent master table.the related entity is RELATION TYPE,  Typ_id=160. On UI this will be a dropdown control',
  `REALTION_TYPE_NAME` varchar(100) DEFAULT NULL COMMENT 'Relation with dependent',
  `DATE_OF_BIRTH` datetime DEFAULT NULL COMMENT 'dependents date of birth',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`DEPENDENT_DTL_ID`),
  KEY `FK_DEPENDENTDTL_EMPID` (`EMP_ID`),
  KEY `FK_DEPENDENTDTL_OADEPCNTCTSID` (`OA_DEP_CNTCTS_ID`),
  KEY `FK_DEPENDENTDTL_RELATIONTYPEID` (`RELATION_TYPE_ID`),
  KEY `FK_DEPENDENTDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_DEPENDENTDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Employee dependents details' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `dept_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `dept_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `directors_mst_vw`
--
CREATE TABLE IF NOT EXISTS `directors_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `district_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `district_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `division_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `division_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `email_account_dtl`
--

CREATE TABLE IF NOT EXISTS `email_account_dtl` (
  `EMAIL_ACCT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Email account id is identifier represents the respective id of the contact email account id',
  `EMAIL_ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from email address master',
  `CONTACT_ID` int(10) NOT NULL COMMENT 'Contact id represents the  id contact person',
  `EMAIL_ACC_FNAME` varchar(40) DEFAULT NULL COMMENT 'First name of the email account  ',
  `EMAIL_ACC_LNAME` varchar(40) DEFAULT NULL COMMENT 'Last name of the email account  ',
  `EMAIL_ACC_ADD_ID` int(10) DEFAULT NULL COMMENT 'Email account address id is the id of the person account id',
  `EMAIL_ACCT_USE_TYPE_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from independent master table',
  `ISDELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMAIL_ACCT_ID`),
  KEY `FK_EMAILACCOUNTDTL_EMAILADDID` (`EMAIL_ADD_ID`),
  KEY `FK_EMAILACCOUNTDTL_CONTACTID` (`CONTACT_ID`),
  KEY `FK_EMAILACCOUNTDTL_EMAILACCTUSETYPEID` (`EMAIL_ACCT_USE_TYPE_ID`),
  KEY `FK_EMAILACCOUNTDTL_CREATEDBY` (`CREATEDBY`),
  KEY `FK_EMAILACCOUNTDTL_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Email Account Detail definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `email_account_use_type_vw`
--
CREATE TABLE IF NOT EXISTS `email_account_use_type_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `email_address_mst`
--

CREATE TABLE IF NOT EXISTS `email_address_mst` (
  `EMAIL_ADD_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Email address id is identifier represents the respective id of the contact email address',
  `EMAIL_ADD` varchar(40) NOT NULL COMMENT 'Contact person email address',
  `OA_ID_ORIGINATED` int(10) DEFAULT NULL COMMENT 'Organisation account id ',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMAIL_ADD_ID`),
  UNIQUE KEY `UK_EMAILADDRESSMST_EMAILADD` (`EMAIL_ADD`),
  UNIQUE KEY `UK_EMAILADDRESSMST_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_EMAILADDRESSMST_CREATEDBY` (`CREATEDBY`),
  KEY `FK_EMAILADDRESSMST_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Email Address Management definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `email_config`
--

CREATE TABLE IF NOT EXISTS `email_config` (
  `EML_CNFG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'email configuration id   Identifier is the unique primary key of this entity. It is a Auto generated number',
  `MAIL_TYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Independent master table',
  `SENT_AS0` varchar(250) NOT NULL COMMENT 'Sent email as',
  `SENDMAIL_PATH` varchar(250) DEFAULT NULL COMMENT 'Path for the mail',
  `SMTP_HOST` varchar(250) NOT NULL COMMENT 'SMTP Host name',
  `SMTP_PORT` int(10) NOT NULL COMMENT 'SMTP port no',
  `SMTP_USERNAME` varchar(250) NOT NULL COMMENT 'SMTP Username',
  `SMTP_PASSWORD` varchar(250) NOT NULL COMMENT 'SMTP Password',
  `SMTP_AUTH_TYPE` varchar(50) DEFAULT NULL COMMENT 'SMTP Authentication type',
  `SMTP_SECURITY_TYPE` varchar(50) DEFAULT NULL COMMENT 'SMTP Security type',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account Id. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `ISDELETED` tinyint(1) DEFAULT NULL COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`EML_CNFG_ID`),
  KEY `FK_EMAILCONFIG_MAILTYPEID` (`MAIL_TYPE_ID`),
  KEY `FK_EMAILCONFIG_OAID` (`OA_ID`),
  KEY `FK_EMAILCONFIG_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_EMAILCONFIG_CREATEDBY` (`CREATEDBY`),
  KEY `FK_EMAILCONFIG_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores all the types used in the system. This typically holds system defined data types and is referred by most of the system entities' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `email_subscriber`
--

CREATE TABLE IF NOT EXISTS `email_subscriber` (
  `EML_SBSCRBR_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Email Subscribe id   Identifier is the unique primary key of this entity. It is a Auto generated number',
  `NOTIFICATION_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Independent master table',
  `SUBCRIBER_NAME` varchar(100) DEFAULT NULL COMMENT 'Subscribe Name',
  `SUBSCRIBER_EMAIL` varchar(100) DEFAULT NULL COMMENT 'Subscribe Email',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account Id. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`EML_SBSCRBR_ID`),
  KEY `FK_EMAILSUBSCRIBER_NOTIFICATIONID` (`NOTIFICATION_ID`),
  KEY `FK_EMAILSUBSCRIBER_OAID` (`OA_ID`),
  KEY `FK_EMAILSUBSCRIBER_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_EMAILSUBSCRIBER_CREATEDBY` (`CREATEDBY`),
  KEY `FK_EMAILSUBSCRIBER_UPDATEDBY` (`UPDATEDBY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the common types' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contact_dtl`
--

CREATE TABLE IF NOT EXISTS `emergency_contact_dtl` (
  `EMERGENCY_CONTACT_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee reporting  id is identifier represents the respective id of the emergency contact detail',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EMERG_CONTACT_ID` int(10) NOT NULL COMMENT 'Emergency contact Sequence number',
  `EMERG_CONTACT_RELATION_TYPE_ID` int(100) NOT NULL COMMENT 'Emergency contact person Name. This is a master data driven from independent master table.the related entity is RELATION TYPE, Typ_id=160. On UI this will be a dropdown control',
  `EMERG_CONTACT_TEL_ID` int(100) NOT NULL COMMENT 'Relation with emergency contact person',
  `EMERG_CONTACT_MOBILE_ID` int(100) NOT NULL COMMENT 'emergency landline number',
  `EMERG_CONTACT_OFFNO_ID` int(100) NOT NULL COMMENT 'emergency mobile number',
  `EMERG_CONTACT_EMAIL_ID` int(100) NOT NULL COMMENT 'emergency mobile number',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMERGENCY_CONTACT_DTL_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMPID` (`EMP_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTID` (`EMERG_CONTACT_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTRELATIONTYPEID` (`EMERG_CONTACT_RELATION_TYPE_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTTELID` (`EMERG_CONTACT_TEL_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTMOBILEID` (`EMERG_CONTACT_MOBILE_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTOFFNOID` (`EMERG_CONTACT_OFFNO_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_EMERGCONTACTEMAILID` (`EMERG_CONTACT_EMAIL_ID`),
  KEY `FK_EMERGENCYCONTACTDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMERGENCYCONTACTDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Employees Emergency Details' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `eml_notification_mst_vw`
--
CREATE TABLE IF NOT EXISTS `eml_notification_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `emp_basic_sal_dtl`
--

CREATE TABLE IF NOT EXISTS `emp_basic_sal_dtl` (
  `EMP_BASIC_SAL_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee basic salary detail id  id is identifier represents the respective id of the employe basic salary',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EMP_GRADE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from  paygrade table',
  `POSITION_ID` int(10) NOT NULL COMMENT 'notes/description',
  `CURRENCY_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from  currency master table',
  `BASIC_SALARY` decimal(10,2) DEFAULT NULL COMMENT 'Basic Salary',
  `PAY_FREQUENCY_ID` int(10) NOT NULL COMMENT 'PAY frequency id. This is a master data driven from independent master table.the related entity is PAY FREQUENCY  Typ_id=163 on UI this will be a dropdown control',
  `COMPONENT_DESC` varchar(100) DEFAULT NULL COMMENT 'Salary Component',
  `COMMENTS` varchar(255) DEFAULT NULL COMMENT 'notes/description',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_BASIC_SAL_DTL_ID`),
  KEY `FK_EMPBASICSALDTL_EMPID` (`EMP_ID`),
  KEY `FK_EMPBASICSALDTL_EMPGRADEID` (`EMP_GRADE_ID`),
  KEY `FK_EMPBASICSALDTL_POSITIONID` (`POSITION_ID`),
  KEY `FK_EMPBASICSALDTL_CURRENCYID` (`CURRENCY_ID`),
  KEY `FK_EMPBASICSALDTL_PAYFREQUENCYID` (`PAY_FREQUENCY_ID`),
  KEY `FK_EMPBASICSALDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPBASICSALDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='salary details of the employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_education`
--

CREATE TABLE IF NOT EXISTS `emp_education` (
  `ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '  id is identifier represents the respective id of the Education',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EDU_QUAL_ID` int(10) NOT NULL COMMENT 'Education qualification id. This is a master data driven from independent master table.the related entity is EDUCATION QUALIFICATION Typ_id=164 on UI this will be a dropdown control',
  `INSTITUTE` varchar(100) DEFAULT NULL COMMENT 'Employee Institute Name',
  `MAJOR` varchar(100) DEFAULT NULL COMMENT 'Major',
  `YEAR` decimal(4,0) DEFAULT NULL COMMENT 'Employee pass-out year',
  `SCORE` varchar(100) DEFAULT NULL COMMENT 'Score',
  `START_DATE` date DEFAULT NULL COMMENT 'Start Date',
  `END_DATE` date DEFAULT NULL COMMENT 'End Date',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`ID`),
  KEY `FK_EMPEDUCATION_EMPID` (`EMP_ID`),
  KEY `FK_EMPEDUCATION_EDUQUALID` (`EDU_QUAL_ID`),
  KEY `FK_EMPEDUCATION_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPEDUCATION_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Education details of the employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_language`
--

CREATE TABLE IF NOT EXISTS `emp_language` (
  `EMP_LANGUAGE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee rlanguage  id is identifier represents the respective id of the Language',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `LANGUAGE_ID` int(10) NOT NULL COMMENT 'Language id. This is a master data driven from independent master table.the related entity is LANGUAGETyp_id=165 on UI this will be a dropdown control',
  `LANGUAGE_FLUENCY_ID` int(10) NOT NULL COMMENT 'Language fluency. This is a master data driven from independent master table.the related entity is LANGUAGE FLUENCY Typ_id=166 on UI this will be a dropdown control',
  `LANGUAGE_COMPETENCY_ID` int(10) NOT NULL COMMENT 'Language competency id. This is a master data driven from independent master table.the related entity LANGUAGE COMPETENCY Typ_id=167 on UI this will be a dropdown control',
  `COMMENTS` varchar(100) DEFAULT NULL COMMENT 'notes/description',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_LANGUAGE_ID`),
  KEY `FK_EMPLANGUAGE_EMPID` (`EMP_ID`),
  KEY `FK_EMPLANGUAGE_LANGUAGEID` (`LANGUAGE_ID`),
  KEY `FK_EMPLANGUAGE_LANGUAGEFLUENCYID` (`LANGUAGE_FLUENCY_ID`),
  KEY `FK_EMPLANGUAGE_LANGUAGECOMPETENCYID` (`LANGUAGE_COMPETENCY_ID`),
  KEY `FK_EMPLANGUAGE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPLANGUAGE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Languages known by the employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_licence`
--

CREATE TABLE IF NOT EXISTS `emp_licence` (
  `LICENSE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'license  id is identifier represents the respective id of the License',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `LICENSE_NO` varchar(100) DEFAULT NULL COMMENT 'Licence number',
  `LICENSE_ISSUED_DATE` date DEFAULT NULL COMMENT 'Date of issue',
  `LICENSE_EXPIRY_DATE` date DEFAULT NULL COMMENT 'date of expiry',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`LICENSE_ID`),
  KEY `FK_EMPLICENCE_EMPID` (`EMP_ID`),
  KEY `FK_EMPLICENCE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPLICENCE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='licences details of the employees' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_mst`
--

CREATE TABLE IF NOT EXISTS `emp_mst` (
  `EMP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee id is identifier represents the respective id of the employee master',
  `EMP_NAME` varchar(250) DEFAULT NULL COMMENT 'Employee full name',
  `EMP_NBR` varchar(100) NOT NULL COMMENT 'Unique employee id ',
  `OA_CNTCTS_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Contact master master table',
  `OA_CNTCT_ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Contact master master table',
  `OA_CNTCT_EML_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Contact master master table',
  `OA_CNTCT_PHONE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Contact master master table',
  `EMP_SSN_NBR` varchar(100) DEFAULT NULL COMMENT 'Employee SSN Number',
  `EMP_SIN_NBR` varchar(100) DEFAULT NULL COMMENT 'Employee SIN Number',
  `EMP_OTHER_ID` varchar(100) NOT NULL COMMENT 'Employee Other ID',
  `EMP_DRI_LICE_NBR` varchar(100) DEFAULT NULL COMMENT 'Driving License',
  `EMP_DRI_LICE_EXP_DATE` datetime DEFAULT NULL COMMENT 'Driving License Expiry Date',
  `EMP_MILITARY_SERVICE` varchar(100) DEFAULT NULL COMMENT 'If a ex military',
  `EMP_STATUS_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from employee status table',
  `JOB_TITLE_ID` int(10) NOT NULL COMMENT 'Job title id. This is a master data driven from independent master table.the related entity is JOB TITLE,  Typ_id=158. On UI this will be a dropdown control',
  `JOB_CAT_ID` int(10) DEFAULT NULL COMMENT 'employee category code. This is a master data driven from independent master table.the related entity is JOB CATEGORY\nTyp_id=159\non UI this will be a dropdown control',
  `WORK_STATION` varchar(100) DEFAULT NULL COMMENT 'Foreign key column value driven from Contact master master table',
  `EMP_GRADE_ID` int(10) NOT NULL COMMENT 'Employee grade id. This is a master data driven from independent master table.the related entity is EMPLOYEE GRADE, Typ_id=161. On UI this will be a dropdown control',
  `DATE_OF_JOINING` datetime DEFAULT NULL COMMENT 'Joining Date',
  `TERMINATION_ID` int(10) NOT NULL COMMENT 'Termination id. This is a master data driven from independent master table.the related entity is EMPLOYEE TERMINATION,  Typ_id=157. On UI this will be a dropdown control',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Emergency contact person Name. This is a master data driven from independent master table',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_ID`),
  UNIQUE KEY `UK_EMPMST_EMPNBROABRANDID` (`EMP_NBR`,`OA_BRAND_ID`),
  KEY `FK_EMPMST_OACNTCTSID` (`OA_CNTCTS_ID`),
  KEY `FK_EMPMST_OACNTCTADDID` (`OA_CNTCT_ADD_ID`),
  KEY `FK_EMPMST_OACNTCTEMLID` (`OA_CNTCT_EML_ID`),
  KEY `FK_EMPMST_OACNTCTPHONEID` (`OA_CNTCT_PHONE_ID`),
  KEY `FK_EMPMST_EMPSTATUSID` (`EMP_STATUS_ID`),
  KEY `FK_EMPMST_JOBTITLEID` (`JOB_TITLE_ID`),
  KEY `FK_EMPMST_JOBCATID` (`JOB_CAT_ID`),
  KEY `FK_EMPMST_EMPGRADEID` (`EMP_GRADE_ID`),
  KEY `FK_EMPMST_TERMINATIONID` (`TERMINATION_ID`),
  KEY `FK_EMPMST_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_EMPMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Detailed Information about the Employees' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_picture`
--

CREATE TABLE IF NOT EXISTS `emp_picture` (
  `EMP_PICYURE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Emergency contact detail id  id is identifier represents the respective id of the emp picture',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EPIC_PICTURE` mediumblob COMMENT 'Picture in BLOB format',
  `EPIC_FILENAME` varchar(100) DEFAULT NULL COMMENT 'Image file name',
  `EPIC_TYPE` varchar(100) DEFAULT NULL COMMENT 'file type',
  `EPIC_FILE_SIZE` varchar(100) DEFAULT NULL COMMENT 'Image file size',
  `EPIC_FILE_WIDTH` varchar(100) DEFAULT NULL COMMENT 'image file width',
  `EPIC_FILE_HEIGHT` varchar(100) DEFAULT NULL COMMENT 'image file height',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_PICYURE_ID`),
  KEY `FK_EMPPICTURE_EMPID` (`EMP_ID`),
  KEY `FK_EMPPICTURE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPPICTURE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Image Details of employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_reporting`
--

CREATE TABLE IF NOT EXISTS `emp_reporting` (
  `EMP_REPORTING_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee reporting  id is identifier represents the respective id of the employee reporting',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `MANAGER_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `MANAGER_TYPE_ID` int(10) NOT NULL COMMENT 'Relation type id. This is a master data driven from independent master table.the related entity is RELATION TYPE Typ_id=160 on UI this will be a dropdown control',
  `REPORTING_MODE_ID` int(10) NOT NULL COMMENT 'Relation type id. This is a master data driven from independent master table.the related entity is RELATION TYPE Typ_id=160 on UI this will be a dropdown control',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_REPORTING_ID`),
  KEY `FK_EMPREPORTING_EMPID` (`EMP_ID`),
  KEY `FK_EMPREPORTING_MANAGERID` (`MANAGER_ID`),
  KEY `FK_EMPREPORTING_MANAGERTYPEID` (`MANAGER_TYPE_ID`),
  KEY `FK_EMPREPORTING_REPORTINGMODEID` (`REPORTING_MODE_ID`),
  KEY `FK_EMPREPORTING_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPREPORTING_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Employee Supervisors' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_reporting_locations`
--

CREATE TABLE IF NOT EXISTS `emp_reporting_locations` (
  `EMP_REPORTING_LOCATIONS_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Employee reporting location  id is identifier represents the respective id of the employee reporting location',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `LOCATION_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Location master table',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_REPORTING_LOCATIONS_ID`),
  KEY `FK_EMPREPORTINGLOCATIONS_EMPID` (`EMP_ID`),
  KEY `FK_EMPREPORTINGLOCATIONS_LOCATIONID` (`LOCATION_ID`),
  KEY `FK_EMPREPORTINGLOCATIONS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPREPORTINGLOCATIONS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Location where the employee reports' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_skill`
--

CREATE TABLE IF NOT EXISTS `emp_skill` (
  `EMP_SKILL_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `SKILL_ID` int(10) NOT NULL COMMENT 'Employee skills id. This is a master data driven from independent master table.the related entity EMPLOYEE SKILLS Typ_id=170 on UI this will be a dropdown control',
  `YEARS_OF_EXP` decimal(2,0) DEFAULT NULL COMMENT 'experience in this skill',
  `COMMENTS` varchar(100) DEFAULT NULL COMMENT 'notes/description',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_SKILL_ID`),
  KEY `FK_EMPSKILL_EMPID` (`EMP_ID`),
  KEY `FK_EMPSKILL_SKILLID` (`SKILL_ID`),
  KEY `FK_EMPSKILL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPSKILL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='technical skills of that employee';

-- --------------------------------------------------------

--
-- Table structure for table `emp_work_experience`
--

CREATE TABLE IF NOT EXISTS `emp_work_experience` (
  `EMP_WORK_EXPERIENCE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee work experience  id is identifier represents the respective id of the employee work experience',
  `EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `EEXP_SEQNO` int(10) DEFAULT NULL COMMENT 'sequence of experience',
  `EEXP_EMPLOYER` varchar(100) DEFAULT NULL COMMENT 'Employee ex company',
  `JOB_TITLE_ID` int(10) NOT NULL COMMENT 'Job title id. This is a master data driven from independent master table.the related entity is JOB TITLE Typ_id=158 on UI this will be a dropdown control',
  `EEXP_FROM_DATE` datetime DEFAULT NULL COMMENT 'Start Date',
  `EEXP_TO_DATE` datetime DEFAULT NULL COMMENT 'End Date',
  `EEXP_COMMENTS` varchar(250) DEFAULT NULL COMMENT 'notes/description',
  `EEXP_INTERNAL` int(10) DEFAULT NULL COMMENT 'eexp internal',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_WORK_EXPERIENCE_ID`),
  KEY `FK_EMPWORKEXPERIENCE_EMPNUMBER` (`EMP_ID`),
  KEY `FK_EMPWORKEXPERIENCE_JOBTITLEID` (`JOB_TITLE_ID`),
  KEY `FK_EMPWORKEXPERIENCE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPWORKEXPERIENCE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='employees previous work experience' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_work_shift`
--

CREATE TABLE IF NOT EXISTS `emp_work_shift` (
  `EMP_WORK_SHIFT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Employee work shif  id is identifier represents the respective id of the employee work shft id',
  `WORK_SHIFT_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee work shift table',
  `EMP_NUMBER` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`EMP_WORK_SHIFT_ID`),
  KEY `FK_EMPWORKSHIFT_WORKSHIFTID` (`WORK_SHIFT_ID`),
  KEY `FK_EMPWORKSHIFT_EMPNUMBER` (`EMP_NUMBER`),
  KEY `FK_EMPWORKSHIFT_CREATEDBY` (`CREATED_BY`),
  KEY `FK_EMPWORKSHIFT_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Employees work shift' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_sys_err_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_sys_err_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_sys_info_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_sys_info_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_sys_warn_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_sys_warn_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_usr_err_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_usr_err_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_usr_info_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_usr_info_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `emt_usr_warn_mst_vw`
--
CREATE TABLE IF NOT EXISTS `emt_usr_warn_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `entity_obj`
--

CREATE TABLE IF NOT EXISTS `entity_obj` (
  `OBJ_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'System or application object identifier',
  `OBJ_TYP` varchar(4) NOT NULL COMMENT 'System or object type. This includes but not limited to tables, views, interfaces, procedures, functions, triggers, business objects etc',
  `OBJ_NM` varchar(40) NOT NULL COMMENT 'Name of the object',
  PRIMARY KEY (`OBJ_ID`),
  UNIQUE KEY `UK_ENTITYOBJ_OJBNM` (`OBJ_NM`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='A List of all the Entity objects including all the system table, view, procedures, functions. Business layer objects, Presentation Layer Objects, Data Layer Objects, model, View & Controller (MVC) objects' AUTO_INCREMENT=257 ;

--
-- Dumping data for table `entity_obj`
--

INSERT INTO `entity_obj` (`OBJ_ID`, `OBJ_TYP`, `OBJ_NM`) VALUES
(1, 'TABL', 'address_mst'),
(2, 'TABL', 'appl_name_mst_vw'),
(3, 'TABL', 'application_dtl'),
(4, 'TABL', 'area_name_mst_vw'),
(5, 'TABL', 'board_of_dirs_mst_vw'),
(6, 'TABL', 'buss_layer_obj_mst_vw'),
(7, 'TABL', 'cast_mst_vw'),
(8, 'TABL', 'city_name_mst_vw'),
(9, 'TABL', 'cntrllr_obj_mst_vw'),
(10, 'TABL', 'common_type'),
(11, 'TABL', 'comp_hier_mst_vw'),
(12, 'TABL', 'company_name_mst_vw'),
(13, 'TABL', 'config_mapping_dtl'),
(14, 'TABL', 'contact_add_phoneno'),
(15, 'TABL', 'contact_address'),
(16, 'TABL', 'contact_address_type_vw'),
(17, 'TABL', 'contact_emails'),
(18, 'TABL', 'contact_mst'),
(19, 'TABL', 'contact_nationality'),
(20, 'TABL', 'contact_phones'),
(21, 'TABL', 'contact_relation_type_mst_vw'),
(22, 'TABL', 'continent_name_mst_vw'),
(23, 'TABL', 'country_name_mst_vw'),
(24, 'TABL', 'county_name_mst_vw'),
(25, 'TABL', 'currency_mst'),
(26, 'TABL', 'currency_rate'),
(27, 'TABL', 'data_layer_obj_mst_vw'),
(28, 'TABL', 'db_funcations_mst_vw'),
(29, 'TABL', 'db_obj_type_mst_vw'),
(30, 'TABL', 'db_procs_mst_vw'),
(31, 'TABL', 'db_tables_mst_vw'),
(32, 'TABL', 'db_triggers_mst_vw'),
(33, 'TABL', 'db_views_mst_vw'),
(34, 'TABL', 'dependent_dtl'),
(35, 'TABL', 'dept_name_mst_vw'),
(36, 'TABL', 'directors_mst_vw'),
(37, 'TABL', 'district_name_mst_vw'),
(38, 'TABL', 'division_name_mst_vw'),
(39, 'TABL', 'email_account_dtl'),
(40, 'TABL', 'email_account_use_type_vw'),
(41, 'TABL', 'email_address_mst'),
(42, 'TABL', 'email_config'),
(43, 'TABL', 'email_subscriber'),
(44, 'TABL', 'emergency_contact_dtl'),
(45, 'TABL', 'eml_notification_mst_vw'),
(46, 'TABL', 'emp_basic_sal_dtl'),
(47, 'TABL', 'emp_education'),
(48, 'TABL', 'emp_language'),
(49, 'TABL', 'emp_licence'),
(50, 'TABL', 'emp_mst'),
(51, 'TABL', 'emp_picture'),
(52, 'TABL', 'emp_reporting'),
(53, 'TABL', 'emp_reporting_locations'),
(54, 'TABL', 'emp_skill'),
(55, 'TABL', 'emp_work_experience'),
(56, 'TABL', 'emp_work_shift'),
(57, 'TABL', 'emt_sys_err_mst_vw'),
(58, 'TABL', 'emt_sys_info_mst_vw'),
(59, 'TABL', 'emt_sys_warn_mst_vw'),
(60, 'TABL', 'emt_usr_err_mst_vw'),
(61, 'TABL', 'emt_usr_info_mst_vw'),
(62, 'TABL', 'emt_usr_warn_mst_vw'),
(63, 'TABL', 'entity_obj'),
(64, 'TABL', 'entity_obj_attrbt'),
(65, 'TABL', 'entity_obj_attrbt_dsply_dtl'),
(66, 'TABL', 'entity_obj_attrbt_mppng'),
(67, 'TABL', 'entity_obj_mppng'),
(68, 'TABL', 'entity_obj_tmp'),
(69, 'TABL', 'entity_obj_type_mst_vw'),
(70, 'TABL', 'epic_name_mst_vw'),
(71, 'TABL', 'ethinicity_mst_vw'),
(72, 'TABL', 'exception_log'),
(73, 'TABL', 'exception_message_type_mst_vw'),
(74, 'TABL', 'exe_mngmnt_mst_vw'),
(75, 'TABL', 'feature_name_mst_vw'),
(76, 'TABL', 'form_mst_vw'),
(77, 'TABL', 'gender_mst_vw'),
(78, 'TABL', 'geo_hier_mst_vw'),
(79, 'TABL', 'global_setting_item_mst_vw'),
(80, 'TABL', 'group_name_mst_vw'),
(81, 'TABL', 'group_role'),
(82, 'TABL', 'gsdatavaluetype_mst_vw'),
(83, 'TABL', 'hier_level_config'),
(84, 'TABL', 'hierarchy_type_vw'),
(85, 'TABL', 'hod_mst_vw'),
(86, 'TABL', 'independent_mst'),
(87, 'TABL', 'inface_obj_type_mst_vw'),
(88, 'TABL', 'location_mst'),
(89, 'TABL', 'location_name_mst_vw'),
(90, 'TABL', 'mail_type_mst_vw'),
(91, 'TABL', 'manager_mst_vw'),
(92, 'TABL', 'marrital_status_mst_vw'),
(93, 'TABL', 'menu_hier_vw'),
(94, 'TABL', 'menu_item_mst_vw'),
(95, 'TABL', 'message_mst'),
(96, 'TABL', 'mngt_hier_mst_vw'),
(97, 'TABL', 'model_obj_mst_vw'),
(98, 'TABL', 'module_name_mst_vw'),
(99, 'TABL', 'nationality_mst_vw'),
(100, 'TABL', 'non_personal_contact_type_mst_vw'),
(101, 'TABL', 'oa_brand_settings'),
(102, 'TABL', 'oa_brands'),
(103, 'TABL', 'oa_contact_add_phoneno'),
(104, 'TABL', 'oa_contact_address'),
(105, 'TABL', 'oa_contact_emails'),
(106, 'TABL', 'oa_contact_nationality'),
(107, 'TABL', 'oa_contact_phones'),
(108, 'TABL', 'oa_contacts'),
(109, 'TABL', 'obj_attrbt_previleges'),
(110, 'TABL', 'obj_layer_type_mst_vw'),
(111, 'TABL', 'org_accounts'),
(112, 'TABL', 'orgacct_settings_mst_vw'),
(113, 'TABL', 'permission_dtl'),
(114, 'TABL', 'phone_nbr_mst'),
(115, 'TABL', 'phone_number_type_mst_vw'),
(116, 'TABL', 'postcode_mst'),
(117, 'TABL', 'prcss_obj_type_mst_vw'),
(118, 'TABL', 'prsnttn_layer_obj_mst_vw'),
(119, 'TABL', 'race_mst_vw'),
(120, 'TABL', 'relationship_dtl'),
(121, 'TABL', 'relegion_mst_vw'),
(122, 'TABL', 'role_mst'),
(123, 'TABL', 'salutation_mst_vw'),
(124, 'TABL', 'shift_mst'),
(125, 'TABL', 'state_name_mst_vw'),
(126, 'TABL', 'street_mst'),
(127, 'TABL', 'subdept_name_mst_vw'),
(128, 'TABL', 'sw_app_hier_mst_vw'),
(129, 'TABL', 'systempermisiontype_mst_vw'),
(130, 'TABL', 'systm_glssry'),
(131, 'TABL', 'systm_lst_dtl'),
(132, 'TABL', 'theme_name_mst_vw'),
(133, 'TABL', 'timezone_mst'),
(134, 'TABL', 'toolbar_mst_vw'),
(135, 'TABL', 'town_name_mst_vw'),
(136, 'TABL', 'user_contact_type_vw'),
(137, 'TABL', 'user_contacts'),
(138, 'TABL', 'user_domain'),
(139, 'TABL', 'user_group'),
(140, 'TABL', 'user_group_dtl'),
(141, 'TABL', 'user_mst'),
(142, 'TABL', 'user_role'),
(143, 'TABL', 'user_status_vw'),
(144, 'TABL', 'view_obj_mst_vw'),
(256, 'TsTy', 'TEST4');

-- --------------------------------------------------------

--
-- Table structure for table `entity_obj_attrbt`
--

CREATE TABLE IF NOT EXISTS `entity_obj_attrbt` (
  `OBJ_ATTRBT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object attribute identifier',
  `OBJ_NM` varchar(40) NOT NULL COMMENT 'Name of the object for which the attribute belong to',
  `OBJ_ATTRBT_NM` varchar(40) NOT NULL COMMENT 'Name of the attribute',
  `OBJ_ATTRBT_DT_TYP` varchar(40) NOT NULL COMMENT 'Attribute data type',
  `OBJ_SZ` int(10) NOT NULL COMMENT 'Size of the object in numbers',
  `OBJ_PRCSN` int(10) DEFAULT NULL COMMENT 'Precision of the object in number',
  `OBJ_SCALE` int(10) DEFAULT NULL COMMENT 'Scale of the object in number',
  `IS_VISIBLE` tinyint(1) DEFAULT NULL COMMENT 'Indicates whether the column is visible on screnn or not',
  PRIMARY KEY (`OBJ_ATTRBT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='list the attributes of an system entity' AUTO_INCREMENT=2049 ;

--
-- Dumping data for table `entity_obj_attrbt`
--

INSERT INTO `entity_obj_attrbt` (`OBJ_ATTRBT_ID`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_SCALE`, `IS_VISIBLE`) VALUES
(1, 'address_mst', 'ADDRESS_ID', 'int', 10, 0, NULL, 1),
(2, 'address_mst', 'FLAT_NO', 'varchar', 10, NULL, NULL, 1),
(3, 'address_mst', 'HOUSE_NO', 'varchar', 10, NULL, NULL, 1),
(4, 'address_mst', 'HOUSE_NAME', 'varchar', 10, NULL, NULL, 1),
(5, 'address_mst', 'ADDRESS_LINE_1', 'varchar', 40, NULL, NULL, 1),
(6, 'address_mst', 'ADDRESS_LINE_2', 'varchar', 40, NULL, NULL, 1),
(7, 'address_mst', 'ADDRESS_LINE_3', 'varchar', 40, NULL, NULL, 1),
(8, 'address_mst', 'DWELLING_TYPE_ID', 'int', 10, 0, NULL, 1),
(9, 'address_mst', 'STREET_ID', 'int', 10, 0, NULL, 1),
(10, 'address_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(11, 'address_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(12, 'address_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(13, 'address_mst', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(14, 'address_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(15, 'appl_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(16, 'appl_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(17, 'appl_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(18, 'appl_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(19, 'appl_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(20, 'appl_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(21, 'appl_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(22, 'appl_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(23, 'appl_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(24, 'appl_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(25, 'appl_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(26, 'appl_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(27, 'appl_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(28, 'application_dtl', 'APP_DETAIL_ID', 'int', 10, 0, NULL, 1),
(29, 'application_dtl', 'APP_ID', 'int', 10, 0, NULL, 1),
(30, 'application_dtl', 'FUNCTION_ID', 'int', 10, 0, NULL, 1),
(31, 'application_dtl', 'EPIC_ID', 'int', 10, 0, NULL, 1),
(32, 'application_dtl', 'FEATURE_ID', 'int', 10, 0, NULL, 1),
(33, 'application_dtl', 'OPTIONAL_THEME_ID', 'int', 10, 0, NULL, 1),
(34, 'application_dtl', 'ENABLED', 'tinyint', 3, 0, NULL, 1),
(35, 'application_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(36, 'application_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(37, 'application_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(38, 'application_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(39, 'area_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(40, 'area_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(41, 'area_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(42, 'area_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(43, 'area_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(44, 'area_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(45, 'area_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(46, 'area_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(47, 'area_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(48, 'area_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(49, 'area_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(50, 'area_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(51, 'area_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(52, 'board_of_dirs_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(53, 'board_of_dirs_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(54, 'board_of_dirs_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(55, 'board_of_dirs_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(56, 'board_of_dirs_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(57, 'board_of_dirs_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(58, 'board_of_dirs_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(59, 'board_of_dirs_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(60, 'board_of_dirs_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(61, 'board_of_dirs_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(62, 'board_of_dirs_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(63, 'board_of_dirs_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(64, 'board_of_dirs_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(65, 'buss_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(66, 'buss_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(67, 'buss_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(68, 'buss_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(69, 'buss_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(70, 'buss_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(71, 'buss_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(72, 'buss_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(73, 'buss_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(74, 'buss_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(75, 'buss_layer_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(76, 'buss_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(77, 'cast_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(78, 'cast_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(79, 'cast_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(80, 'cast_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(81, 'cast_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(82, 'cast_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(83, 'cast_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(84, 'cast_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(85, 'cast_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(86, 'cast_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(87, 'cast_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(88, 'cast_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(89, 'cast_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(90, 'city_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(91, 'city_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(92, 'city_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(93, 'city_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(94, 'city_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(95, 'city_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(96, 'city_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(97, 'city_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(98, 'city_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(99, 'city_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(100, 'city_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(101, 'city_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(102, 'city_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(103, 'cntrllr_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(104, 'cntrllr_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(105, 'cntrllr_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(106, 'cntrllr_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(107, 'cntrllr_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(108, 'cntrllr_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(109, 'cntrllr_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(110, 'cntrllr_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(111, 'cntrllr_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(112, 'cntrllr_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(113, 'cntrllr_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(114, 'cntrllr_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(115, 'common_type', 'TYP_ID', 'int', 10, 0, NULL, 1),
(116, 'common_type', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(117, 'common_type', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(118, 'common_type', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(119, 'common_type', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(120, 'common_type', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(121, 'common_type', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(122, 'common_type', 'OA_ID', 'int', 10, 0, NULL, 1),
(123, 'common_type', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(124, 'common_type', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(125, 'common_type', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(126, 'common_type', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(127, 'common_type', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(128, 'comp_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(129, 'comp_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(130, 'comp_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(131, 'comp_hier_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(132, 'comp_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(133, 'comp_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(134, 'comp_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(135, 'comp_hier_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(136, 'comp_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(137, 'comp_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(138, 'comp_hier_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(139, 'comp_hier_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(140, 'comp_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(141, 'company_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(142, 'company_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(143, 'company_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(144, 'company_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(145, 'company_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(146, 'company_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(147, 'company_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(148, 'company_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(149, 'company_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(150, 'company_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(151, 'company_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(152, 'company_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(153, 'company_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(154, 'config_mapping_dtl', 'CNFG_MPPNG_DTL_ID', 'int', 10, 0, NULL, 1),
(155, 'config_mapping_dtl', 'SRC_ENTTY_ID', 'int', 10, 0, NULL, 1),
(156, 'config_mapping_dtl', 'TRGT_ENTTY_ID', 'int', 10, 0, NULL, 1),
(157, 'config_mapping_dtl', 'CNFG_MPPNG_TYP_ID', 'int', 10, 0, NULL, 1),
(158, 'config_mapping_dtl', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(159, 'config_mapping_dtl', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(160, 'config_mapping_dtl', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(161, 'config_mapping_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(162, 'config_mapping_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(163, 'contact_add_phoneno', 'CNTCT_ADD_PHONENO_ID', 'int', 10, 0, NULL, 1),
(164, 'contact_add_phoneno', 'CNTCT_ADD_ID', 'int', 10, 0, NULL, 1),
(165, 'contact_add_phoneno', 'CNTCT_NBR_ID', 'int', 10, 0, NULL, 1),
(166, 'contact_add_phoneno', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(167, 'contact_add_phoneno', 'IS_PRIMARY_TELNO', 'tinyint', 3, 0, NULL, 1),
(168, 'contact_add_phoneno', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(169, 'contact_add_phoneno', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(170, 'contact_add_phoneno', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(171, 'contact_add_phoneno', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(172, 'contact_address', 'CNTCT_ADD_ID', 'int', 10, 0, NULL, 1),
(173, 'contact_address', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(174, 'contact_address', 'CNTCT_ADD_TYPE_ID', 'int', 10, 0, NULL, 1),
(175, 'contact_address', 'ADD_ID', 'int', 10, 0, NULL, 1),
(176, 'contact_address', 'CNTCT_ADD_START_DATE', 'datetime', 0, NULL, NULL, 1),
(177, 'contact_address', 'CNTCT_ADD_END_DATE', 'datetime', 0, NULL, NULL, 1),
(178, 'contact_address', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(179, 'contact_address', 'IS_CURRENT_ADD', 'tinyint', 3, 0, NULL, 1),
(180, 'contact_address', 'IS_PRIMARY_ADD', 'tinyint', 3, 0, NULL, 1),
(181, 'contact_address', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(182, 'contact_address', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(183, 'contact_address', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(184, 'contact_address', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(185, 'contact_address_type_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(186, 'contact_address_type_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(187, 'contact_address_type_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(188, 'contact_address_type_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(189, 'contact_address_type_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(190, 'contact_address_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(191, 'contact_address_type_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(192, 'contact_address_type_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(193, 'contact_address_type_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(194, 'contact_address_type_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(195, 'contact_address_type_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(196, 'contact_address_type_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(197, 'contact_address_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(198, 'contact_emails', 'CNTCT_EML_ID', 'int', 10, 0, NULL, 1),
(199, 'contact_emails', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(200, 'contact_emails', 'EMAIL_ADD_ID', 'int', 10, 0, NULL, 1),
(201, 'contact_emails', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(202, 'contact_emails', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(203, 'contact_emails', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(204, 'contact_emails', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(205, 'contact_emails', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(206, 'contact_emails', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(207, 'contact_mst', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(208, 'contact_mst', 'CNTCT_SALUTATION_ID', 'int', 10, 0, NULL, 1),
(209, 'contact_mst', 'CNTCT_FRST_NM', 'varchar', 40, NULL, NULL, 1),
(210, 'contact_mst', 'CNTCT_LST_NM', 'varchar', 40, NULL, NULL, 1),
(211, 'contact_mst', 'CNTCT_MDDL_NM', 'varchar', 40, NULL, NULL, 1),
(212, 'contact_mst', 'CNTCT_OTHER_NM', 'varchar', 40, NULL, NULL, 1),
(213, 'contact_mst', 'CNTCT_PRFRD_NM', 'varchar', 40, NULL, NULL, 1),
(214, 'contact_mst', 'CNTCT_DOB', 'varchar', 40, NULL, NULL, 1),
(215, 'contact_mst', 'CNTCT_SMOKER', 'tinyint', 3, 0, NULL, 1),
(216, 'contact_mst', 'CNTCT_GENDER_ID', 'int', 10, 0, NULL, 1),
(217, 'contact_mst', 'MARRITAL_STATUS_ID', 'int', 10, 0, NULL, 1),
(218, 'contact_mst', 'CAST_ID', 'int', 10, 0, NULL, 1),
(219, 'contact_mst', 'RASE_ID', 'int', 10, 0, NULL, 1),
(220, 'contact_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(221, 'contact_mst', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(222, 'contact_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(223, 'contact_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(224, 'contact_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(225, 'contact_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(226, 'contact_nationality', 'CNTCT_NATIONALITY_ID', 'int', 10, 0, NULL, 1),
(227, 'contact_nationality', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(228, 'contact_nationality', 'NATIONALITY_ID', 'int', 10, 0, NULL, 1),
(229, 'contact_nationality', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(230, 'contact_nationality', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(231, 'contact_nationality', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(232, 'contact_nationality', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(233, 'contact_nationality', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(234, 'contact_nationality', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(235, 'contact_phones', 'CNTCT_PHONE_ID', 'int', 10, 0, NULL, 1),
(236, 'contact_phones', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(237, 'contact_phones', 'PHONE_NBR_ID', 'int', 10, 0, NULL, 1),
(238, 'contact_phones', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(239, 'contact_phones', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(240, 'contact_phones', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(241, 'contact_phones', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(242, 'contact_phones', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(243, 'contact_phones', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(244, 'contact_relation_type_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(245, 'contact_relation_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(246, 'contact_relation_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(247, 'contact_relation_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(248, 'contact_relation_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(249, 'contact_relation_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(250, 'contact_relation_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(251, 'contact_relation_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(252, 'contact_relation_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(253, 'contact_relation_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(254, 'contact_relation_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(255, 'contact_relation_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(256, 'contact_relation_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(257, 'continent_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(258, 'continent_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(259, 'continent_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(260, 'continent_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(261, 'continent_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(262, 'continent_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(263, 'continent_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(264, 'continent_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(265, 'continent_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(266, 'continent_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(267, 'continent_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(268, 'continent_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(269, 'continent_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(270, 'country_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(271, 'country_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(272, 'country_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(273, 'country_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(274, 'country_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(275, 'country_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(276, 'country_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(277, 'country_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(278, 'country_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(279, 'country_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(280, 'country_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(281, 'country_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(282, 'country_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(283, 'county_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(284, 'county_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(285, 'county_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(286, 'county_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(287, 'county_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(288, 'county_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(289, 'county_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(290, 'county_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(291, 'county_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(292, 'county_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(293, 'county_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(294, 'county_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(295, 'county_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(296, 'currency_mst', 'CURR_ID', 'int', 10, 0, NULL, 1),
(297, 'currency_mst', 'CURR_CODE', 'varchar', 5, NULL, NULL, 1),
(298, 'currency_mst', 'CURR_NAME', 'varchar', 40, NULL, NULL, 1),
(299, 'currency_mst', 'CURR_SYMBOL', 'varchar', 5, NULL, NULL, 1),
(300, 'currency_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(301, 'currency_mst', 'COUNTRY_ID', 'int', 10, 0, NULL, 1),
(302, 'currency_mst', 'REF_NBR', 'varchar', 10, NULL, NULL, 1),
(303, 'currency_mst', 'CURR_COMMENTS', 'varchar', 255, NULL, NULL, 1),
(304, 'currency_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(305, 'currency_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(306, 'currency_mst', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(307, 'currency_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(308, 'currency_rate', 'CURR_RATE_ID', 'int', 10, 0, NULL, 1),
(309, 'currency_rate', 'SRC_CURR_ID', 'int', 10, 0, NULL, 1),
(310, 'currency_rate', 'TRG_CURR_ID', 'int', 10, 0, NULL, 1),
(311, 'currency_rate', 'EX_RATE', 'decimal', 10, 5, NULL, 1),
(312, 'currency_rate', 'EFF_FROM', 'datetime', 0, NULL, NULL, 1),
(313, 'currency_rate', 'EFF_TO', 'datetime', 0, NULL, NULL, 1),
(314, 'currency_rate', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(315, 'currency_rate', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(316, 'currency_rate', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(317, 'currency_rate', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(318, 'data_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(319, 'data_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(320, 'data_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(321, 'data_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(322, 'data_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(323, 'data_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(324, 'data_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(325, 'data_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(326, 'data_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(327, 'data_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(328, 'data_layer_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(329, 'data_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(330, 'db_funcations_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(331, 'db_funcations_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(332, 'db_funcations_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(333, 'db_funcations_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(334, 'db_funcations_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(335, 'db_funcations_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(336, 'db_funcations_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(337, 'db_funcations_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(338, 'db_funcations_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(339, 'db_funcations_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(340, 'db_funcations_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(341, 'db_funcations_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(342, 'db_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(343, 'db_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(344, 'db_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(345, 'db_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(346, 'db_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(347, 'db_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(348, 'db_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(349, 'db_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(350, 'db_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(351, 'db_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(352, 'db_obj_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(353, 'db_obj_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(354, 'db_procs_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(355, 'db_procs_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(356, 'db_procs_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(357, 'db_procs_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(358, 'db_procs_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(359, 'db_procs_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(360, 'db_procs_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(361, 'db_procs_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(362, 'db_procs_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(363, 'db_procs_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(364, 'db_procs_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(365, 'db_procs_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(366, 'db_tables_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(367, 'db_tables_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(368, 'db_tables_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(369, 'db_tables_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(370, 'db_tables_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(371, 'db_tables_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(372, 'db_tables_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(373, 'db_tables_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(374, 'db_tables_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(375, 'db_tables_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(376, 'db_tables_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(377, 'db_tables_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(378, 'db_triggers_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(379, 'db_triggers_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(380, 'db_triggers_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(381, 'db_triggers_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(382, 'db_triggers_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(383, 'db_triggers_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(384, 'db_triggers_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(385, 'db_triggers_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(386, 'db_triggers_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(387, 'db_triggers_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(388, 'db_triggers_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(389, 'db_triggers_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(390, 'db_views_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(391, 'db_views_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(392, 'db_views_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(393, 'db_views_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(394, 'db_views_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(395, 'db_views_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(396, 'db_views_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(397, 'db_views_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(398, 'db_views_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(399, 'db_views_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(400, 'db_views_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(401, 'db_views_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(402, 'dependent_dtl', 'DEPENDENT_DTL_ID', 'int', 10, 0, NULL, 1),
(403, 'dependent_dtl', 'EMP_ID', 'int', 10, 0, NULL, 1),
(404, 'dependent_dtl', 'OA_DEP_CNTCTS_ID', 'int', 10, 0, NULL, 1),
(405, 'dependent_dtl', 'RELATION_TYPE_ID', 'int', 10, 0, NULL, 1),
(406, 'dependent_dtl', 'REALTION_TYPE_NAME', 'varchar', 100, NULL, NULL, 1),
(407, 'dependent_dtl', 'DATE_OF_BIRTH', 'datetime', 0, NULL, NULL, 1),
(408, 'dependent_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(409, 'dependent_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(410, 'dependent_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(411, 'dependent_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(412, 'dept_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(413, 'dept_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(414, 'dept_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(415, 'dept_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(416, 'dept_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(417, 'dept_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(418, 'dept_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(419, 'dept_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(420, 'dept_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(421, 'dept_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(422, 'dept_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(423, 'dept_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(424, 'dept_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(425, 'directors_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(426, 'directors_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(427, 'directors_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(428, 'directors_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(429, 'directors_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(430, 'directors_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(431, 'directors_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(432, 'directors_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(433, 'directors_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(434, 'directors_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(435, 'directors_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(436, 'directors_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(437, 'directors_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(438, 'district_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(439, 'district_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(440, 'district_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(441, 'district_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(442, 'district_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(443, 'district_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(444, 'district_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(445, 'district_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(446, 'district_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(447, 'district_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(448, 'district_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(449, 'district_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(450, 'district_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(451, 'division_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(452, 'division_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(453, 'division_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(454, 'division_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(455, 'division_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(456, 'division_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(457, 'division_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(458, 'division_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(459, 'division_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(460, 'division_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(461, 'division_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(462, 'division_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(463, 'division_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(464, 'email_account_dtl', 'EMAIL_ACCT_ID', 'int', 10, 0, NULL, 1),
(465, 'email_account_dtl', 'EMAIL_ADD_ID', 'int', 10, 0, NULL, 1),
(466, 'email_account_dtl', 'CONTACT_ID', 'int', 10, 0, NULL, 1),
(467, 'email_account_dtl', 'EMAIL_ACC_FNAME', 'varchar', 40, NULL, NULL, 1),
(468, 'email_account_dtl', 'EMAIL_ACC_LNAME', 'varchar', 40, NULL, NULL, 1),
(469, 'email_account_dtl', 'EMAIL_ACC_ADD_ID', 'int', 10, 0, NULL, 1),
(470, 'email_account_dtl', 'EMAIL_ACCT_USE_TYPE_ID', 'int', 10, 0, NULL, 1),
(471, 'email_account_dtl', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(472, 'email_account_dtl', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(473, 'email_account_dtl', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(474, 'email_account_dtl', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(475, 'email_account_dtl', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(476, 'email_account_use_type_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(477, 'email_account_use_type_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(478, 'email_account_use_type_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(479, 'email_account_use_type_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(480, 'email_account_use_type_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(481, 'email_account_use_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(482, 'email_account_use_type_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(483, 'email_account_use_type_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(484, 'email_account_use_type_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(485, 'email_account_use_type_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(486, 'email_account_use_type_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(487, 'email_account_use_type_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(488, 'email_account_use_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(489, 'email_address_mst', 'EMAIL_ADD_ID', 'int', 10, 0, NULL, 1),
(490, 'email_address_mst', 'EMAIL_ADD', 'varchar', 40, NULL, NULL, 1),
(491, 'email_address_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(492, 'email_address_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(493, 'email_address_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(494, 'email_address_mst', 'CREATEDON', 'timestamp', 0, NULL, NULL, 1),
(495, 'email_address_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(496, 'email_config', 'EML_CNFG_ID', 'int', 10, 0, NULL, 1),
(497, 'email_config', 'MAIL_TYPE_ID', 'int', 10, 0, NULL, 1),
(498, 'email_config', 'SENT_AS0', 'varchar', 250, NULL, NULL, 1),
(499, 'email_config', 'SENDMAIL_PATH', 'varchar', 250, NULL, NULL, 1),
(500, 'email_config', 'SMTP_HOST', 'varchar', 250, NULL, NULL, 1),
(501, 'email_config', 'SMTP_PORT', 'int', 10, 0, NULL, 1),
(502, 'email_config', 'SMTP_USERNAME', 'varchar', 250, NULL, NULL, 1),
(503, 'email_config', 'SMTP_PASSWORD', 'varchar', 250, NULL, NULL, 1),
(504, 'email_config', 'SMTP_AUTH_TYPE', 'varchar', 50, NULL, NULL, 1),
(505, 'email_config', 'SMTP_SECURITY_TYPE', 'varchar', 50, NULL, NULL, 1),
(506, 'email_config', 'OA_ID', 'int', 10, 0, NULL, 1),
(507, 'email_config', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(508, 'email_config', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(509, 'email_config', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(510, 'email_config', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(511, 'email_config', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(512, 'email_config', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(513, 'email_subscriber', 'EML_SBSCRBR_ID', 'int', 10, 0, NULL, 1),
(514, 'email_subscriber', 'NOTIFICATION_ID', 'int', 10, 0, NULL, 1),
(515, 'email_subscriber', 'SUBCRIBER_NAME', 'varchar', 100, NULL, NULL, 1),
(516, 'email_subscriber', 'SUBSCRIBER_EMAIL', 'varchar', 100, NULL, NULL, 1),
(517, 'email_subscriber', 'OA_ID', 'int', 10, 0, NULL, 1),
(518, 'email_subscriber', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(519, 'email_subscriber', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(520, 'email_subscriber', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(521, 'email_subscriber', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(522, 'email_subscriber', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(523, 'emergency_contact_dtl', 'EMERGENCY_CONTACT_DTL_ID', 'int', 10, 0, NULL, 1),
(524, 'emergency_contact_dtl', 'EMP_ID', 'int', 10, 0, NULL, 1),
(525, 'emergency_contact_dtl', 'EMERG_CONTACT_ID', 'int', 10, 0, NULL, 1),
(526, 'emergency_contact_dtl', 'EMERG_CONTACT_RELATION_TYPE_ID', 'int', 10, 0, NULL, 1),
(527, 'emergency_contact_dtl', 'EMERG_CONTACT_TEL_ID', 'int', 10, 0, NULL, 1),
(528, 'emergency_contact_dtl', 'EMERG_CONTACT_MOBILE_ID', 'int', 10, 0, NULL, 1),
(529, 'emergency_contact_dtl', 'EMERG_CONTACT_OFFNO_ID', 'int', 10, 0, NULL, 1),
(530, 'emergency_contact_dtl', 'EMERG_CONTACT_EMAIL_ID', 'int', 10, 0, NULL, 1),
(531, 'emergency_contact_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(532, 'emergency_contact_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(533, 'emergency_contact_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(534, 'emergency_contact_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(535, 'eml_notification_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(536, 'eml_notification_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(537, 'eml_notification_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(538, 'eml_notification_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(539, 'eml_notification_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(540, 'eml_notification_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(541, 'eml_notification_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(542, 'eml_notification_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(543, 'eml_notification_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(544, 'eml_notification_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(545, 'eml_notification_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(546, 'eml_notification_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(547, 'eml_notification_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(548, 'emp_basic_sal_dtl', 'EMP_BASIC_SAL_DTL_ID', 'int', 10, 0, NULL, 1),
(549, 'emp_basic_sal_dtl', 'EMP_ID', 'int', 10, 0, NULL, 1),
(550, 'emp_basic_sal_dtl', 'EMP_GRADE_ID', 'int', 10, 0, NULL, 1),
(551, 'emp_basic_sal_dtl', 'POSITION_ID', 'int', 10, 0, NULL, 1),
(552, 'emp_basic_sal_dtl', 'CURRENCY_ID', 'int', 10, 0, NULL, 1),
(553, 'emp_basic_sal_dtl', 'BASIC_SALARY', 'decimal', 10, 2, NULL, 1),
(554, 'emp_basic_sal_dtl', 'PAY_FREQUENCY_ID', 'int', 10, 0, NULL, 1),
(555, 'emp_basic_sal_dtl', 'COMPONENT_DESC', 'varchar', 100, NULL, NULL, 1),
(556, 'emp_basic_sal_dtl', 'COMMENTS', 'varchar', 255, NULL, NULL, 1),
(557, 'emp_basic_sal_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(558, 'emp_basic_sal_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(559, 'emp_basic_sal_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(560, 'emp_basic_sal_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(561, 'emp_education', 'ID', 'int', 10, 0, NULL, 1),
(562, 'emp_education', 'EMP_ID', 'int', 10, 0, NULL, 1),
(563, 'emp_education', 'EDU_QUAL_ID', 'int', 10, 0, NULL, 1),
(564, 'emp_education', 'INSTITUTE', 'varchar', 100, NULL, NULL, 1),
(565, 'emp_education', 'MAJOR', 'varchar', 100, NULL, NULL, 1),
(566, 'emp_education', 'YEAR', 'decimal', 4, 0, NULL, 1),
(567, 'emp_education', 'SCORE', 'varchar', 100, NULL, NULL, 1),
(568, 'emp_education', 'START_DATE', 'date', 0, NULL, NULL, 1),
(569, 'emp_education', 'END_DATE', 'date', 0, NULL, NULL, 1),
(570, 'emp_education', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(571, 'emp_education', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(572, 'emp_education', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(573, 'emp_education', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(574, 'emp_language', 'EMP_LANGUAGE_ID', 'int', 10, 0, NULL, 1),
(575, 'emp_language', 'EMP_ID', 'int', 10, 0, NULL, 1),
(576, 'emp_language', 'LANGUAGE_ID', 'int', 10, 0, NULL, 1),
(577, 'emp_language', 'LANGUAGE_FLUENCY_ID', 'int', 10, 0, NULL, 1),
(578, 'emp_language', 'LANGUAGE_COMPETENCY_ID', 'int', 10, 0, NULL, 1),
(579, 'emp_language', 'COMMENTS', 'varchar', 100, NULL, NULL, 1),
(580, 'emp_language', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(581, 'emp_language', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(582, 'emp_language', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(583, 'emp_language', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(584, 'emp_licence', 'LICENSE_ID', 'int', 10, 0, NULL, 1),
(585, 'emp_licence', 'EMP_ID', 'int', 10, 0, NULL, 1),
(586, 'emp_licence', 'LICENSE_NO', 'varchar', 100, NULL, NULL, 1),
(587, 'emp_licence', 'LICENSE_ISSUED_DATE', 'date', 0, NULL, NULL, 1),
(588, 'emp_licence', 'LICENSE_EXPIRY_DATE', 'date', 0, NULL, NULL, 1),
(589, 'emp_licence', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(590, 'emp_licence', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(591, 'emp_licence', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(592, 'emp_licence', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(593, 'emp_mst', 'EMP_ID', 'int', 10, 0, NULL, 1),
(594, 'emp_mst', 'EMP_NAME', 'varchar', 250, NULL, NULL, 1),
(595, 'emp_mst', 'EMP_NBR', 'varchar', 100, NULL, NULL, 1),
(596, 'emp_mst', 'OA_CNTCTS_ID', 'int', 10, 0, NULL, 1),
(597, 'emp_mst', 'OA_CNTCT_ADD_ID', 'int', 10, 0, NULL, 1),
(598, 'emp_mst', 'OA_CNTCT_EML_ID', 'int', 10, 0, NULL, 1),
(599, 'emp_mst', 'OA_CNTCT_PHONE_ID', 'int', 10, 0, NULL, 1),
(600, 'emp_mst', 'EMP_SSN_NBR', 'varchar', 100, NULL, NULL, 1),
(601, 'emp_mst', 'EMP_SIN_NBR', 'varchar', 100, NULL, NULL, 1),
(602, 'emp_mst', 'EMP_OTHER_ID', 'varchar', 100, NULL, NULL, 1),
(603, 'emp_mst', 'EMP_DRI_LICE_NBR', 'varchar', 100, NULL, NULL, 1),
(604, 'emp_mst', 'EMP_DRI_LICE_EXP_DATE', 'datetime', 0, NULL, NULL, 1),
(605, 'emp_mst', 'EMP_MILITARY_SERVICE', 'varchar', 100, NULL, NULL, 1),
(606, 'emp_mst', 'EMP_STATUS_ID', 'int', 10, 0, NULL, 1),
(607, 'emp_mst', 'JOB_TITLE_ID', 'int', 10, 0, NULL, 1),
(608, 'emp_mst', 'JOB_CAT_ID', 'int', 10, 0, NULL, 1),
(609, 'emp_mst', 'WORK_STATION', 'varchar', 100, NULL, NULL, 1),
(610, 'emp_mst', 'EMP_GRADE_ID', 'int', 10, 0, NULL, 1),
(611, 'emp_mst', 'DATE_OF_JOINING', 'datetime', 0, NULL, NULL, 1),
(612, 'emp_mst', 'TERMINATION_ID', 'int', 10, 0, NULL, 1),
(613, 'emp_mst', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(614, 'emp_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(615, 'emp_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(616, 'emp_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(617, 'emp_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(618, 'emp_picture', 'EMP_PICYURE_ID', 'int', 10, 0, NULL, 1),
(619, 'emp_picture', 'EMP_ID', 'int', 10, 0, NULL, 1),
(620, 'emp_picture', 'EPIC_PICTURE', 'mediumblob', 16777215, NULL, NULL, 1),
(621, 'emp_picture', 'EPIC_FILENAME', 'varchar', 100, NULL, NULL, 1),
(622, 'emp_picture', 'EPIC_TYPE', 'varchar', 100, NULL, NULL, 1),
(623, 'emp_picture', 'EPIC_FILE_SIZE', 'varchar', 100, NULL, NULL, 1),
(624, 'emp_picture', 'EPIC_FILE_WIDTH', 'varchar', 100, NULL, NULL, 1),
(625, 'emp_picture', 'EPIC_FILE_HEIGHT', 'varchar', 100, NULL, NULL, 1),
(626, 'emp_picture', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(627, 'emp_picture', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(628, 'emp_picture', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(629, 'emp_picture', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(630, 'emp_reporting', 'EMP_REPORTING_ID', 'int', 10, 0, NULL, 1),
(631, 'emp_reporting', 'EMP_ID', 'int', 10, 0, NULL, 1),
(632, 'emp_reporting', 'MANAGER_ID', 'int', 10, 0, NULL, 1),
(633, 'emp_reporting', 'MANAGER_TYPE_ID', 'int', 10, 0, NULL, 1),
(634, 'emp_reporting', 'REPORTING_MODE_ID', 'int', 10, 0, NULL, 1),
(635, 'emp_reporting', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(636, 'emp_reporting', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(637, 'emp_reporting', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(638, 'emp_reporting', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(639, 'emp_reporting_locations', 'EMP_REPORTING_LOCATIONS_ID', 'int', 10, 0, NULL, 1),
(640, 'emp_reporting_locations', 'EMP_ID', 'int', 10, 0, NULL, 1),
(641, 'emp_reporting_locations', 'LOCATION_ID', 'int', 10, 0, NULL, 1),
(642, 'emp_reporting_locations', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(643, 'emp_reporting_locations', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(644, 'emp_reporting_locations', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(645, 'emp_reporting_locations', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(646, 'emp_skill', 'EMP_SKILL_ID', 'int', 10, 0, NULL, 1),
(647, 'emp_skill', 'EMP_ID', 'int', 10, 0, NULL, 1),
(648, 'emp_skill', 'SKILL_ID', 'int', 10, 0, NULL, 1),
(649, 'emp_skill', 'YEARS_OF_EXP', 'decimal', 2, 0, NULL, 1),
(650, 'emp_skill', 'COMMENTS', 'varchar', 100, NULL, NULL, 1),
(651, 'emp_skill', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(652, 'emp_skill', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(653, 'emp_skill', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(654, 'emp_skill', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(655, 'emp_work_experience', 'EMP_WORK_EXPERIENCE_ID', 'int', 10, 0, NULL, 1),
(656, 'emp_work_experience', 'EMP_ID', 'int', 10, 0, NULL, 1),
(657, 'emp_work_experience', 'EEXP_SEQNO', 'int', 10, 0, NULL, 1),
(658, 'emp_work_experience', 'EEXP_EMPLOYER', 'varchar', 100, NULL, NULL, 1),
(659, 'emp_work_experience', 'JOB_TITLE_ID', 'int', 10, 0, NULL, 1),
(660, 'emp_work_experience', 'EEXP_FROM_DATE', 'datetime', 0, NULL, NULL, 1),
(661, 'emp_work_experience', 'EEXP_TO_DATE', 'datetime', 0, NULL, NULL, 1),
(662, 'emp_work_experience', 'EEXP_COMMENTS', 'varchar', 250, NULL, NULL, 1),
(663, 'emp_work_experience', 'EEXP_INTERNAL', 'int', 10, 0, NULL, 1),
(664, 'emp_work_experience', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(665, 'emp_work_experience', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(666, 'emp_work_experience', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(667, 'emp_work_experience', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(668, 'emp_work_shift', 'EMP_WORK_SHIFT_ID', 'int', 10, 0, NULL, 1),
(669, 'emp_work_shift', 'WORK_SHIFT_ID', 'int', 10, 0, NULL, 1),
(670, 'emp_work_shift', 'EMP_NUMBER', 'int', 10, 0, NULL, 1),
(671, 'emp_work_shift', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(672, 'emp_work_shift', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(673, 'emp_work_shift', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(674, 'emp_work_shift', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(675, 'emt_sys_err_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(676, 'emt_sys_err_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(677, 'emt_sys_err_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(678, 'emt_sys_err_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(679, 'emt_sys_err_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(680, 'emt_sys_err_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(681, 'emt_sys_err_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(682, 'emt_sys_err_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(683, 'emt_sys_err_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(684, 'emt_sys_err_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(685, 'emt_sys_err_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(686, 'emt_sys_err_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(687, 'emt_sys_info_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(688, 'emt_sys_info_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(689, 'emt_sys_info_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(690, 'emt_sys_info_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(691, 'emt_sys_info_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(692, 'emt_sys_info_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(693, 'emt_sys_info_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(694, 'emt_sys_info_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(695, 'emt_sys_info_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(696, 'emt_sys_info_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(697, 'emt_sys_info_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(698, 'emt_sys_info_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(699, 'emt_sys_warn_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(700, 'emt_sys_warn_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(701, 'emt_sys_warn_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(702, 'emt_sys_warn_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(703, 'emt_sys_warn_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(704, 'emt_sys_warn_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(705, 'emt_sys_warn_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(706, 'emt_sys_warn_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(707, 'emt_sys_warn_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(708, 'emt_sys_warn_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(709, 'emt_sys_warn_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(710, 'emt_sys_warn_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(711, 'emt_usr_err_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(712, 'emt_usr_err_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(713, 'emt_usr_err_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(714, 'emt_usr_err_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(715, 'emt_usr_err_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(716, 'emt_usr_err_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(717, 'emt_usr_err_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(718, 'emt_usr_err_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(719, 'emt_usr_err_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(720, 'emt_usr_err_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(721, 'emt_usr_err_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(722, 'emt_usr_err_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(723, 'emt_usr_info_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(724, 'emt_usr_info_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(725, 'emt_usr_info_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(726, 'emt_usr_info_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(727, 'emt_usr_info_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(728, 'emt_usr_info_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(729, 'emt_usr_info_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(730, 'emt_usr_info_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(731, 'emt_usr_info_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(732, 'emt_usr_info_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(733, 'emt_usr_info_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(734, 'emt_usr_info_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(735, 'emt_usr_warn_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(736, 'emt_usr_warn_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(737, 'emt_usr_warn_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(738, 'emt_usr_warn_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(739, 'emt_usr_warn_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(740, 'emt_usr_warn_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(741, 'emt_usr_warn_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(742, 'emt_usr_warn_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(743, 'emt_usr_warn_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(744, 'emt_usr_warn_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(745, 'emt_usr_warn_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(746, 'emt_usr_warn_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(747, 'entity_obj', 'OBJ_ID', 'int', 10, 0, NULL, 1),
(748, 'entity_obj', 'OBJ_TYP', 'varchar', 4, NULL, NULL, 1),
(749, 'entity_obj', 'OBJ_NM', 'varchar', 40, NULL, NULL, 1),
(750, 'entity_obj_attrbt', 'OBJ_ATTRBT_ID', 'int', 10, 0, NULL, 1),
(751, 'entity_obj_attrbt', 'OBJ_NM', 'varchar', 40, NULL, NULL, 1),
(752, 'entity_obj_attrbt', 'OBJ_ATTRBT_NM', 'varchar', 40, NULL, NULL, 1),
(753, 'entity_obj_attrbt', 'OBJ_ATTRBT_DT_TYP', 'varchar', 40, NULL, NULL, 1),
(754, 'entity_obj_attrbt', 'OBJ_SZ', 'int', 10, 0, NULL, 1),
(755, 'entity_obj_attrbt', 'OBJ_PRCSN', 'int', 10, 0, NULL, 1),
(756, 'entity_obj_attrbt', 'OBJ_SCALE', 'int', 10, 0, NULL, 1),
(757, 'entity_obj_attrbt', 'IS_VISIBLE', 'tinyint', 3, 0, NULL, 1),
(758, 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_DSPLY_ID', 'int', 10, 0, NULL, 1),
(759, 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_ID', 'int', 10, 0, NULL, 1),
(760, 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_DSPLY_NM', 'varchar', 40, NULL, NULL, 1),
(761, 'entity_obj_attrbt_dsply_dtl', 'OA_ID', 'int', 10, 0, NULL, 1),
(762, 'entity_obj_attrbt_dsply_dtl', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(763, 'entity_obj_attrbt_dsply_dtl', 'USER_ID', 'int', 10, 0, NULL, 1);
INSERT INTO `entity_obj_attrbt` (`OBJ_ATTRBT_ID`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_SCALE`, `IS_VISIBLE`) VALUES
(764, 'entity_obj_attrbt_mppng', 'OBJ_ATTRBT_MPPNG_ID', 'int', 10, 0, NULL, 1),
(765, 'entity_obj_attrbt_mppng', 'SRC_OJB_NM', 'varchar', 40, NULL, NULL, 1),
(766, 'entity_obj_attrbt_mppng', 'SRC_OBJ_ATTRBT_NM', 'varchar', 40, NULL, NULL, 1),
(767, 'entity_obj_attrbt_mppng', 'TRG_OJB_NM', 'varchar', 40, NULL, NULL, 1),
(768, 'entity_obj_attrbt_mppng', 'TRG_OBJ_ATTRBT_NM', 'varchar', 40, NULL, NULL, 1),
(769, 'entity_obj_attrbt_mppng', 'OBJ_MPPNG_ID', 'int', 10, 0, NULL, 1),
(770, 'entity_obj_mppng', 'OBJ_MPPNG_ID', 'int', 10, 0, NULL, 1),
(771, 'entity_obj_mppng', 'SRC_LYR_ID', 'int', 10, 0, NULL, 1),
(772, 'entity_obj_mppng', 'SRC_OBJ_ID', 'int', 10, 0, NULL, 1),
(773, 'entity_obj_mppng', 'TRGT_LYR_ID', 'int', 10, 0, NULL, 1),
(774, 'entity_obj_mppng', 'TRGT_OBJ_ID', 'int', 10, 0, NULL, 1),
(775, 'entity_obj_tmp', 'TMP_OBJ_ID', 'int', 10, 0, NULL, 1),
(776, 'entity_obj_tmp', 'OBJ_TYP', 'varchar', 4, NULL, NULL, 1),
(777, 'entity_obj_tmp', 'OBJ_NM', 'varchar', 40, NULL, NULL, 1),
(778, 'entity_obj_tmp', 'OBJ_ATTRBT_NM', 'varchar', 40, NULL, NULL, 1),
(779, 'entity_obj_tmp', 'OBJ_ATTRBT_DT_TYP', 'varchar', 40, NULL, NULL, 1),
(780, 'entity_obj_tmp', 'OBJ_SZ', 'int', 10, 0, NULL, 1),
(781, 'entity_obj_tmp', 'OBJ_PRCSN', 'int', 10, 0, NULL, 1),
(782, 'entity_obj_tmp', 'OBJ_NW_RCRD_FLG', 'tinyint', 3, 0, NULL, 1),
(783, 'entity_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(784, 'entity_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(785, 'entity_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(786, 'entity_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(787, 'entity_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(788, 'entity_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(789, 'entity_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(790, 'entity_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(791, 'entity_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(792, 'entity_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(793, 'entity_obj_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(794, 'entity_obj_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(795, 'epic_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(796, 'epic_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(797, 'epic_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(798, 'epic_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(799, 'epic_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(800, 'epic_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(801, 'epic_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(802, 'epic_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(803, 'epic_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(804, 'epic_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(805, 'epic_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(806, 'epic_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(807, 'epic_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(808, 'ethinicity_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(809, 'ethinicity_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(810, 'ethinicity_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(811, 'ethinicity_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(812, 'ethinicity_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(813, 'ethinicity_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(814, 'ethinicity_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(815, 'ethinicity_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(816, 'ethinicity_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(817, 'ethinicity_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(818, 'ethinicity_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(819, 'ethinicity_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(820, 'ethinicity_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(821, 'exception_log', 'EXCEPTION_LOG_ID', 'int', 10, 0, NULL, 1),
(822, 'exception_log', 'EXCEPTION_TYPE_ID', 'int', 10, 0, NULL, 1),
(823, 'exception_log', 'SESSION_ID', 'varchar', 500, NULL, NULL, 1),
(824, 'exception_log', 'APP_ID', 'int', 10, 0, NULL, 1),
(825, 'exception_log', 'MODULE_ID', 'int', 10, 0, NULL, 1),
(826, 'exception_log', 'PROCESS_ID', 'int', 10, 0, NULL, 1),
(827, 'exception_log', 'LOCATION_NO', 'int', 10, 0, NULL, 1),
(828, 'exception_log', 'ERROR_NBR', 'int', 10, 0, NULL, 1),
(829, 'exception_log', 'ERROR_DESC', 'varchar', 4000, NULL, NULL, 1),
(830, 'exception_log', 'OA_ID', 'int', 10, 0, NULL, 1),
(831, 'exception_log', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(832, 'exception_log', 'ERROR_STACK', 'varchar', 4000, NULL, NULL, 1),
(833, 'exception_log', 'CALL_STACK', 'varchar', 4000, NULL, NULL, 1),
(834, 'exception_log', 'MESSAGE_LEVEL', 'int', 10, 0, NULL, 1),
(835, 'exception_log', 'MSG_ID', 'int', 10, 0, NULL, 1),
(836, 'exception_log', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(837, 'exception_log', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(838, 'exception_message_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(839, 'exception_message_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(840, 'exception_message_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(841, 'exception_message_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(842, 'exception_message_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(843, 'exception_message_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(844, 'exception_message_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(845, 'exception_message_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(846, 'exception_message_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(847, 'exception_message_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(848, 'exception_message_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(849, 'exception_message_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(850, 'exe_mngmnt_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(851, 'exe_mngmnt_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(852, 'exe_mngmnt_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(853, 'exe_mngmnt_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(854, 'exe_mngmnt_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(855, 'exe_mngmnt_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(856, 'exe_mngmnt_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(857, 'exe_mngmnt_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(858, 'exe_mngmnt_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(859, 'exe_mngmnt_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(860, 'exe_mngmnt_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(861, 'exe_mngmnt_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(862, 'exe_mngmnt_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(863, 'feature_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(864, 'feature_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(865, 'feature_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(866, 'feature_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(867, 'feature_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(868, 'feature_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(869, 'feature_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(870, 'feature_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(871, 'feature_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(872, 'feature_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(873, 'feature_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(874, 'feature_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(875, 'feature_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(876, 'form_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(877, 'form_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(878, 'form_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(879, 'form_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(880, 'form_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(881, 'form_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(882, 'form_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(883, 'form_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(884, 'form_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(885, 'form_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(886, 'form_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(887, 'form_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(888, 'gender_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(889, 'gender_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(890, 'gender_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(891, 'gender_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(892, 'gender_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(893, 'gender_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(894, 'gender_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(895, 'gender_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(896, 'gender_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(897, 'gender_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(898, 'gender_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(899, 'gender_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(900, 'gender_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(901, 'geo_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(902, 'geo_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(903, 'geo_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(904, 'geo_hier_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(905, 'geo_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(906, 'geo_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(907, 'geo_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(908, 'geo_hier_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(909, 'geo_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(910, 'geo_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(911, 'geo_hier_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(912, 'geo_hier_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(913, 'geo_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(914, 'global_setting_item_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(915, 'global_setting_item_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(916, 'global_setting_item_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(917, 'global_setting_item_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(918, 'global_setting_item_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(919, 'global_setting_item_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(920, 'global_setting_item_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(921, 'global_setting_item_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(922, 'global_setting_item_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(923, 'global_setting_item_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(924, 'global_setting_item_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(925, 'global_setting_item_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(926, 'group_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(927, 'group_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(928, 'group_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(929, 'group_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(930, 'group_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(931, 'group_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(932, 'group_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(933, 'group_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(934, 'group_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(935, 'group_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(936, 'group_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(937, 'group_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(938, 'group_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(939, 'group_role', 'GRP_ROLE_ID', 'int', 10, 0, NULL, 1),
(940, 'group_role', 'ROLE_ID', 'int', 10, 0, NULL, 1),
(941, 'group_role', 'USER_GRP_ID', 'int', 10, 0, NULL, 1),
(942, 'group_role', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(943, 'group_role', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(944, 'group_role', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(945, 'group_role', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(946, 'gsdatavaluetype_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(947, 'gsdatavaluetype_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(948, 'gsdatavaluetype_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(949, 'gsdatavaluetype_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(950, 'gsdatavaluetype_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(951, 'gsdatavaluetype_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(952, 'gsdatavaluetype_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(953, 'gsdatavaluetype_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(954, 'gsdatavaluetype_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(955, 'gsdatavaluetype_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(956, 'gsdatavaluetype_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(957, 'gsdatavaluetype_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(958, 'hier_level_config', 'HIER_LEVEL_CONFIG_ID', 'int', 10, 0, NULL, 1),
(959, 'hier_level_config', 'HIER_TYPE_ID', 'int', 10, 0, NULL, 1),
(960, 'hier_level_config', 'HIER_CHILD_ENTITY_TYPE_ID', 'int', 10, 0, NULL, 1),
(961, 'hier_level_config', 'HIER_PARENT_ENTITY_TYPE_ID', 'int', 10, 0, NULL, 1),
(962, 'hier_level_config', 'LEVEL_SEQ', 'int', 10, 0, NULL, 1),
(963, 'hier_level_config', 'OA_ID', 'int', 10, 0, NULL, 1),
(964, 'hier_level_config', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(965, 'hier_level_config', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(966, 'hier_level_config', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(967, 'hier_level_config', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(968, 'hier_level_config', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(969, 'hier_level_config', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(970, 'hier_level_config', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(971, 'hier_level_config', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(972, 'hierarchy_type_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(973, 'hierarchy_type_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(974, 'hierarchy_type_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(975, 'hierarchy_type_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(976, 'hierarchy_type_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(977, 'hierarchy_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(978, 'hierarchy_type_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(979, 'hierarchy_type_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(980, 'hierarchy_type_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(981, 'hierarchy_type_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(982, 'hierarchy_type_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(983, 'hierarchy_type_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(984, 'hierarchy_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(985, 'hod_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(986, 'hod_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(987, 'hod_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(988, 'hod_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(989, 'hod_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(990, 'hod_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(991, 'hod_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(992, 'hod_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(993, 'hod_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(994, 'hod_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(995, 'hod_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(996, 'hod_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(997, 'hod_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(998, 'independent_mst', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(999, 'independent_mst', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1000, 'independent_mst', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1001, 'independent_mst', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1002, 'independent_mst', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1003, 'independent_mst', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1004, 'independent_mst', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1005, 'independent_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(1006, 'independent_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1007, 'independent_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1008, 'independent_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1009, 'independent_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1010, 'independent_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1011, 'inface_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1012, 'inface_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(1013, 'inface_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(1014, 'inface_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(1015, 'inface_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(1016, 'inface_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1017, 'inface_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1018, 'inface_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1019, 'inface_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1020, 'inface_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1021, 'inface_obj_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1022, 'inface_obj_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1023, 'location_mst', 'LOC_ID', 'int', 10, 0, NULL, 1),
(1024, 'location_mst', 'LOC_CODE', 'varchar', 5, NULL, NULL, 1),
(1025, 'location_mst', 'LOC_NAME', 'varchar', 40, NULL, NULL, 1),
(1026, 'location_mst', 'LOC_TYPE_ID', 'int', 10, 0, NULL, 1),
(1027, 'location_mst', 'LOC_DIAL_CD', 'varchar', 5, NULL, NULL, 1),
(1028, 'location_mst', 'LOC_TIMEZONE_CD', 'int', 10, 0, NULL, 1),
(1029, 'location_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(1030, 'location_mst', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(1031, 'location_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(1032, 'location_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(1033, 'location_mst', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(1034, 'location_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(1035, 'location_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1036, 'location_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1037, 'location_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1038, 'location_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1039, 'location_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1040, 'location_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1041, 'location_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1042, 'location_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1043, 'location_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1044, 'location_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1045, 'location_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1046, 'location_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1047, 'location_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1048, 'mail_type_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1049, 'mail_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1050, 'mail_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1051, 'mail_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1052, 'mail_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1053, 'mail_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1054, 'mail_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1055, 'mail_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1056, 'mail_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1057, 'mail_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1058, 'mail_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1059, 'mail_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1060, 'mail_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1061, 'manager_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1062, 'manager_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1063, 'manager_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1064, 'manager_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1065, 'manager_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1066, 'manager_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1067, 'manager_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1068, 'manager_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1069, 'manager_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1070, 'manager_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1071, 'manager_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1072, 'manager_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1073, 'manager_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1074, 'marrital_status_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1075, 'marrital_status_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1076, 'marrital_status_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1077, 'marrital_status_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1078, 'marrital_status_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1079, 'marrital_status_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1080, 'marrital_status_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1081, 'marrital_status_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1082, 'marrital_status_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1083, 'marrital_status_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1084, 'marrital_status_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1085, 'marrital_status_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1086, 'marrital_status_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1087, 'menu_hier_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1088, 'menu_hier_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1089, 'menu_hier_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1090, 'menu_hier_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1091, 'menu_hier_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1092, 'menu_hier_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1093, 'menu_hier_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1094, 'menu_hier_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1095, 'menu_hier_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1096, 'menu_hier_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1097, 'menu_hier_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1098, 'menu_hier_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1099, 'menu_hier_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1100, 'menu_item_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1101, 'menu_item_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1102, 'menu_item_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1103, 'menu_item_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1104, 'menu_item_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1105, 'menu_item_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1106, 'menu_item_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1107, 'menu_item_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1108, 'menu_item_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1109, 'menu_item_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1110, 'menu_item_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1111, 'menu_item_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1112, 'message_mst', 'MSG_ID', 'int', 10, 0, NULL, 1),
(1113, 'message_mst', 'SYSTEM_MSG_ID', 'int', 10, 0, NULL, 1),
(1114, 'message_mst', 'MSG_SHORT_TEXT', 'varchar', 50, NULL, NULL, 1),
(1115, 'message_mst', 'MSG_LONG_TEXT', 'varchar', 250, NULL, NULL, 1),
(1116, 'message_mst', 'MSG_TYPE_ID', 'int', 10, 0, NULL, 1),
(1117, 'message_mst', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1118, 'message_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1119, 'message_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1120, 'message_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1121, 'message_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1122, 'mngt_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1123, 'mngt_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1124, 'mngt_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1125, 'mngt_hier_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1126, 'mngt_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1127, 'mngt_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1128, 'mngt_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1129, 'mngt_hier_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1130, 'mngt_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1131, 'mngt_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1132, 'mngt_hier_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1133, 'mngt_hier_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1134, 'mngt_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1135, 'model_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1136, 'model_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1137, 'model_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1138, 'model_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1139, 'model_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1140, 'model_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1141, 'model_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1142, 'model_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1143, 'model_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1144, 'model_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1145, 'model_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1146, 'model_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1147, 'module_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1148, 'module_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1149, 'module_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1150, 'module_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1151, 'module_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1152, 'module_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1153, 'module_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1154, 'module_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1155, 'module_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1156, 'module_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1157, 'module_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1158, 'module_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1159, 'module_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1160, 'nationality_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1161, 'nationality_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1162, 'nationality_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1163, 'nationality_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1164, 'nationality_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1165, 'nationality_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1166, 'nationality_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1167, 'nationality_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1168, 'nationality_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1169, 'nationality_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1170, 'nationality_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1171, 'nationality_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1172, 'nationality_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1173, 'non_personal_contact_type_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1174, 'non_personal_contact_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1175, 'non_personal_contact_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1176, 'non_personal_contact_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1177, 'non_personal_contact_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1178, 'non_personal_contact_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1179, 'non_personal_contact_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1180, 'non_personal_contact_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1181, 'non_personal_contact_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1182, 'non_personal_contact_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1183, 'non_personal_contact_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1184, 'non_personal_contact_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1185, 'non_personal_contact_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1186, 'oa_brand_settings', 'OAB_SETTING_ID', 'int', 10, 0, NULL, 1),
(1187, 'oa_brand_settings', 'OABS_ATTRBUTE_ID', 'int', 10, 0, NULL, 1),
(1188, 'oa_brand_settings', 'OABS_SETTING_VALUE', 'varchar', 40, NULL, NULL, 1),
(1189, 'oa_brand_settings', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1190, 'oa_brand_settings', 'REF_ID', 'int', 10, 0, NULL, 1),
(1191, 'oa_brand_settings', 'DESCRIPTION', 'varchar', 255, NULL, NULL, 1),
(1192, 'oa_brand_settings', 'VALIDATION', 'varchar', 255, NULL, NULL, 1),
(1193, 'oa_brand_settings', 'IS_ACTIVE', 'tinyint', 3, 0, NULL, 1),
(1194, 'oa_brand_settings', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1195, 'oa_brand_settings', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1196, 'oa_brand_settings', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1197, 'oa_brand_settings', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1198, 'oa_brands', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1199, 'oa_brands', 'OA_BRAND_CD', 'varchar', 5, NULL, NULL, 1),
(1200, 'oa_brands', 'OA_BRAND_NM', 'varchar', 40, NULL, NULL, 1),
(1201, 'oa_brands', 'OA_ID', 'int', 10, 0, NULL, 1),
(1202, 'oa_brands', 'REF_ID', 'int', 10, 0, NULL, 1),
(1203, 'oa_brands', 'OA_BRAND_LOGO', 'varchar', 100, NULL, NULL, 1),
(1204, 'oa_brands', 'OA_BRAND_INV_TMPLT', 'varchar', 100, NULL, NULL, 1),
(1205, 'oa_brands', 'IS_ACTIVE', 'tinyint', 3, 0, NULL, 1),
(1206, 'oa_brands', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(1207, 'oa_brands', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1208, 'oa_brands', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1209, 'oa_brands', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1210, 'oa_brands', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1211, 'oa_contact_add_phoneno', 'OA_CNTCT_ADD_PHONENO_ID', 'int', 10, 0, NULL, 1),
(1212, 'oa_contact_add_phoneno', 'CNTCT_ADD_PHONENO_ID', 'int', 10, 0, NULL, 1),
(1213, 'oa_contact_add_phoneno', 'OA_ID', 'int', 10, 0, NULL, 1),
(1214, 'oa_contact_add_phoneno', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1215, 'oa_contact_add_phoneno', 'IS_PRIMARY_TELNO', 'tinyint', 3, 0, NULL, 1),
(1216, 'oa_contact_add_phoneno', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1217, 'oa_contact_add_phoneno', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1218, 'oa_contact_add_phoneno', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1219, 'oa_contact_add_phoneno', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1220, 'oa_contact_address', 'OA_CNTCT_ADD_ID', 'int', 10, 0, NULL, 1),
(1221, 'oa_contact_address', 'CNTCT_ADD_ID', 'int', 10, 0, NULL, 1),
(1222, 'oa_contact_address', 'OA_ID', 'int', 10, 0, NULL, 1),
(1223, 'oa_contact_address', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1224, 'oa_contact_address', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(1225, 'oa_contact_address', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1226, 'oa_contact_address', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1227, 'oa_contact_address', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1228, 'oa_contact_address', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1229, 'oa_contact_emails', 'OA_CNTCT_EML_ID', 'int', 10, 0, NULL, 1),
(1230, 'oa_contact_emails', 'CNTCT_EML_ID', 'int', 10, 0, NULL, 1),
(1231, 'oa_contact_emails', 'OA_ID', 'int', 10, 0, NULL, 1),
(1232, 'oa_contact_emails', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1233, 'oa_contact_emails', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(1234, 'oa_contact_emails', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1235, 'oa_contact_emails', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1236, 'oa_contact_emails', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1237, 'oa_contact_emails', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1238, 'oa_contact_nationality', 'OA_CNTCT_NATIONALITY_ID', 'int', 10, 0, NULL, 1),
(1239, 'oa_contact_nationality', 'CNTCT_NATIONALITY_ID', 'int', 10, 0, NULL, 1),
(1240, 'oa_contact_nationality', 'OA_ID', 'int', 10, 0, NULL, 1),
(1241, 'oa_contact_nationality', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1242, 'oa_contact_nationality', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1243, 'oa_contact_nationality', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1244, 'oa_contact_nationality', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1245, 'oa_contact_nationality', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1246, 'oa_contact_nationality', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1247, 'oa_contact_phones', 'OA_CNTCT_PHONE_ID', 'int', 10, 0, NULL, 1),
(1248, 'oa_contact_phones', 'CNTCT_PHONE_ID', 'int', 10, 0, NULL, 1),
(1249, 'oa_contact_phones', 'OA_ID', 'int', 10, 0, NULL, 1),
(1250, 'oa_contact_phones', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1251, 'oa_contact_phones', 'IS_PRIMARY', 'tinyint', 3, 0, NULL, 1),
(1252, 'oa_contact_phones', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1253, 'oa_contact_phones', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1254, 'oa_contact_phones', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1255, 'oa_contact_phones', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1256, 'oa_contacts', 'OA_CNTCTS_ID', 'int', 10, 0, NULL, 1),
(1257, 'oa_contacts', 'OA_CNTCT_RELTYPE_ID', 'int', 10, 0, NULL, 1),
(1258, 'oa_contacts', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(1259, 'oa_contacts', 'NON_PRSNL', 'tinyint', 3, 0, NULL, 1),
(1260, 'oa_contacts', 'NON_PRSNL_CNTCT_TYP', 'int', 10, 0, NULL, 1),
(1261, 'oa_contacts', 'OA_ID', 'int', 10, 0, NULL, 1),
(1262, 'oa_contacts', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1263, 'oa_contacts', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1264, 'oa_contacts', 'IS_ACTIVE', 'tinyint', 3, 0, NULL, 1),
(1265, 'oa_contacts', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1266, 'oa_contacts', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1267, 'oa_contacts', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1268, 'oa_contacts', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1269, 'obj_attrbt_previleges', 'OBJ_ATTRBT_PREVILEGES_ID', 'int', 10, 0, NULL, 1),
(1270, 'obj_attrbt_previleges', 'OBJ_ID', 'int', 10, 0, NULL, 1),
(1271, 'obj_attrbt_previleges', 'OBJ_ATTRBT_ID', 'int', 10, 0, NULL, 1),
(1272, 'obj_attrbt_previleges', 'OA_ID', 'int', 10, 0, NULL, 1),
(1273, 'obj_attrbt_previleges', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1274, 'obj_attrbt_previleges', 'USER_ID', 'int', 10, 0, NULL, 1),
(1275, 'obj_attrbt_previleges', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1276, 'obj_attrbt_previleges', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1277, 'obj_attrbt_previleges', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1278, 'obj_attrbt_previleges', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1279, 'obj_layer_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1280, 'obj_layer_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(1281, 'obj_layer_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(1282, 'obj_layer_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(1283, 'obj_layer_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(1284, 'obj_layer_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1285, 'obj_layer_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1286, 'obj_layer_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1287, 'obj_layer_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1288, 'obj_layer_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1289, 'obj_layer_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1290, 'obj_layer_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1291, 'org_accounts', 'OA_ID', 'int', 10, 0, NULL, 1),
(1292, 'org_accounts', 'OA_CD', 'varchar', 5, NULL, NULL, 1),
(1293, 'org_accounts', 'OA_NM', 'varchar', 40, NULL, NULL, 1),
(1294, 'org_accounts', 'OA_EMAIL', 'varchar', 40, NULL, NULL, 1),
(1295, 'org_accounts', 'OA_WEB_DOMAIN', 'varchar', 40, NULL, NULL, 1),
(1296, 'org_accounts', 'OA_CONTACT_NO', 'varchar', 40, NULL, NULL, 1),
(1297, 'org_accounts', 'OA_STATUS_ID', 'int', 10, 0, NULL, 1),
(1298, 'org_accounts', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1299, 'org_accounts', 'UPDATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1300, 'org_accounts', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1301, 'org_accounts', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1302, 'orgacct_settings_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1303, 'orgacct_settings_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1304, 'orgacct_settings_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1305, 'orgacct_settings_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1306, 'orgacct_settings_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1307, 'orgacct_settings_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1308, 'orgacct_settings_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1309, 'orgacct_settings_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1310, 'orgacct_settings_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1311, 'orgacct_settings_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1312, 'orgacct_settings_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1313, 'orgacct_settings_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1314, 'permission_dtl', 'PERMISSIONS_DTL_ID', 'int', 10, 0, NULL, 1),
(1315, 'permission_dtl', 'PERMISSIONS_REF_TYPE_ID', 'int', 10, 0, NULL, 1),
(1316, 'permission_dtl', 'PERMISSIONS_REF_ID', 'int', 10, 0, NULL, 1),
(1317, 'permission_dtl', 'PERMISSIONS_ID', 'int', 10, 0, NULL, 1),
(1318, 'permission_dtl', 'OBJ_ATTRBT_PREVILEGES_ID', 'int', 10, 0, NULL, 1),
(1319, 'permission_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1320, 'permission_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1321, 'permission_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1322, 'permission_dtl', 'UPDATED_ON', 'datetime', 0, 0, 0, 0),
(1323, 'phone_nbr_mst', 'PHONE_NBR_ID', 'int', 10, 0, NULL, 1),
(1324, 'phone_nbr_mst', 'PHONE_NBR', 'varchar', 14, NULL, NULL, 1),
(1325, 'phone_nbr_mst', 'PHONE_NBR_TYPE_ID', 'int', 10, 0, NULL, 1),
(1326, 'phone_nbr_mst', 'PHONE_COUNTRY_CD', 'varchar', 5, NULL, NULL, 1),
(1327, 'phone_nbr_mst', 'PHONE_AREA_CD', 'varchar', 5, NULL, NULL, 1),
(1328, 'phone_nbr_mst', 'PHONE_EXCHANGE_NBR', 'varchar', 5, NULL, NULL, 1),
(1329, 'phone_nbr_mst', 'PHONE_LINE_NBR', 'varchar', 6, NULL, NULL, 1),
(1330, 'phone_nbr_mst', 'PHONE_EXTN', 'varchar', 5, NULL, NULL, 1),
(1331, 'phone_nbr_mst', 'IS_FAXNBR', 'tinyint', 3, 0, NULL, 1),
(1332, 'phone_nbr_mst', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1333, 'phone_nbr_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, NULL, 1),
(1334, 'phone_nbr_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1335, 'phone_nbr_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1336, 'phone_nbr_mst', 'CREATED_ON', 'timestamp', 0, NULL, NULL, 1),
(1337, 'phone_nbr_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1338, 'phone_number_type_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1339, 'phone_number_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1340, 'phone_number_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1341, 'phone_number_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1342, 'phone_number_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1343, 'phone_number_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1344, 'phone_number_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1345, 'phone_number_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1346, 'phone_number_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1347, 'phone_number_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1348, 'phone_number_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1349, 'phone_number_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1350, 'phone_number_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1351, 'postcode_mst', 'POSTCODE_ID', 'int', 10, 0, NULL, 1),
(1352, 'postcode_mst', 'POSTCODE_PREFIX', 'varchar', 4, NULL, NULL, 1),
(1353, 'postcode_mst', 'POSTCODE_SUFFIX', 'varchar', 4, NULL, NULL, 1),
(1354, 'postcode_mst', 'POSTCODE', 'varchar', 9, NULL, NULL, 1),
(1355, 'postcode_mst', 'COUNTRY_ID', 'int', 10, 0, NULL, 1),
(1356, 'postcode_mst', 'COUNTY_STATE_ID', 'int', 10, 0, NULL, 1),
(1357, 'postcode_mst', 'TIME_ZONE_ID', 'int', 10, 0, NULL, 1),
(1358, 'postcode_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(1359, 'postcode_mst', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(1360, 'postcode_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(1361, 'postcode_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(1362, 'postcode_mst', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(1363, 'postcode_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(1364, 'prcss_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1365, 'prcss_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(1366, 'prcss_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(1367, 'prcss_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(1368, 'prcss_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(1369, 'prcss_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1370, 'prcss_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1371, 'prcss_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1372, 'prcss_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1373, 'prcss_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1374, 'prcss_obj_type_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1375, 'prcss_obj_type_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1376, 'prsnttn_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1377, 'prsnttn_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, NULL, 1),
(1378, 'prsnttn_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, NULL, 1),
(1379, 'prsnttn_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, NULL, 1),
(1380, 'prsnttn_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, NULL, 1),
(1381, 'prsnttn_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1382, 'prsnttn_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1383, 'prsnttn_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1384, 'prsnttn_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1385, 'prsnttn_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1386, 'prsnttn_layer_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1387, 'prsnttn_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1388, 'race_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1389, 'race_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1390, 'race_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1391, 'race_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1392, 'race_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1393, 'race_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1394, 'race_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1395, 'race_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1396, 'race_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1397, 'race_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1398, 'race_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1399, 'race_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1400, 'race_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1401, 'relationship_dtl', 'REL_DET_ID', 'int', 10, 0, NULL, 1),
(1402, 'relationship_dtl', 'HIER_LEVEL_CONFIG_ID', 'int', 10, 0, NULL, 1),
(1403, 'relationship_dtl', 'CHILD_ID', 'int', 10, 0, NULL, 1),
(1404, 'relationship_dtl', 'PARENT_ID', 'int', 10, 0, NULL, 1),
(1405, 'relationship_dtl', 'HIER_TYPE_ID', 'int', 10, 0, NULL, 1),
(1406, 'relationship_dtl', 'HIER_CHILD_ENTITY_TYPE_ID', 'int', 10, 0, NULL, 1),
(1407, 'relationship_dtl', 'HIER_PARENT_ENTITY_TYPE_ID', 'int', 10, 0, NULL, 1),
(1408, 'relationship_dtl', 'LEVEL_SEQ', 'int', 10, 0, NULL, 1),
(1409, 'relationship_dtl', 'OA_ID', 'int', 10, 0, NULL, 1),
(1410, 'relationship_dtl', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1411, 'relationship_dtl', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1412, 'relationship_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1413, 'relationship_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1414, 'relationship_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1415, 'relationship_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1416, 'relegion_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1417, 'relegion_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1418, 'relegion_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1419, 'relegion_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1420, 'relegion_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1421, 'relegion_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1422, 'relegion_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1423, 'relegion_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1424, 'relegion_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1425, 'relegion_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1426, 'relegion_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1427, 'relegion_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1428, 'relegion_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1429, 'role_mst', 'ROLE_ID', 'int', 10, 0, NULL, 1),
(1430, 'role_mst', 'ROLE_NM', 'varchar', 40, NULL, NULL, 1),
(1431, 'role_mst', 'ROLE_DSCRPTN', 'varchar', 255, NULL, NULL, 1),
(1432, 'role_mst', 'DMN_ID', 'int', 10, 0, NULL, 1),
(1433, 'role_mst', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1434, 'role_mst', 'IS_ADMIN_ROLE', 'tinyint', 3, 0, NULL, 1),
(1435, 'role_mst', 'IS_ASSIGNABLE', 'tinyint', 3, 0, NULL, 1),
(1436, 'role_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1437, 'role_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1438, 'role_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1439, 'role_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1440, 'role_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1441, 'salutation_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1442, 'salutation_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1443, 'salutation_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1444, 'salutation_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1445, 'salutation_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1446, 'salutation_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1447, 'salutation_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1448, 'salutation_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1449, 'salutation_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1450, 'salutation_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1451, 'salutation_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1452, 'salutation_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1453, 'salutation_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1454, 'shift_mst', 'SHIFT_ID', 'int', 10, 0, NULL, 1),
(1455, 'shift_mst', 'NAME', 'varchar', 250, NULL, NULL, 1),
(1456, 'shift_mst', 'HOURS_PER_DAY', 'decimal', 4, 2, NULL, 1),
(1457, 'shift_mst', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1458, 'shift_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1459, 'shift_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1460, 'shift_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1461, 'shift_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1462, 'state_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1463, 'state_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1464, 'state_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1465, 'state_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1466, 'state_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1467, 'state_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1468, 'state_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1469, 'state_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1470, 'state_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1471, 'state_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1472, 'state_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1473, 'state_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1474, 'state_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1475, 'street_mst', 'STREET_ID', 'int', 10, 0, NULL, 1),
(1476, 'street_mst', 'STREET_NAME', 'varchar', 40, NULL, NULL, 1),
(1477, 'street_mst', 'LOCALITY', 'varchar', 40, NULL, NULL, 1),
(1478, 'street_mst', 'AREA', 'varchar', 40, NULL, NULL, 1),
(1479, 'street_mst', 'TOWN_ID', 'int', 10, 0, NULL, 1),
(1480, 'street_mst', 'CENSUS_BLOCK_ID', 'int', 10, 0, NULL, 1),
(1481, 'street_mst', 'CITY_ID', 'int', 10, 0, NULL, 1),
(1482, 'street_mst', 'TERRITORY_ID', 'int', 10, 0, NULL, 1),
(1483, 'street_mst', 'DISTRICT_ID', 'int', 10, 0, NULL, 1),
(1484, 'street_mst', 'POSTCODE_ID', 'int', 10, 0, NULL, 1),
(1485, 'street_mst', 'OA_ID', 'int', 10, 0, NULL, 1),
(1486, 'street_mst', 'COURIER_ROUTE_DESC', 'varchar', 100, NULL, NULL, 1),
(1487, 'street_mst', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(1488, 'street_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(1489, 'street_mst', 'UPDATEDBY', 'int', 10, 0, NULL, 1),
(1490, 'street_mst', 'CREATEDON', 'datetime', 0, NULL, NULL, 1),
(1491, 'street_mst', 'UPDATEDON', 'datetime', 0, NULL, NULL, 1),
(1492, 'subdept_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1493, 'subdept_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1494, 'subdept_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1495, 'subdept_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1496, 'subdept_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1497, 'subdept_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1498, 'subdept_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1499, 'subdept_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1500, 'subdept_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1501, 'subdept_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1502, 'subdept_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1503, 'subdept_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1504, 'subdept_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1505, 'sw_app_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1506, 'sw_app_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1507, 'sw_app_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1508, 'sw_app_hier_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1509, 'sw_app_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1510, 'sw_app_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1511, 'sw_app_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1512, 'sw_app_hier_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1513, 'sw_app_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1514, 'sw_app_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1515, 'sw_app_hier_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1516, 'sw_app_hier_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1517, 'sw_app_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1518, 'systempermisiontype_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1519, 'systempermisiontype_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1);
INSERT INTO `entity_obj_attrbt` (`OBJ_ATTRBT_ID`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_SCALE`, `IS_VISIBLE`) VALUES
(1520, 'systempermisiontype_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1521, 'systempermisiontype_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1522, 'systempermisiontype_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1523, 'systempermisiontype_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1524, 'systempermisiontype_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1525, 'systempermisiontype_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1526, 'systempermisiontype_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1527, 'systempermisiontype_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1528, 'systempermisiontype_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1529, 'systempermisiontype_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1530, 'systm_glssry', 'GLSSRY_ID', 'int', 10, 0, NULL, 1),
(1531, 'systm_glssry', 'GLSSRY_CD', 'varchar', 10, NULL, NULL, 1),
(1532, 'systm_glssry', 'GLSSRY_MNNG', 'varchar', 25, NULL, NULL, 1),
(1533, 'systm_glssry', 'GLSSRY_DSCRPTN', 'varchar', 100, NULL, NULL, 1),
(1534, 'systm_lst_dtl', 'TBL_NM', 'varchar', 50, NULL, NULL, 1),
(1535, 'systm_lst_dtl', 'LST_NMBR', 'int', 10, 0, NULL, 1),
(1536, 'theme_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1537, 'theme_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1538, 'theme_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1539, 'theme_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1540, 'theme_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1541, 'theme_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1542, 'theme_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1543, 'theme_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1544, 'theme_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1545, 'theme_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1546, 'theme_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1547, 'theme_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1548, 'theme_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1549, 'timezone_mst', 'TIME_ZONE_ID', 'int', 10, 0, NULL, 1),
(1550, 'timezone_mst', 'TIMEZONE', 'varchar', 4, NULL, NULL, 1),
(1551, 'timezone_mst', 'TIMEZONE_TYPE_ID', 'int', 10, 0, NULL, 1),
(1552, 'timezone_mst', 'ISDELETED', 'tinyint', 3, 0, NULL, 1),
(1553, 'timezone_mst', 'CREATEDBY', 'int', 10, 0, NULL, 1),
(1554, 'timezone_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1555, 'timezone_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1556, 'timezone_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1557, 'toolbar_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1558, 'toolbar_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1559, 'toolbar_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1560, 'toolbar_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1561, 'toolbar_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1562, 'toolbar_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1563, 'toolbar_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1564, 'toolbar_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1565, 'toolbar_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1566, 'toolbar_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1567, 'toolbar_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1568, 'toolbar_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1569, 'town_name_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1570, 'town_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1571, 'town_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1572, 'town_name_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1573, 'town_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1574, 'town_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1575, 'town_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1576, 'town_name_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1577, 'town_name_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1578, 'town_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1579, 'town_name_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1580, 'town_name_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1581, 'town_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1582, 'user_contact_type_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1583, 'user_contact_type_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1584, 'user_contact_type_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1585, 'user_contact_type_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1586, 'user_contact_type_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1587, 'user_contact_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1588, 'user_contact_type_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1589, 'user_contact_type_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1590, 'user_contact_type_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1591, 'user_contact_type_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1592, 'user_contact_type_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1593, 'user_contact_type_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1594, 'user_contacts', 'USER_CNTCT_ID', 'int', 10, 0, NULL, 1),
(1595, 'user_contacts', 'USER_ID', 'int', 10, 0, NULL, 1),
(1596, 'user_contacts', 'CNTCT_ID', 'int', 10, 0, NULL, 1),
(1597, 'user_contacts', 'USER_CNTCT_TYPE_ID', 'int', 10, 0, NULL, 1),
(1598, 'user_contacts', 'EXT_REF_NBR', 'varchar', 40, NULL, NULL, 1),
(1599, 'user_contacts', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1600, 'user_contacts', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1601, 'user_contacts', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1602, 'user_contacts', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1603, 'user_domain', 'DMN_ID', 'int', 10, 0, NULL, 1),
(1604, 'user_domain', 'DMN_NM', 'varchar', 40, NULL, NULL, 1),
(1605, 'user_domain', 'DSCRPTN', 'varchar', 100, NULL, NULL, 1),
(1606, 'user_domain', 'OA_ID', 'int', 10, 0, NULL, 1),
(1607, 'user_domain', 'OA_BRAND_ID', 'int', 10, 0, NULL, 1),
(1608, 'user_domain', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1609, 'user_domain', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1610, 'user_domain', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1611, 'user_domain', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1612, 'user_domain', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1613, 'user_group', 'USER_GRP_ID', 'int', 10, 0, NULL, 1),
(1614, 'user_group', 'USER_GRP_NM', 'varchar', 40, NULL, NULL, 1),
(1615, 'user_group', 'DMN_ID', 'int', 10, 0, NULL, 1),
(1616, 'user_group', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1617, 'user_group', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1618, 'user_group', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1619, 'user_group', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1620, 'user_group', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1621, 'user_group_dtl', 'USER_GRP_DTL_ID', 'int', 10, 0, NULL, 1),
(1622, 'user_group_dtl', 'USER_GRP_ID', 'int', 10, 0, NULL, 1),
(1623, 'user_group_dtl', 'USER_ID', 'int', 10, 0, NULL, 1),
(1624, 'user_group_dtl', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1625, 'user_group_dtl', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1626, 'user_group_dtl', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1627, 'user_group_dtl', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1628, 'user_mst', 'USER_ID', 'int', 10, 0, NULL, 1),
(1629, 'user_mst', 'USER_NAME', 'varchar', 40, NULL, NULL, 1),
(1630, 'user_mst', 'REG_EMAIL_ID', 'varchar', 40, NULL, NULL, 1),
(1631, 'user_mst', 'PASSWORD', 'varchar', 40, NULL, NULL, 1),
(1632, 'user_mst', 'USER_STATUS_ID', 'int', 10, 0, NULL, 1),
(1633, 'user_mst', 'EXT_REF_NBR', 'varchar', 40, NULL, NULL, 1),
(1634, 'user_mst', 'LAST_LOGIN_AT', 'datetime', 0, NULL, NULL, 1),
(1635, 'user_mst', 'DMN_ID', 'int', 10, 0, NULL, 1),
(1636, 'user_mst', 'ACTIVATION', 'varchar', 100, NULL, NULL, 1),
(1637, 'user_mst', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1638, 'user_mst', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1639, 'user_mst', 'IS_ADMIN', 'tinyint', 3, 0, NULL, 1),
(1640, 'user_mst', 'IS_ASSIGNABLE', 'tinyint', 3, 0, NULL, 1),
(1641, 'user_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, NULL, 1),
(1642, 'user_mst', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1643, 'user_mst', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1644, 'user_mst', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1645, 'user_mst', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1646, 'user_role', 'USER_ROLE_ID', 'int', 10, 0, NULL, 1),
(1647, 'user_role', 'ROLE_ID', 'int', 10, 0, NULL, 1),
(1648, 'user_role', 'USER_ID', 'int', 10, 0, NULL, 1),
(1649, 'user_role', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1650, 'user_role', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1651, 'user_role', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1652, 'user_role', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1653, 'user_status_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1654, 'user_status_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1655, 'user_status_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1656, 'user_status_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1657, 'user_status_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1658, 'user_status_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1659, 'user_status_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1660, 'user_status_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1661, 'user_status_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1662, 'user_status_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1663, 'user_status_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1664, 'user_status_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(1665, 'view_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, NULL, 1),
(1666, 'view_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, NULL, 1),
(1667, 'view_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, NULL, 1),
(1668, 'view_obj_mst_vw', 'TYP_ID', 'int', 10, 0, NULL, 1),
(1669, 'view_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, NULL, 1),
(1670, 'view_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, NULL, 1),
(1671, 'view_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, NULL, 1),
(1672, 'view_obj_mst_vw', 'OA_ID', 'int', 10, 0, NULL, 1),
(1673, 'view_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, NULL, 1),
(1674, 'view_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, NULL, 1),
(1675, 'view_obj_mst_vw', 'CREATED_ON', 'datetime', 0, NULL, NULL, 1),
(1676, 'view_obj_mst_vw', 'UPDATED_ON', 'datetime', 0, NULL, NULL, 1),
(2048, 'Test_obj2', 'test2', 'test_DT2', 11, 2, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `entity_obj_attrbt_dsply_dtl`
--

CREATE TABLE IF NOT EXISTS `entity_obj_attrbt_dsply_dtl` (
  `OBJ_ATTRBT_DSPLY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object attribute identifier',
  `OBJ_ATTRBT_ID` int(10) NOT NULL COMMENT 'Object attribute identifier',
  `OBJ_ATTRBT_DSPLY_NM` varchar(40) NOT NULL COMMENT 'Object display name',
  `OA_ID` int(10) NOT NULL COMMENT 'Organisation accounts identifier',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Organisation brand id viz. The company name',
  `USER_ID` int(10) NOT NULL COMMENT 'User identifier',
  PRIMARY KEY (`OBJ_ATTRBT_DSPLY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Entity storing all display name against an attribute' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `entity_obj_attrbt_mppng`
--

CREATE TABLE IF NOT EXISTS `entity_obj_attrbt_mppng` (
  `OBJ_ATTRBT_MPPNG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object attribute mapping identifier. This is the primary key of the table',
  `SRC_OBJ_NM` varchar(40) NOT NULL COMMENT 'Source object name',
  `SRC_OBJ_ATTRBT_NM` varchar(40) NOT NULL COMMENT 'Source object attribute name viz. Source column name',
  `TRG_OBJ_NM` varchar(40) NOT NULL COMMENT 'Target object name',
  `TRG_OBJ_ATTRBT_NM` varchar(40) NOT NULL COMMENT 'Target  object attribute name viz. Target column name',
  `OBJ_MPPNG_ID` int(10) NOT NULL COMMENT 'Object mapping identifier. This is the foreign key of the object mapping table',
  PRIMARY KEY (`OBJ_ATTRBT_MPPNG_ID`),
  KEY `FK_ENTITYOBJATTRBTMPPNG_OBJMPPNGID` (`OBJ_MPPNG_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Mapping the relationship between attributes of the two mapped objects' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `entity_obj_attrbt_mppng`
--

INSERT INTO `entity_obj_attrbt_mppng` (`OBJ_ATTRBT_MPPNG_ID`, `SRC_OBJ_NM`, `SRC_OBJ_ATTRBT_NM`, `TRG_OBJ_NM`, `TRG_OBJ_ATTRBT_NM`, `OBJ_MPPNG_ID`) VALUES
(3, '2', '3', '3', '4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `entity_obj_mppng`
--

CREATE TABLE IF NOT EXISTS `entity_obj_mppng` (
  `OBJ_MPPNG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object mapping identifier. This is the primary key of the table',
  `SRC_LYR_ID` int(10) NOT NULL COMMENT 'Source layer identifier',
  `SRC_OBJ_ID` int(10) NOT NULL COMMENT 'Source object identifier',
  `TRGT_LYR_ID` int(10) NOT NULL COMMENT 'Target layer identifier',
  `TRGT_OBJ_ID` int(10) NOT NULL COMMENT 'Target object identifier',
  PRIMARY KEY (`OBJ_MPPNG_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Mapping the relationship between objects' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `entity_obj_mppng`
--

INSERT INTO `entity_obj_mppng` (`OBJ_MPPNG_ID`, `SRC_LYR_ID`, `SRC_OBJ_ID`, `TRGT_LYR_ID`, `TRGT_OBJ_ID`) VALUES
(1, 36, 2, 36, 3);

-- --------------------------------------------------------

--
-- Table structure for table `entity_obj_tmp`
--

CREATE TABLE IF NOT EXISTS `entity_obj_tmp` (
  `TMP_OBJ_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object attribute identifier',
  `OBJ_TYP` varchar(4) DEFAULT NULL COMMENT 'Name of the object for which the attribute belong to',
  `OBJ_NM` varchar(40) DEFAULT NULL COMMENT 'Name of the attribute',
  `OBJ_ATTRBT_NM` varchar(40) DEFAULT NULL COMMENT 'Attribute data type',
  `OBJ_ATTRBT_DT_TYP` varchar(40) DEFAULT NULL COMMENT 'Size of the object in numbers',
  `OBJ_SZ` int(10) DEFAULT NULL COMMENT 'Precision of the object in number',
  `OBJ_PRCSN` int(10) DEFAULT NULL COMMENT 'Scale of the object in number',
  `OBJ_NW_RCRD_FLG` tinyint(1) DEFAULT NULL COMMENT 'New record flag',
  PRIMARY KEY (`TMP_OBJ_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Temporary entity to store all the columns and table info of a Schema' AUTO_INCREMENT=1679 ;

--
-- Dumping data for table `entity_obj_tmp`
--

INSERT INTO `entity_obj_tmp` (`TMP_OBJ_ID`, `OBJ_TYP`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_NW_RCRD_FLG`) VALUES
(2, 'TABL', 'address_mst', 'ADDRESS_ID', 'int', 10, 0, 1),
(3, 'TABL', 'address_mst', 'FLAT_NO', 'varchar', 10, NULL, 1),
(4, 'TABL', 'address_mst', 'HOUSE_NO', 'varchar', 10, NULL, 1),
(5, 'TABL', 'address_mst', 'HOUSE_NAME', 'varchar', 10, NULL, 1),
(6, 'TABL', 'address_mst', 'ADDRESS_LINE_1', 'varchar', 40, NULL, 1),
(7, 'TABL', 'address_mst', 'ADDRESS_LINE_2', 'varchar', 40, NULL, 1),
(8, 'TABL', 'address_mst', 'ADDRESS_LINE_3', 'varchar', 40, NULL, 1),
(9, 'TABL', 'address_mst', 'DWELLING_TYPE_ID', 'int', 10, 0, 1),
(10, 'TABL', 'address_mst', 'STREET_ID', 'int', 10, 0, 1),
(11, 'TABL', 'address_mst', 'OA_ID', 'int', 10, 0, 1),
(12, 'TABL', 'address_mst', 'CREATEDBY', 'int', 10, 0, 1),
(13, 'TABL', 'address_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(14, 'TABL', 'address_mst', 'CREATEDON', 'datetime', NULL, NULL, 1),
(15, 'TABL', 'address_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(16, 'TABL', 'appl_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(17, 'TABL', 'appl_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(18, 'TABL', 'appl_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(19, 'TABL', 'appl_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(20, 'TABL', 'appl_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(21, 'TABL', 'appl_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(22, 'TABL', 'appl_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(23, 'TABL', 'appl_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(24, 'TABL', 'appl_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(25, 'TABL', 'appl_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(26, 'TABL', 'appl_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(27, 'TABL', 'appl_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(28, 'TABL', 'appl_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(29, 'TABL', 'application_dtl', 'APP_DETAIL_ID', 'int', 10, 0, 1),
(30, 'TABL', 'application_dtl', 'APP_ID', 'int', 10, 0, 1),
(31, 'TABL', 'application_dtl', 'FUNCTION_ID', 'int', 10, 0, 1),
(32, 'TABL', 'application_dtl', 'EPIC_ID', 'int', 10, 0, 1),
(33, 'TABL', 'application_dtl', 'FEATURE_ID', 'int', 10, 0, 1),
(34, 'TABL', 'application_dtl', 'OPTIONAL_THEME_ID', 'int', 10, 0, 1),
(35, 'TABL', 'application_dtl', 'ENABLED', 'tinyint', 3, 0, 1),
(36, 'TABL', 'application_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(37, 'TABL', 'application_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(38, 'TABL', 'application_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(39, 'TABL', 'application_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(40, 'TABL', 'area_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(41, 'TABL', 'area_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(42, 'TABL', 'area_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(43, 'TABL', 'area_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(44, 'TABL', 'area_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(45, 'TABL', 'area_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(46, 'TABL', 'area_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(47, 'TABL', 'area_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(48, 'TABL', 'area_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(49, 'TABL', 'area_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(50, 'TABL', 'area_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(51, 'TABL', 'area_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(52, 'TABL', 'area_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(53, 'TABL', 'board_of_dirs_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(54, 'TABL', 'board_of_dirs_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(55, 'TABL', 'board_of_dirs_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(56, 'TABL', 'board_of_dirs_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(57, 'TABL', 'board_of_dirs_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(58, 'TABL', 'board_of_dirs_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(59, 'TABL', 'board_of_dirs_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(60, 'TABL', 'board_of_dirs_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(61, 'TABL', 'board_of_dirs_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(62, 'TABL', 'board_of_dirs_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(63, 'TABL', 'board_of_dirs_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(64, 'TABL', 'board_of_dirs_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(65, 'TABL', 'board_of_dirs_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(66, 'TABL', 'buss_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(67, 'TABL', 'buss_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(68, 'TABL', 'buss_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(69, 'TABL', 'buss_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(70, 'TABL', 'buss_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(71, 'TABL', 'buss_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(72, 'TABL', 'buss_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(73, 'TABL', 'buss_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(74, 'TABL', 'buss_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(75, 'TABL', 'buss_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(76, 'TABL', 'buss_layer_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(77, 'TABL', 'buss_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(78, 'TABL', 'cast_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(79, 'TABL', 'cast_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(80, 'TABL', 'cast_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(81, 'TABL', 'cast_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(82, 'TABL', 'cast_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(83, 'TABL', 'cast_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(84, 'TABL', 'cast_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(85, 'TABL', 'cast_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(86, 'TABL', 'cast_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(87, 'TABL', 'cast_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(88, 'TABL', 'cast_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(89, 'TABL', 'cast_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(90, 'TABL', 'cast_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(91, 'TABL', 'city_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(92, 'TABL', 'city_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(93, 'TABL', 'city_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(94, 'TABL', 'city_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(95, 'TABL', 'city_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(96, 'TABL', 'city_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(97, 'TABL', 'city_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(98, 'TABL', 'city_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(99, 'TABL', 'city_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(100, 'TABL', 'city_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(101, 'TABL', 'city_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(102, 'TABL', 'city_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(103, 'TABL', 'city_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(104, 'TABL', 'cntrllr_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(105, 'TABL', 'cntrllr_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(106, 'TABL', 'cntrllr_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(107, 'TABL', 'cntrllr_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(108, 'TABL', 'cntrllr_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(109, 'TABL', 'cntrllr_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(110, 'TABL', 'cntrllr_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(111, 'TABL', 'cntrllr_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(112, 'TABL', 'cntrllr_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(113, 'TABL', 'cntrllr_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(114, 'TABL', 'cntrllr_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(115, 'TABL', 'cntrllr_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(116, 'TABL', 'common_type', 'TYP_ID', 'int', 10, 0, 1),
(117, 'TABL', 'common_type', 'TYP_CD', 'varchar', 5, NULL, 1),
(118, 'TABL', 'common_type', 'TYP_NM', 'varchar', 40, NULL, 1),
(119, 'TABL', 'common_type', 'VIEW_NM', 'varchar', 40, NULL, 1),
(120, 'TABL', 'common_type', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(121, 'TABL', 'common_type', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(122, 'TABL', 'common_type', 'IS_DELETED', 'tinyint', 3, 0, 1),
(123, 'TABL', 'common_type', 'OA_ID', 'int', 10, 0, 1),
(124, 'TABL', 'common_type', 'CREATED_BY', 'int', 10, 0, 1),
(125, 'TABL', 'common_type', 'UPDATED_BY', 'int', 10, 0, 1),
(126, 'TABL', 'common_type', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(127, 'TABL', 'common_type', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(128, 'TABL', 'common_type', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(129, 'TABL', 'comp_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(130, 'TABL', 'comp_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(131, 'TABL', 'comp_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(132, 'TABL', 'comp_hier_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(133, 'TABL', 'comp_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(134, 'TABL', 'comp_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(135, 'TABL', 'comp_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(136, 'TABL', 'comp_hier_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(137, 'TABL', 'comp_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(138, 'TABL', 'comp_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(139, 'TABL', 'comp_hier_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(140, 'TABL', 'comp_hier_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(141, 'TABL', 'comp_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(142, 'TABL', 'company_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(143, 'TABL', 'company_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(144, 'TABL', 'company_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(145, 'TABL', 'company_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(146, 'TABL', 'company_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(147, 'TABL', 'company_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(148, 'TABL', 'company_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(149, 'TABL', 'company_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(150, 'TABL', 'company_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(151, 'TABL', 'company_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(152, 'TABL', 'company_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(153, 'TABL', 'company_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(154, 'TABL', 'company_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(155, 'TABL', 'config_mapping_dtl', 'CNFG_MPPNG_DTL_ID', 'int', 10, 0, 1),
(156, 'TABL', 'config_mapping_dtl', 'SRC_ENTTY_ID', 'int', 10, 0, 1),
(157, 'TABL', 'config_mapping_dtl', 'TRGT_ENTTY_ID', 'int', 10, 0, 1),
(158, 'TABL', 'config_mapping_dtl', 'CNFG_MPPNG_TYP_ID', 'int', 10, 0, 1),
(159, 'TABL', 'config_mapping_dtl', 'OA_BRAND_ID', 'int', 10, 0, 1),
(160, 'TABL', 'config_mapping_dtl', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(161, 'TABL', 'config_mapping_dtl', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(162, 'TABL', 'config_mapping_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(163, 'TABL', 'config_mapping_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(164, 'TABL', 'contact_add_phoneno', 'CNTCT_ADD_PHONENO_ID', 'int', 10, 0, 1),
(165, 'TABL', 'contact_add_phoneno', 'CNTCT_ADD_ID', 'int', 10, 0, 1),
(166, 'TABL', 'contact_add_phoneno', 'CNTCT_NBR_ID', 'int', 10, 0, 1),
(167, 'TABL', 'contact_add_phoneno', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(168, 'TABL', 'contact_add_phoneno', 'IS_PRIMARY_TELNO', 'tinyint', 3, 0, 1),
(169, 'TABL', 'contact_add_phoneno', 'CREATED_BY', 'int', 10, 0, 1),
(170, 'TABL', 'contact_add_phoneno', 'UPDATED_BY', 'int', 10, 0, 1),
(171, 'TABL', 'contact_add_phoneno', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(172, 'TABL', 'contact_add_phoneno', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(173, 'TABL', 'contact_address', 'CNTCT_ADD_ID', 'int', 10, 0, 1),
(174, 'TABL', 'contact_address', 'CNTCT_ID', 'int', 10, 0, 1),
(175, 'TABL', 'contact_address', 'CNTCT_ADD_TYPE_ID', 'int', 10, 0, 1),
(176, 'TABL', 'contact_address', 'ADD_ID', 'int', 10, 0, 1),
(177, 'TABL', 'contact_address', 'CNTCT_ADD_START_DATE', 'datetime', NULL, NULL, 1),
(178, 'TABL', 'contact_address', 'CNTCT_ADD_END_DATE', 'datetime', NULL, NULL, 1),
(179, 'TABL', 'contact_address', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(180, 'TABL', 'contact_address', 'IS_CURRENT_ADD', 'tinyint', 3, 0, 1),
(181, 'TABL', 'contact_address', 'IS_PRIMARY_ADD', 'tinyint', 3, 0, 1),
(182, 'TABL', 'contact_address', 'CREATED_BY', 'int', 10, 0, 1),
(183, 'TABL', 'contact_address', 'UPDATED_BY', 'int', 10, 0, 1),
(184, 'TABL', 'contact_address', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(185, 'TABL', 'contact_address', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(186, 'TABL', 'contact_address_type_vw', 'MSTR_ID', 'int', 10, 0, 1),
(187, 'TABL', 'contact_address_type_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(188, 'TABL', 'contact_address_type_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(189, 'TABL', 'contact_address_type_vw', 'TYP_ID', 'int', 10, 0, 1),
(190, 'TABL', 'contact_address_type_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(191, 'TABL', 'contact_address_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(192, 'TABL', 'contact_address_type_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(193, 'TABL', 'contact_address_type_vw', 'OA_ID', 'int', 10, 0, 1),
(194, 'TABL', 'contact_address_type_vw', 'CREATED_BY', 'int', 10, 0, 1),
(195, 'TABL', 'contact_address_type_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(196, 'TABL', 'contact_address_type_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(197, 'TABL', 'contact_address_type_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(198, 'TABL', 'contact_address_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(199, 'TABL', 'contact_emails', 'CNTCT_EML_ID', 'int', 10, 0, 1),
(200, 'TABL', 'contact_emails', 'CNTCT_ID', 'int', 10, 0, 1),
(201, 'TABL', 'contact_emails', 'EMAIL_ADD_ID', 'int', 10, 0, 1),
(202, 'TABL', 'contact_emails', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(203, 'TABL', 'contact_emails', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(204, 'TABL', 'contact_emails', 'CREATED_BY', 'int', 10, 0, 1),
(205, 'TABL', 'contact_emails', 'UPDATED_BY', 'int', 10, 0, 1),
(206, 'TABL', 'contact_emails', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(207, 'TABL', 'contact_emails', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(208, 'TABL', 'contact_mst', 'CNTCT_ID', 'int', 10, 0, 1),
(209, 'TABL', 'contact_mst', 'CNTCT_SALUTATION_ID', 'int', 10, 0, 1),
(210, 'TABL', 'contact_mst', 'CNTCT_FRST_NM', 'varchar', 40, NULL, 1),
(211, 'TABL', 'contact_mst', 'CNTCT_LST_NM', 'varchar', 40, NULL, 1),
(212, 'TABL', 'contact_mst', 'CNTCT_MDDL_NM', 'varchar', 40, NULL, 1),
(213, 'TABL', 'contact_mst', 'CNTCT_OTHER_NM', 'varchar', 40, NULL, 1),
(214, 'TABL', 'contact_mst', 'CNTCT_PRFRD_NM', 'varchar', 40, NULL, 1),
(215, 'TABL', 'contact_mst', 'CNTCT_DOB', 'varchar', 40, NULL, 1),
(216, 'TABL', 'contact_mst', 'CNTCT_SMOKER', 'tinyint', 3, 0, 1),
(217, 'TABL', 'contact_mst', 'CNTCT_GENDER_ID', 'int', 10, 0, 1),
(218, 'TABL', 'contact_mst', 'MARRITAL_STATUS_ID', 'int', 10, 0, 1),
(219, 'TABL', 'contact_mst', 'CAST_ID', 'int', 10, 0, 1),
(220, 'TABL', 'contact_mst', 'RASE_ID', 'int', 10, 0, 1),
(221, 'TABL', 'contact_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(222, 'TABL', 'contact_mst', 'IS_DELETED', 'tinyint', 3, 0, 1),
(223, 'TABL', 'contact_mst', 'CREATED_BY', 'int', 10, 0, 1),
(224, 'TABL', 'contact_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(225, 'TABL', 'contact_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(226, 'TABL', 'contact_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(227, 'TABL', 'contact_nationality', 'CNTCT_NATIONALITY_ID', 'int', 10, 0, 1),
(228, 'TABL', 'contact_nationality', 'CNTCT_ID', 'int', 10, 0, 1),
(229, 'TABL', 'contact_nationality', 'NATIONALITY_ID', 'int', 10, 0, 1),
(230, 'TABL', 'contact_nationality', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(231, 'TABL', 'contact_nationality', 'IS_DELETED', 'tinyint', 3, 0, 1),
(232, 'TABL', 'contact_nationality', 'CREATED_BY', 'int', 10, 0, 1),
(233, 'TABL', 'contact_nationality', 'UPDATED_BY', 'int', 10, 0, 1),
(234, 'TABL', 'contact_nationality', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(235, 'TABL', 'contact_nationality', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(236, 'TABL', 'contact_phones', 'CNTCT_PHONE_ID', 'int', 10, 0, 1),
(237, 'TABL', 'contact_phones', 'CNTCT_ID', 'int', 10, 0, 1),
(238, 'TABL', 'contact_phones', 'PHONE_NBR_ID', 'int', 10, 0, 1),
(239, 'TABL', 'contact_phones', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(240, 'TABL', 'contact_phones', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(241, 'TABL', 'contact_phones', 'CREATED_BY', 'int', 10, 0, 1),
(242, 'TABL', 'contact_phones', 'UPDATED_BY', 'int', 10, 0, 1),
(243, 'TABL', 'contact_phones', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(244, 'TABL', 'contact_phones', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(245, 'TABL', 'contact_relation_type_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(246, 'TABL', 'contact_relation_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(247, 'TABL', 'contact_relation_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(248, 'TABL', 'contact_relation_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(249, 'TABL', 'contact_relation_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(250, 'TABL', 'contact_relation_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(251, 'TABL', 'contact_relation_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(252, 'TABL', 'contact_relation_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(253, 'TABL', 'contact_relation_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(254, 'TABL', 'contact_relation_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(255, 'TABL', 'contact_relation_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(256, 'TABL', 'contact_relation_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(257, 'TABL', 'contact_relation_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(258, 'TABL', 'continent_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(259, 'TABL', 'continent_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(260, 'TABL', 'continent_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(261, 'TABL', 'continent_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(262, 'TABL', 'continent_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(263, 'TABL', 'continent_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(264, 'TABL', 'continent_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(265, 'TABL', 'continent_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(266, 'TABL', 'continent_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(267, 'TABL', 'continent_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(268, 'TABL', 'continent_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(269, 'TABL', 'continent_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(270, 'TABL', 'continent_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(271, 'TABL', 'country_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(272, 'TABL', 'country_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(273, 'TABL', 'country_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(274, 'TABL', 'country_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(275, 'TABL', 'country_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(276, 'TABL', 'country_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(277, 'TABL', 'country_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(278, 'TABL', 'country_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(279, 'TABL', 'country_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(280, 'TABL', 'country_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(281, 'TABL', 'country_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(282, 'TABL', 'country_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(283, 'TABL', 'country_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(284, 'TABL', 'county_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(285, 'TABL', 'county_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(286, 'TABL', 'county_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(287, 'TABL', 'county_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(288, 'TABL', 'county_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(289, 'TABL', 'county_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(290, 'TABL', 'county_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(291, 'TABL', 'county_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(292, 'TABL', 'county_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(293, 'TABL', 'county_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(294, 'TABL', 'county_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(295, 'TABL', 'county_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(296, 'TABL', 'county_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(297, 'TABL', 'currency_mst', 'CURR_ID', 'int', 10, 0, 1),
(298, 'TABL', 'currency_mst', 'CURR_CODE', 'varchar', 5, NULL, 1),
(299, 'TABL', 'currency_mst', 'CURR_NAME', 'varchar', 40, NULL, 1),
(300, 'TABL', 'currency_mst', 'CURR_SYMBOL', 'varchar', 5, NULL, 1),
(301, 'TABL', 'currency_mst', 'OA_ID', 'int', 10, 0, 1),
(302, 'TABL', 'currency_mst', 'COUNTRY_ID', 'int', 10, 0, 1),
(303, 'TABL', 'currency_mst', 'REF_NBR', 'varchar', 10, NULL, 1),
(304, 'TABL', 'currency_mst', 'CURR_COMMENTS', 'varchar', 255, NULL, 1),
(305, 'TABL', 'currency_mst', 'CREATEDBY', 'int', 10, 0, 1),
(306, 'TABL', 'currency_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(307, 'TABL', 'currency_mst', 'CREATEDON', 'datetime', NULL, NULL, 1),
(308, 'TABL', 'currency_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(309, 'TABL', 'currency_rate', 'CURR_RATE_ID', 'int', 10, 0, 1),
(310, 'TABL', 'currency_rate', 'SRC_CURR_ID', 'int', 10, 0, 1),
(311, 'TABL', 'currency_rate', 'TRG_CURR_ID', 'int', 10, 0, 1),
(312, 'TABL', 'currency_rate', 'EX_RATE', 'decimal', 10, 5, 1),
(313, 'TABL', 'currency_rate', 'EFF_FROM', 'datetime', NULL, NULL, 1),
(314, 'TABL', 'currency_rate', 'EFF_TO', 'datetime', NULL, NULL, 1),
(315, 'TABL', 'currency_rate', 'CREATEDBY', 'int', 10, 0, 1),
(316, 'TABL', 'currency_rate', 'UPDATEDBY', 'int', 10, 0, 1),
(317, 'TABL', 'currency_rate', 'CREATEDON', 'datetime', NULL, NULL, 1),
(318, 'TABL', 'currency_rate', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(319, 'TABL', 'data_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(320, 'TABL', 'data_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(321, 'TABL', 'data_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(322, 'TABL', 'data_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(323, 'TABL', 'data_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(324, 'TABL', 'data_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(325, 'TABL', 'data_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(326, 'TABL', 'data_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(327, 'TABL', 'data_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(328, 'TABL', 'data_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(329, 'TABL', 'data_layer_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(330, 'TABL', 'data_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(331, 'TABL', 'db_funcations_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(332, 'TABL', 'db_funcations_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(333, 'TABL', 'db_funcations_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(334, 'TABL', 'db_funcations_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(335, 'TABL', 'db_funcations_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(336, 'TABL', 'db_funcations_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(337, 'TABL', 'db_funcations_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(338, 'TABL', 'db_funcations_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(339, 'TABL', 'db_funcations_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(340, 'TABL', 'db_funcations_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(341, 'TABL', 'db_funcations_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(342, 'TABL', 'db_funcations_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(343, 'TABL', 'db_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(344, 'TABL', 'db_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(345, 'TABL', 'db_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(346, 'TABL', 'db_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(347, 'TABL', 'db_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(348, 'TABL', 'db_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(349, 'TABL', 'db_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(350, 'TABL', 'db_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(351, 'TABL', 'db_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(352, 'TABL', 'db_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(353, 'TABL', 'db_obj_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(354, 'TABL', 'db_obj_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(355, 'TABL', 'db_procs_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(356, 'TABL', 'db_procs_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(357, 'TABL', 'db_procs_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(358, 'TABL', 'db_procs_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(359, 'TABL', 'db_procs_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(360, 'TABL', 'db_procs_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(361, 'TABL', 'db_procs_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(362, 'TABL', 'db_procs_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(363, 'TABL', 'db_procs_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(364, 'TABL', 'db_procs_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(365, 'TABL', 'db_procs_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(366, 'TABL', 'db_procs_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(367, 'TABL', 'db_tables_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(368, 'TABL', 'db_tables_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(369, 'TABL', 'db_tables_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(370, 'TABL', 'db_tables_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(371, 'TABL', 'db_tables_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(372, 'TABL', 'db_tables_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(373, 'TABL', 'db_tables_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(374, 'TABL', 'db_tables_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(375, 'TABL', 'db_tables_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(376, 'TABL', 'db_tables_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(377, 'TABL', 'db_tables_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(378, 'TABL', 'db_tables_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(379, 'TABL', 'db_triggers_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(380, 'TABL', 'db_triggers_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(381, 'TABL', 'db_triggers_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(382, 'TABL', 'db_triggers_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(383, 'TABL', 'db_triggers_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(384, 'TABL', 'db_triggers_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(385, 'TABL', 'db_triggers_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(386, 'TABL', 'db_triggers_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(387, 'TABL', 'db_triggers_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(388, 'TABL', 'db_triggers_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(389, 'TABL', 'db_triggers_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(390, 'TABL', 'db_triggers_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(391, 'TABL', 'db_views_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(392, 'TABL', 'db_views_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(393, 'TABL', 'db_views_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(394, 'TABL', 'db_views_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(395, 'TABL', 'db_views_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(396, 'TABL', 'db_views_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(397, 'TABL', 'db_views_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(398, 'TABL', 'db_views_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(399, 'TABL', 'db_views_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(400, 'TABL', 'db_views_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(401, 'TABL', 'db_views_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(402, 'TABL', 'db_views_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(403, 'TABL', 'dependent_dtl', 'DEPENDENT_DTL_ID', 'int', 10, 0, 1),
(404, 'TABL', 'dependent_dtl', 'EMP_ID', 'int', 10, 0, 1),
(405, 'TABL', 'dependent_dtl', 'OA_DEP_CNTCTS_ID', 'int', 10, 0, 1),
(406, 'TABL', 'dependent_dtl', 'RELATION_TYPE_ID', 'int', 10, 0, 1),
(407, 'TABL', 'dependent_dtl', 'REALTION_TYPE_NAME', 'varchar', 100, NULL, 1),
(408, 'TABL', 'dependent_dtl', 'DATE_OF_BIRTH', 'datetime', NULL, NULL, 1),
(409, 'TABL', 'dependent_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(410, 'TABL', 'dependent_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(411, 'TABL', 'dependent_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(412, 'TABL', 'dependent_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(413, 'TABL', 'dept_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(414, 'TABL', 'dept_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(415, 'TABL', 'dept_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(416, 'TABL', 'dept_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(417, 'TABL', 'dept_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(418, 'TABL', 'dept_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(419, 'TABL', 'dept_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(420, 'TABL', 'dept_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(421, 'TABL', 'dept_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(422, 'TABL', 'dept_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(423, 'TABL', 'dept_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(424, 'TABL', 'dept_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(425, 'TABL', 'dept_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(426, 'TABL', 'directors_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(427, 'TABL', 'directors_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(428, 'TABL', 'directors_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(429, 'TABL', 'directors_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(430, 'TABL', 'directors_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(431, 'TABL', 'directors_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(432, 'TABL', 'directors_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(433, 'TABL', 'directors_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(434, 'TABL', 'directors_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(435, 'TABL', 'directors_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(436, 'TABL', 'directors_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(437, 'TABL', 'directors_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(438, 'TABL', 'directors_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(439, 'TABL', 'district_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(440, 'TABL', 'district_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(441, 'TABL', 'district_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(442, 'TABL', 'district_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(443, 'TABL', 'district_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(444, 'TABL', 'district_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(445, 'TABL', 'district_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(446, 'TABL', 'district_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(447, 'TABL', 'district_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(448, 'TABL', 'district_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(449, 'TABL', 'district_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(450, 'TABL', 'district_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(451, 'TABL', 'district_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(452, 'TABL', 'division_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(453, 'TABL', 'division_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(454, 'TABL', 'division_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(455, 'TABL', 'division_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(456, 'TABL', 'division_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(457, 'TABL', 'division_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(458, 'TABL', 'division_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(459, 'TABL', 'division_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(460, 'TABL', 'division_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(461, 'TABL', 'division_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(462, 'TABL', 'division_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(463, 'TABL', 'division_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(464, 'TABL', 'division_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(465, 'TABL', 'email_account_dtl', 'EMAIL_ACCT_ID', 'int', 10, 0, 1),
(466, 'TABL', 'email_account_dtl', 'EMAIL_ADD_ID', 'int', 10, 0, 1),
(467, 'TABL', 'email_account_dtl', 'CONTACT_ID', 'int', 10, 0, 1),
(468, 'TABL', 'email_account_dtl', 'EMAIL_ACC_FNAME', 'varchar', 40, NULL, 1),
(469, 'TABL', 'email_account_dtl', 'EMAIL_ACC_LNAME', 'varchar', 40, NULL, 1),
(470, 'TABL', 'email_account_dtl', 'EMAIL_ACC_ADD_ID', 'int', 10, 0, 1),
(471, 'TABL', 'email_account_dtl', 'EMAIL_ACCT_USE_TYPE_ID', 'int', 10, 0, 1),
(472, 'TABL', 'email_account_dtl', 'ISDELETED', 'tinyint', 3, 0, 1),
(473, 'TABL', 'email_account_dtl', 'CREATEDBY', 'int', 10, 0, 1),
(474, 'TABL', 'email_account_dtl', 'UPDATEDBY', 'int', 10, 0, 1),
(475, 'TABL', 'email_account_dtl', 'CREATEDON', 'datetime', NULL, NULL, 1),
(476, 'TABL', 'email_account_dtl', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(477, 'TABL', 'email_account_use_type_vw', 'MSTR_ID', 'int', 10, 0, 1),
(478, 'TABL', 'email_account_use_type_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(479, 'TABL', 'email_account_use_type_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(480, 'TABL', 'email_account_use_type_vw', 'TYP_ID', 'int', 10, 0, 1),
(481, 'TABL', 'email_account_use_type_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(482, 'TABL', 'email_account_use_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(483, 'TABL', 'email_account_use_type_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(484, 'TABL', 'email_account_use_type_vw', 'OA_ID', 'int', 10, 0, 1),
(485, 'TABL', 'email_account_use_type_vw', 'CREATED_BY', 'int', 10, 0, 1),
(486, 'TABL', 'email_account_use_type_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(487, 'TABL', 'email_account_use_type_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(488, 'TABL', 'email_account_use_type_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(489, 'TABL', 'email_account_use_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(490, 'TABL', 'email_address_mst', 'EMAIL_ADD_ID', 'int', 10, 0, 1),
(491, 'TABL', 'email_address_mst', 'EMAIL_ADD', 'varchar', 40, NULL, 1),
(492, 'TABL', 'email_address_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(493, 'TABL', 'email_address_mst', 'CREATEDBY', 'int', 10, 0, 1),
(494, 'TABL', 'email_address_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(495, 'TABL', 'email_address_mst', 'CREATEDON', 'timestamp', NULL, NULL, 1),
(496, 'TABL', 'email_address_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(497, 'TABL', 'email_config', 'EML_CNFG_ID', 'int', 10, 0, 1),
(498, 'TABL', 'email_config', 'MAIL_TYPE_ID', 'int', 10, 0, 1),
(499, 'TABL', 'email_config', 'SENT_AS0', 'varchar', 250, NULL, 1),
(500, 'TABL', 'email_config', 'SENDMAIL_PATH', 'varchar', 250, NULL, 1),
(501, 'TABL', 'email_config', 'SMTP_HOST', 'varchar', 250, NULL, 1),
(502, 'TABL', 'email_config', 'SMTP_PORT', 'int', 10, 0, 1),
(503, 'TABL', 'email_config', 'SMTP_USERNAME', 'varchar', 250, NULL, 1),
(504, 'TABL', 'email_config', 'SMTP_PASSWORD', 'varchar', 250, NULL, 1),
(505, 'TABL', 'email_config', 'SMTP_AUTH_TYPE', 'varchar', 50, NULL, 1),
(506, 'TABL', 'email_config', 'SMTP_SECURITY_TYPE', 'varchar', 50, NULL, 1),
(507, 'TABL', 'email_config', 'OA_ID', 'int', 10, 0, 1),
(508, 'TABL', 'email_config', 'OA_BRAND_ID', 'int', 10, 0, 1),
(509, 'TABL', 'email_config', 'ISDELETED', 'tinyint', 3, 0, 1),
(510, 'TABL', 'email_config', 'CREATEDBY', 'int', 10, 0, 1),
(511, 'TABL', 'email_config', 'UPDATEDBY', 'int', 10, 0, 1),
(512, 'TABL', 'email_config', 'CREATEDON', 'datetime', NULL, NULL, 1),
(513, 'TABL', 'email_config', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(514, 'TABL', 'email_subscriber', 'EML_SBSCRBR_ID', 'int', 10, 0, 1),
(515, 'TABL', 'email_subscriber', 'NOTIFICATION_ID', 'int', 10, 0, 1),
(516, 'TABL', 'email_subscriber', 'SUBCRIBER_NAME', 'varchar', 100, NULL, 1),
(517, 'TABL', 'email_subscriber', 'SUBSCRIBER_EMAIL', 'varchar', 100, NULL, 1),
(518, 'TABL', 'email_subscriber', 'OA_ID', 'int', 10, 0, 1),
(519, 'TABL', 'email_subscriber', 'OA_BRAND_ID', 'int', 10, 0, 1),
(520, 'TABL', 'email_subscriber', 'CREATEDBY', 'int', 10, 0, 1),
(521, 'TABL', 'email_subscriber', 'UPDATEDBY', 'int', 10, 0, 1),
(522, 'TABL', 'email_subscriber', 'CREATEDON', 'datetime', NULL, NULL, 1),
(523, 'TABL', 'email_subscriber', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(524, 'TABL', 'emergency_contact_dtl', 'EMERGENCY_CONTACT_DTL_ID', 'int', 10, 0, 1),
(525, 'TABL', 'emergency_contact_dtl', 'EMP_ID', 'int', 10, 0, 1),
(526, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_ID', 'int', 10, 0, 1),
(527, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_RELATION_TYPE_ID', 'int', 10, 0, 1),
(528, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_TEL_ID', 'int', 10, 0, 1),
(529, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_MOBILE_ID', 'int', 10, 0, 1),
(530, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_OFFNO_ID', 'int', 10, 0, 1),
(531, 'TABL', 'emergency_contact_dtl', 'EMERG_CONTACT_EMAIL_ID', 'int', 10, 0, 1),
(532, 'TABL', 'emergency_contact_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(533, 'TABL', 'emergency_contact_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(534, 'TABL', 'emergency_contact_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(535, 'TABL', 'emergency_contact_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(536, 'TABL', 'eml_notification_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(537, 'TABL', 'eml_notification_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(538, 'TABL', 'eml_notification_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(539, 'TABL', 'eml_notification_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(540, 'TABL', 'eml_notification_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(541, 'TABL', 'eml_notification_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(542, 'TABL', 'eml_notification_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(543, 'TABL', 'eml_notification_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(544, 'TABL', 'eml_notification_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(545, 'TABL', 'eml_notification_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(546, 'TABL', 'eml_notification_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(547, 'TABL', 'eml_notification_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(548, 'TABL', 'eml_notification_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(549, 'TABL', 'emp_basic_sal_dtl', 'EMP_BASIC_SAL_DTL_ID', 'int', 10, 0, 1),
(550, 'TABL', 'emp_basic_sal_dtl', 'EMP_ID', 'int', 10, 0, 1),
(551, 'TABL', 'emp_basic_sal_dtl', 'EMP_GRADE_ID', 'int', 10, 0, 1),
(552, 'TABL', 'emp_basic_sal_dtl', 'POSITION_ID', 'int', 10, 0, 1),
(553, 'TABL', 'emp_basic_sal_dtl', 'CURRENCY_ID', 'int', 10, 0, 1),
(554, 'TABL', 'emp_basic_sal_dtl', 'BASIC_SALARY', 'decimal', 10, 2, 1),
(555, 'TABL', 'emp_basic_sal_dtl', 'PAY_FREQUENCY_ID', 'int', 10, 0, 1),
(556, 'TABL', 'emp_basic_sal_dtl', 'COMPONENT_DESC', 'varchar', 100, NULL, 1),
(557, 'TABL', 'emp_basic_sal_dtl', 'COMMENTS', 'varchar', 255, NULL, 1),
(558, 'TABL', 'emp_basic_sal_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(559, 'TABL', 'emp_basic_sal_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(560, 'TABL', 'emp_basic_sal_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(561, 'TABL', 'emp_basic_sal_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(562, 'TABL', 'emp_education', 'ID', 'int', 10, 0, 1),
(563, 'TABL', 'emp_education', 'EMP_ID', 'int', 10, 0, 1),
(564, 'TABL', 'emp_education', 'EDU_QUAL_ID', 'int', 10, 0, 1),
(565, 'TABL', 'emp_education', 'INSTITUTE', 'varchar', 100, NULL, 1),
(566, 'TABL', 'emp_education', 'MAJOR', 'varchar', 100, NULL, 1),
(567, 'TABL', 'emp_education', 'YEAR', 'decimal', 4, 0, 1),
(568, 'TABL', 'emp_education', 'SCORE', 'varchar', 100, NULL, 1),
(569, 'TABL', 'emp_education', 'START_DATE', 'date', NULL, NULL, 1),
(570, 'TABL', 'emp_education', 'END_DATE', 'date', NULL, NULL, 1),
(571, 'TABL', 'emp_education', 'CREATED_BY', 'int', 10, 0, 1),
(572, 'TABL', 'emp_education', 'UPDATED_BY', 'int', 10, 0, 1),
(573, 'TABL', 'emp_education', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(574, 'TABL', 'emp_education', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(575, 'TABL', 'emp_language', 'EMP_LANGUAGE_ID', 'int', 10, 0, 1),
(576, 'TABL', 'emp_language', 'EMP_ID', 'int', 10, 0, 1),
(577, 'TABL', 'emp_language', 'LANGUAGE_ID', 'int', 10, 0, 1),
(578, 'TABL', 'emp_language', 'LANGUAGE_FLUENCY_ID', 'int', 10, 0, 1),
(579, 'TABL', 'emp_language', 'LANGUAGE_COMPETENCY_ID', 'int', 10, 0, 1),
(580, 'TABL', 'emp_language', 'COMMENTS', 'varchar', 100, NULL, 1),
(581, 'TABL', 'emp_language', 'CREATED_BY', 'int', 10, 0, 1),
(582, 'TABL', 'emp_language', 'UPDATED_BY', 'int', 10, 0, 1),
(583, 'TABL', 'emp_language', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(584, 'TABL', 'emp_language', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(585, 'TABL', 'emp_licence', 'LICENSE_ID', 'int', 10, 0, 1),
(586, 'TABL', 'emp_licence', 'EMP_ID', 'int', 10, 0, 1),
(587, 'TABL', 'emp_licence', 'LICENSE_NO', 'varchar', 100, NULL, 1),
(588, 'TABL', 'emp_licence', 'LICENSE_ISSUED_DATE', 'date', NULL, NULL, 1),
(589, 'TABL', 'emp_licence', 'LICENSE_EXPIRY_DATE', 'date', NULL, NULL, 1),
(590, 'TABL', 'emp_licence', 'CREATED_BY', 'int', 10, 0, 1),
(591, 'TABL', 'emp_licence', 'UPDATED_BY', 'int', 10, 0, 1),
(592, 'TABL', 'emp_licence', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(593, 'TABL', 'emp_licence', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(594, 'TABL', 'emp_mst', 'EMP_ID', 'int', 10, 0, 1),
(595, 'TABL', 'emp_mst', 'EMP_NAME', 'varchar', 250, NULL, 1),
(596, 'TABL', 'emp_mst', 'EMP_NBR', 'varchar', 100, NULL, 1),
(597, 'TABL', 'emp_mst', 'OA_CNTCTS_ID', 'int', 10, 0, 1),
(598, 'TABL', 'emp_mst', 'OA_CNTCT_ADD_ID', 'int', 10, 0, 1),
(599, 'TABL', 'emp_mst', 'OA_CNTCT_EML_ID', 'int', 10, 0, 1),
(600, 'TABL', 'emp_mst', 'OA_CNTCT_PHONE_ID', 'int', 10, 0, 1),
(601, 'TABL', 'emp_mst', 'EMP_SSN_NBR', 'varchar', 100, NULL, 1),
(602, 'TABL', 'emp_mst', 'EMP_SIN_NBR', 'varchar', 100, NULL, 1),
(603, 'TABL', 'emp_mst', 'EMP_OTHER_ID', 'varchar', 100, NULL, 1),
(604, 'TABL', 'emp_mst', 'EMP_DRI_LICE_NBR', 'varchar', 100, NULL, 1),
(605, 'TABL', 'emp_mst', 'EMP_DRI_LICE_EXP_DATE', 'datetime', NULL, NULL, 1),
(606, 'TABL', 'emp_mst', 'EMP_MILITARY_SERVICE', 'varchar', 100, NULL, 1),
(607, 'TABL', 'emp_mst', 'EMP_STATUS_ID', 'int', 10, 0, 1),
(608, 'TABL', 'emp_mst', 'JOB_TITLE_ID', 'int', 10, 0, 1),
(609, 'TABL', 'emp_mst', 'JOB_CAT_ID', 'int', 10, 0, 1),
(610, 'TABL', 'emp_mst', 'WORK_STATION', 'varchar', 100, NULL, 1),
(611, 'TABL', 'emp_mst', 'EMP_GRADE_ID', 'int', 10, 0, 1),
(612, 'TABL', 'emp_mst', 'DATE_OF_JOINING', 'datetime', NULL, NULL, 1),
(613, 'TABL', 'emp_mst', 'TERMINATION_ID', 'int', 10, 0, 1),
(614, 'TABL', 'emp_mst', 'OA_BRAND_ID', 'int', 10, 0, 1),
(615, 'TABL', 'emp_mst', 'CREATED_BY', 'int', 10, 0, 1),
(616, 'TABL', 'emp_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(617, 'TABL', 'emp_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(618, 'TABL', 'emp_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(619, 'TABL', 'emp_picture', 'EMP_PICYURE_ID', 'int', 10, 0, 1),
(620, 'TABL', 'emp_picture', 'EMP_ID', 'int', 10, 0, 1),
(621, 'TABL', 'emp_picture', 'EPIC_PICTURE', 'mediumblob', 16777215, NULL, 1),
(622, 'TABL', 'emp_picture', 'EPIC_FILENAME', 'varchar', 100, NULL, 1),
(623, 'TABL', 'emp_picture', 'EPIC_TYPE', 'varchar', 100, NULL, 1),
(624, 'TABL', 'emp_picture', 'EPIC_FILE_SIZE', 'varchar', 100, NULL, 1),
(625, 'TABL', 'emp_picture', 'EPIC_FILE_WIDTH', 'varchar', 100, NULL, 1),
(626, 'TABL', 'emp_picture', 'EPIC_FILE_HEIGHT', 'varchar', 100, NULL, 1),
(627, 'TABL', 'emp_picture', 'CREATED_BY', 'int', 10, 0, 1),
(628, 'TABL', 'emp_picture', 'UPDATED_BY', 'int', 10, 0, 1),
(629, 'TABL', 'emp_picture', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(630, 'TABL', 'emp_picture', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(631, 'TABL', 'emp_reporting', 'EMP_REPORTING_ID', 'int', 10, 0, 1),
(632, 'TABL', 'emp_reporting', 'EMP_ID', 'int', 10, 0, 1),
(633, 'TABL', 'emp_reporting', 'MANAGER_ID', 'int', 10, 0, 1),
(634, 'TABL', 'emp_reporting', 'MANAGER_TYPE_ID', 'int', 10, 0, 1),
(635, 'TABL', 'emp_reporting', 'REPORTING_MODE_ID', 'int', 10, 0, 1),
(636, 'TABL', 'emp_reporting', 'CREATED_BY', 'int', 10, 0, 1),
(637, 'TABL', 'emp_reporting', 'UPDATED_BY', 'int', 10, 0, 1),
(638, 'TABL', 'emp_reporting', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(639, 'TABL', 'emp_reporting', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(640, 'TABL', 'emp_reporting_locations', 'EMP_REPORTING_LOCATIONS_ID', 'int', 10, 0, 1),
(641, 'TABL', 'emp_reporting_locations', 'EMP_ID', 'int', 10, 0, 1),
(642, 'TABL', 'emp_reporting_locations', 'LOCATION_ID', 'int', 10, 0, 1),
(643, 'TABL', 'emp_reporting_locations', 'CREATED_BY', 'int', 10, 0, 1),
(644, 'TABL', 'emp_reporting_locations', 'UPDATED_BY', 'int', 10, 0, 1),
(645, 'TABL', 'emp_reporting_locations', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(646, 'TABL', 'emp_reporting_locations', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(647, 'TABL', 'emp_skill', 'EMP_SKILL_ID', 'int', 10, 0, 1),
(648, 'TABL', 'emp_skill', 'EMP_ID', 'int', 10, 0, 1),
(649, 'TABL', 'emp_skill', 'SKILL_ID', 'int', 10, 0, 1),
(650, 'TABL', 'emp_skill', 'YEARS_OF_EXP', 'decimal', 2, 0, 1),
(651, 'TABL', 'emp_skill', 'COMMENTS', 'varchar', 100, NULL, 1),
(652, 'TABL', 'emp_skill', 'CREATED_BY', 'int', 10, 0, 1),
(653, 'TABL', 'emp_skill', 'UPDATED_BY', 'int', 10, 0, 1),
(654, 'TABL', 'emp_skill', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(655, 'TABL', 'emp_skill', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(656, 'TABL', 'emp_work_experience', 'EMP_WORK_EXPERIENCE_ID', 'int', 10, 0, 1),
(657, 'TABL', 'emp_work_experience', 'EMP_ID', 'int', 10, 0, 1),
(658, 'TABL', 'emp_work_experience', 'EEXP_SEQNO', 'int', 10, 0, 1),
(659, 'TABL', 'emp_work_experience', 'EEXP_EMPLOYER', 'varchar', 100, NULL, 1),
(660, 'TABL', 'emp_work_experience', 'JOB_TITLE_ID', 'int', 10, 0, 1),
(661, 'TABL', 'emp_work_experience', 'EEXP_FROM_DATE', 'datetime', NULL, NULL, 1),
(662, 'TABL', 'emp_work_experience', 'EEXP_TO_DATE', 'datetime', NULL, NULL, 1),
(663, 'TABL', 'emp_work_experience', 'EEXP_COMMENTS', 'varchar', 250, NULL, 1),
(664, 'TABL', 'emp_work_experience', 'EEXP_INTERNAL', 'int', 10, 0, 1),
(665, 'TABL', 'emp_work_experience', 'CREATED_BY', 'int', 10, 0, 1),
(666, 'TABL', 'emp_work_experience', 'UPDATED_BY', 'int', 10, 0, 1),
(667, 'TABL', 'emp_work_experience', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(668, 'TABL', 'emp_work_experience', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(669, 'TABL', 'emp_work_shift', 'EMP_WORK_SHIFT_ID', 'int', 10, 0, 1),
(670, 'TABL', 'emp_work_shift', 'WORK_SHIFT_ID', 'int', 10, 0, 1),
(671, 'TABL', 'emp_work_shift', 'EMP_NUMBER', 'int', 10, 0, 1),
(672, 'TABL', 'emp_work_shift', 'CREATED_BY', 'int', 10, 0, 1),
(673, 'TABL', 'emp_work_shift', 'UPDATED_BY', 'int', 10, 0, 1),
(674, 'TABL', 'emp_work_shift', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(675, 'TABL', 'emp_work_shift', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(676, 'TABL', 'emt_sys_err_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(677, 'TABL', 'emt_sys_err_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(678, 'TABL', 'emt_sys_err_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(679, 'TABL', 'emt_sys_err_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(680, 'TABL', 'emt_sys_err_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(681, 'TABL', 'emt_sys_err_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(682, 'TABL', 'emt_sys_err_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(683, 'TABL', 'emt_sys_err_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(684, 'TABL', 'emt_sys_err_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(685, 'TABL', 'emt_sys_err_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(686, 'TABL', 'emt_sys_err_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(687, 'TABL', 'emt_sys_err_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(688, 'TABL', 'emt_sys_info_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(689, 'TABL', 'emt_sys_info_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(690, 'TABL', 'emt_sys_info_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(691, 'TABL', 'emt_sys_info_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(692, 'TABL', 'emt_sys_info_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(693, 'TABL', 'emt_sys_info_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(694, 'TABL', 'emt_sys_info_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(695, 'TABL', 'emt_sys_info_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(696, 'TABL', 'emt_sys_info_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(697, 'TABL', 'emt_sys_info_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(698, 'TABL', 'emt_sys_info_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(699, 'TABL', 'emt_sys_info_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(700, 'TABL', 'emt_sys_warn_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(701, 'TABL', 'emt_sys_warn_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(702, 'TABL', 'emt_sys_warn_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(703, 'TABL', 'emt_sys_warn_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(704, 'TABL', 'emt_sys_warn_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(705, 'TABL', 'emt_sys_warn_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(706, 'TABL', 'emt_sys_warn_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(707, 'TABL', 'emt_sys_warn_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(708, 'TABL', 'emt_sys_warn_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(709, 'TABL', 'emt_sys_warn_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(710, 'TABL', 'emt_sys_warn_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(711, 'TABL', 'emt_sys_warn_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(712, 'TABL', 'emt_usr_err_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(713, 'TABL', 'emt_usr_err_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(714, 'TABL', 'emt_usr_err_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(715, 'TABL', 'emt_usr_err_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(716, 'TABL', 'emt_usr_err_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(717, 'TABL', 'emt_usr_err_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(718, 'TABL', 'emt_usr_err_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(719, 'TABL', 'emt_usr_err_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(720, 'TABL', 'emt_usr_err_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(721, 'TABL', 'emt_usr_err_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(722, 'TABL', 'emt_usr_err_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(723, 'TABL', 'emt_usr_err_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(724, 'TABL', 'emt_usr_info_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(725, 'TABL', 'emt_usr_info_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(726, 'TABL', 'emt_usr_info_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(727, 'TABL', 'emt_usr_info_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(728, 'TABL', 'emt_usr_info_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(729, 'TABL', 'emt_usr_info_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(730, 'TABL', 'emt_usr_info_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(731, 'TABL', 'emt_usr_info_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(732, 'TABL', 'emt_usr_info_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(733, 'TABL', 'emt_usr_info_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(734, 'TABL', 'emt_usr_info_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(735, 'TABL', 'emt_usr_info_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(736, 'TABL', 'emt_usr_warn_mst_vw', 'MSTR_ID', 'int', 10, 0, 1);
INSERT INTO `entity_obj_tmp` (`TMP_OBJ_ID`, `OBJ_TYP`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_NW_RCRD_FLG`) VALUES
(737, 'TABL', 'emt_usr_warn_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(738, 'TABL', 'emt_usr_warn_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(739, 'TABL', 'emt_usr_warn_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(740, 'TABL', 'emt_usr_warn_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(741, 'TABL', 'emt_usr_warn_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(742, 'TABL', 'emt_usr_warn_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(743, 'TABL', 'emt_usr_warn_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(744, 'TABL', 'emt_usr_warn_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(745, 'TABL', 'emt_usr_warn_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(746, 'TABL', 'emt_usr_warn_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(747, 'TABL', 'emt_usr_warn_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(748, 'TABL', 'entity_obj', 'OBJ_ID', 'int', 10, 0, 1),
(749, 'TABL', 'entity_obj', 'OBJ_TYP', 'varchar', 4, NULL, 1),
(750, 'TABL', 'entity_obj', 'OBJ_NM', 'varchar', 40, NULL, 1),
(751, 'TABL', 'entity_obj_attrbt', 'OBJ_ATTRBT_ID', 'int', 10, 0, 1),
(752, 'TABL', 'entity_obj_attrbt', 'OBJ_NM', 'varchar', 40, NULL, 1),
(753, 'TABL', 'entity_obj_attrbt', 'OBJ_ATTRBT_NM', 'varchar', 40, NULL, 1),
(754, 'TABL', 'entity_obj_attrbt', 'OBJ_ATTRBT_DT_TYP', 'varchar', 40, NULL, 1),
(755, 'TABL', 'entity_obj_attrbt', 'OBJ_SZ', 'int', 10, 0, 1),
(756, 'TABL', 'entity_obj_attrbt', 'OBJ_PRCSN', 'int', 10, 0, 1),
(757, 'TABL', 'entity_obj_attrbt', 'OBJ_SCALE', 'int', 10, 0, 1),
(758, 'TABL', 'entity_obj_attrbt', 'IS_VISIBLE', 'tinyint', 3, 0, 1),
(759, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_DSPLY_ID', 'int', 10, 0, 1),
(760, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_ID', 'int', 10, 0, 1),
(761, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'OBJ_ATTRBT_DSPLY_NM', 'varchar', 40, NULL, 1),
(762, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'OA_ID', 'int', 10, 0, 1),
(763, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'OA_BRAND_ID', 'int', 10, 0, 1),
(764, 'TABL', 'entity_obj_attrbt_dsply_dtl', 'USER_ID', 'int', 10, 0, 1),
(765, 'TABL', 'entity_obj_attrbt_mppng', 'OBJ_ATTRBT_MPPNG_ID', 'int', 10, 0, 1),
(766, 'TABL', 'entity_obj_attrbt_mppng', 'SRC_OJB_NM', 'varchar', 40, NULL, 1),
(767, 'TABL', 'entity_obj_attrbt_mppng', 'SRC_OBJ_ATTRBT_NM', 'varchar', 40, NULL, 1),
(768, 'TABL', 'entity_obj_attrbt_mppng', 'TRG_OJB_NM', 'varchar', 40, NULL, 1),
(769, 'TABL', 'entity_obj_attrbt_mppng', 'TRG_OBJ_ATTRBT_NM', 'varchar', 40, NULL, 1),
(770, 'TABL', 'entity_obj_attrbt_mppng', 'OBJ_MPPNG_ID', 'int', 10, 0, 1),
(771, 'TABL', 'entity_obj_mppng', 'OBJ_MPPNG_ID', 'int', 10, 0, 1),
(772, 'TABL', 'entity_obj_mppng', 'SRC_LYR_ID', 'int', 10, 0, 1),
(773, 'TABL', 'entity_obj_mppng', 'SRC_OBJ_ID', 'int', 10, 0, 1),
(774, 'TABL', 'entity_obj_mppng', 'TRGT_LYR_ID', 'int', 10, 0, 1),
(775, 'TABL', 'entity_obj_mppng', 'TRGT_OBJ_ID', 'int', 10, 0, 1),
(776, 'TABL', 'entity_obj_tmp', 'TMP_OBJ_ID', 'int', 10, 0, 1),
(777, 'TABL', 'entity_obj_tmp', 'OBJ_TYP', 'varchar', 4, NULL, 1),
(778, 'TABL', 'entity_obj_tmp', 'OBJ_NM', 'varchar', 40, NULL, 1),
(779, 'TABL', 'entity_obj_tmp', 'OBJ_ATTRBT_NM', 'varchar', 40, NULL, 1),
(780, 'TABL', 'entity_obj_tmp', 'OBJ_ATTRBT_DT_TYP', 'varchar', 40, NULL, 1),
(781, 'TABL', 'entity_obj_tmp', 'OBJ_SZ', 'int', 10, 0, 1),
(782, 'TABL', 'entity_obj_tmp', 'OBJ_PRCSN', 'int', 10, 0, 1),
(783, 'TABL', 'entity_obj_tmp', 'OBJ_NW_RCRD_FLG', 'tinyint', 3, 0, 1),
(784, 'TABL', 'entity_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(785, 'TABL', 'entity_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(786, 'TABL', 'entity_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(787, 'TABL', 'entity_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(788, 'TABL', 'entity_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(789, 'TABL', 'entity_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(790, 'TABL', 'entity_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(791, 'TABL', 'entity_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(792, 'TABL', 'entity_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(793, 'TABL', 'entity_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(794, 'TABL', 'entity_obj_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(795, 'TABL', 'entity_obj_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(796, 'TABL', 'epic_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(797, 'TABL', 'epic_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(798, 'TABL', 'epic_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(799, 'TABL', 'epic_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(800, 'TABL', 'epic_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(801, 'TABL', 'epic_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(802, 'TABL', 'epic_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(803, 'TABL', 'epic_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(804, 'TABL', 'epic_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(805, 'TABL', 'epic_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(806, 'TABL', 'epic_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(807, 'TABL', 'epic_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(808, 'TABL', 'epic_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(809, 'TABL', 'ethinicity_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(810, 'TABL', 'ethinicity_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(811, 'TABL', 'ethinicity_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(812, 'TABL', 'ethinicity_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(813, 'TABL', 'ethinicity_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(814, 'TABL', 'ethinicity_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(815, 'TABL', 'ethinicity_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(816, 'TABL', 'ethinicity_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(817, 'TABL', 'ethinicity_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(818, 'TABL', 'ethinicity_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(819, 'TABL', 'ethinicity_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(820, 'TABL', 'ethinicity_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(821, 'TABL', 'ethinicity_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(822, 'TABL', 'exception_log', 'EXCEPTION_LOG_ID', 'int', 10, 0, 1),
(823, 'TABL', 'exception_log', 'EXCEPTION_TYPE_ID', 'int', 10, 0, 1),
(824, 'TABL', 'exception_log', 'SESSION_ID', 'varchar', 500, NULL, 1),
(825, 'TABL', 'exception_log', 'APP_ID', 'int', 10, 0, 1),
(826, 'TABL', 'exception_log', 'MODULE_ID', 'int', 10, 0, 1),
(827, 'TABL', 'exception_log', 'PROCESS_ID', 'int', 10, 0, 1),
(828, 'TABL', 'exception_log', 'LOCATION_NO', 'int', 10, 0, 1),
(829, 'TABL', 'exception_log', 'ERROR_NBR', 'int', 10, 0, 1),
(830, 'TABL', 'exception_log', 'ERROR_DESC', 'varchar', 4000, NULL, 1),
(831, 'TABL', 'exception_log', 'OA_ID', 'int', 10, 0, 1),
(832, 'TABL', 'exception_log', 'OA_BRAND_ID', 'int', 10, 0, 1),
(833, 'TABL', 'exception_log', 'ERROR_STACK', 'varchar', 4000, NULL, 1),
(834, 'TABL', 'exception_log', 'CALL_STACK', 'varchar', 4000, NULL, 1),
(835, 'TABL', 'exception_log', 'MESSAGE_LEVEL', 'int', 10, 0, 1),
(836, 'TABL', 'exception_log', 'MSG_ID', 'int', 10, 0, 1),
(837, 'TABL', 'exception_log', 'CREATED_BY', 'int', 10, 0, 1),
(838, 'TABL', 'exception_log', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(839, 'TABL', 'exception_message_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(840, 'TABL', 'exception_message_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(841, 'TABL', 'exception_message_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(842, 'TABL', 'exception_message_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(843, 'TABL', 'exception_message_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(844, 'TABL', 'exception_message_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(845, 'TABL', 'exception_message_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(846, 'TABL', 'exception_message_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(847, 'TABL', 'exception_message_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(848, 'TABL', 'exception_message_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(849, 'TABL', 'exception_message_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(850, 'TABL', 'exception_message_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(851, 'TABL', 'exe_mngmnt_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(852, 'TABL', 'exe_mngmnt_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(853, 'TABL', 'exe_mngmnt_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(854, 'TABL', 'exe_mngmnt_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(855, 'TABL', 'exe_mngmnt_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(856, 'TABL', 'exe_mngmnt_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(857, 'TABL', 'exe_mngmnt_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(858, 'TABL', 'exe_mngmnt_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(859, 'TABL', 'exe_mngmnt_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(860, 'TABL', 'exe_mngmnt_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(861, 'TABL', 'exe_mngmnt_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(862, 'TABL', 'exe_mngmnt_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(863, 'TABL', 'exe_mngmnt_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(864, 'TABL', 'feature_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(865, 'TABL', 'feature_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(866, 'TABL', 'feature_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(867, 'TABL', 'feature_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(868, 'TABL', 'feature_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(869, 'TABL', 'feature_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(870, 'TABL', 'feature_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(871, 'TABL', 'feature_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(872, 'TABL', 'feature_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(873, 'TABL', 'feature_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(874, 'TABL', 'feature_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(875, 'TABL', 'feature_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(876, 'TABL', 'feature_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(877, 'TABL', 'form_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(878, 'TABL', 'form_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(879, 'TABL', 'form_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(880, 'TABL', 'form_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(881, 'TABL', 'form_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(882, 'TABL', 'form_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(883, 'TABL', 'form_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(884, 'TABL', 'form_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(885, 'TABL', 'form_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(886, 'TABL', 'form_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(887, 'TABL', 'form_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(888, 'TABL', 'form_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(889, 'TABL', 'gender_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(890, 'TABL', 'gender_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(891, 'TABL', 'gender_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(892, 'TABL', 'gender_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(893, 'TABL', 'gender_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(894, 'TABL', 'gender_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(895, 'TABL', 'gender_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(896, 'TABL', 'gender_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(897, 'TABL', 'gender_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(898, 'TABL', 'gender_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(899, 'TABL', 'gender_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(900, 'TABL', 'gender_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(901, 'TABL', 'gender_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(902, 'TABL', 'geo_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(903, 'TABL', 'geo_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(904, 'TABL', 'geo_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(905, 'TABL', 'geo_hier_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(906, 'TABL', 'geo_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(907, 'TABL', 'geo_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(908, 'TABL', 'geo_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(909, 'TABL', 'geo_hier_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(910, 'TABL', 'geo_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(911, 'TABL', 'geo_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(912, 'TABL', 'geo_hier_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(913, 'TABL', 'geo_hier_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(914, 'TABL', 'geo_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(915, 'TABL', 'global_setting_item_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(916, 'TABL', 'global_setting_item_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(917, 'TABL', 'global_setting_item_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(918, 'TABL', 'global_setting_item_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(919, 'TABL', 'global_setting_item_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(920, 'TABL', 'global_setting_item_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(921, 'TABL', 'global_setting_item_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(922, 'TABL', 'global_setting_item_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(923, 'TABL', 'global_setting_item_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(924, 'TABL', 'global_setting_item_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(925, 'TABL', 'global_setting_item_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(926, 'TABL', 'global_setting_item_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(927, 'TABL', 'group_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(928, 'TABL', 'group_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(929, 'TABL', 'group_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(930, 'TABL', 'group_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(931, 'TABL', 'group_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(932, 'TABL', 'group_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(933, 'TABL', 'group_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(934, 'TABL', 'group_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(935, 'TABL', 'group_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(936, 'TABL', 'group_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(937, 'TABL', 'group_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(938, 'TABL', 'group_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(939, 'TABL', 'group_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(940, 'TABL', 'group_role', 'GRP_ROLE_ID', 'int', 10, 0, 1),
(941, 'TABL', 'group_role', 'ROLE_ID', 'int', 10, 0, 1),
(942, 'TABL', 'group_role', 'USER_GRP_ID', 'int', 10, 0, 1),
(943, 'TABL', 'group_role', 'CREATED_BY', 'int', 10, 0, 1),
(944, 'TABL', 'group_role', 'UPDATED_BY', 'int', 10, 0, 1),
(945, 'TABL', 'group_role', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(946, 'TABL', 'group_role', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(947, 'TABL', 'gsdatavaluetype_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(948, 'TABL', 'gsdatavaluetype_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(949, 'TABL', 'gsdatavaluetype_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(950, 'TABL', 'gsdatavaluetype_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(951, 'TABL', 'gsdatavaluetype_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(952, 'TABL', 'gsdatavaluetype_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(953, 'TABL', 'gsdatavaluetype_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(954, 'TABL', 'gsdatavaluetype_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(955, 'TABL', 'gsdatavaluetype_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(956, 'TABL', 'gsdatavaluetype_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(957, 'TABL', 'gsdatavaluetype_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(958, 'TABL', 'gsdatavaluetype_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(959, 'TABL', 'hier_level_config', 'HIER_LEVEL_CONFIG_ID', 'int', 10, 0, 1),
(960, 'TABL', 'hier_level_config', 'HIER_TYPE_ID', 'int', 10, 0, 1),
(961, 'TABL', 'hier_level_config', 'HIER_CHILD_ENTITY_TYPE_ID', 'int', 10, 0, 1),
(962, 'TABL', 'hier_level_config', 'HIER_PARENT_ENTITY_TYPE_ID', 'int', 10, 0, 1),
(963, 'TABL', 'hier_level_config', 'LEVEL_SEQ', 'int', 10, 0, 1),
(964, 'TABL', 'hier_level_config', 'OA_ID', 'int', 10, 0, 1),
(965, 'TABL', 'hier_level_config', 'OA_BRAND_ID', 'int', 10, 0, 1),
(966, 'TABL', 'hier_level_config', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(967, 'TABL', 'hier_level_config', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(968, 'TABL', 'hier_level_config', 'IS_DELETED', 'tinyint', 3, 0, 1),
(969, 'TABL', 'hier_level_config', 'CREATED_BY', 'int', 10, 0, 1),
(970, 'TABL', 'hier_level_config', 'UPDATED_BY', 'int', 10, 0, 1),
(971, 'TABL', 'hier_level_config', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(972, 'TABL', 'hier_level_config', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(973, 'TABL', 'hierarchy_type_vw', 'MSTR_ID', 'int', 10, 0, 1),
(974, 'TABL', 'hierarchy_type_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(975, 'TABL', 'hierarchy_type_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(976, 'TABL', 'hierarchy_type_vw', 'TYP_ID', 'int', 10, 0, 1),
(977, 'TABL', 'hierarchy_type_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(978, 'TABL', 'hierarchy_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(979, 'TABL', 'hierarchy_type_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(980, 'TABL', 'hierarchy_type_vw', 'OA_ID', 'int', 10, 0, 1),
(981, 'TABL', 'hierarchy_type_vw', 'CREATED_BY', 'int', 10, 0, 1),
(982, 'TABL', 'hierarchy_type_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(983, 'TABL', 'hierarchy_type_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(984, 'TABL', 'hierarchy_type_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(985, 'TABL', 'hierarchy_type_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(986, 'TABL', 'hod_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(987, 'TABL', 'hod_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(988, 'TABL', 'hod_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(989, 'TABL', 'hod_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(990, 'TABL', 'hod_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(991, 'TABL', 'hod_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(992, 'TABL', 'hod_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(993, 'TABL', 'hod_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(994, 'TABL', 'hod_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(995, 'TABL', 'hod_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(996, 'TABL', 'hod_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(997, 'TABL', 'hod_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(998, 'TABL', 'hod_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(999, 'TABL', 'independent_mst', 'MSTR_ID', 'int', 10, 0, 1),
(1000, 'TABL', 'independent_mst', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1001, 'TABL', 'independent_mst', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1002, 'TABL', 'independent_mst', 'TYP_ID', 'int', 10, 0, 1),
(1003, 'TABL', 'independent_mst', 'RECORD_TYP', 'int', 10, 0, 1),
(1004, 'TABL', 'independent_mst', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1005, 'TABL', 'independent_mst', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1006, 'TABL', 'independent_mst', 'OA_ID', 'int', 10, 0, 1),
(1007, 'TABL', 'independent_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1008, 'TABL', 'independent_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1009, 'TABL', 'independent_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1010, 'TABL', 'independent_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1011, 'TABL', 'independent_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1012, 'TABL', 'inface_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1013, 'TABL', 'inface_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(1014, 'TABL', 'inface_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(1015, 'TABL', 'inface_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(1016, 'TABL', 'inface_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(1017, 'TABL', 'inface_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1018, 'TABL', 'inface_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1019, 'TABL', 'inface_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1020, 'TABL', 'inface_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1021, 'TABL', 'inface_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1022, 'TABL', 'inface_obj_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1023, 'TABL', 'inface_obj_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1024, 'TABL', 'location_mst', 'LOC_ID', 'int', 10, 0, 1),
(1025, 'TABL', 'location_mst', 'LOC_CODE', 'varchar', 5, NULL, 1),
(1026, 'TABL', 'location_mst', 'LOC_NAME', 'varchar', 40, NULL, 1),
(1027, 'TABL', 'location_mst', 'LOC_TYPE_ID', 'int', 10, 0, 1),
(1028, 'TABL', 'location_mst', 'LOC_DIAL_CD', 'varchar', 5, NULL, 1),
(1029, 'TABL', 'location_mst', 'LOC_TIMEZONE_CD', 'int', 10, 0, 1),
(1030, 'TABL', 'location_mst', 'OA_ID', 'int', 10, 0, 1),
(1031, 'TABL', 'location_mst', 'ISDELETED', 'tinyint', 3, 0, 1),
(1032, 'TABL', 'location_mst', 'CREATEDBY', 'int', 10, 0, 1),
(1033, 'TABL', 'location_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(1034, 'TABL', 'location_mst', 'CREATEDON', 'datetime', NULL, NULL, 1),
(1035, 'TABL', 'location_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(1036, 'TABL', 'location_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1037, 'TABL', 'location_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1038, 'TABL', 'location_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1039, 'TABL', 'location_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1040, 'TABL', 'location_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1041, 'TABL', 'location_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1042, 'TABL', 'location_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1043, 'TABL', 'location_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1044, 'TABL', 'location_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1045, 'TABL', 'location_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1046, 'TABL', 'location_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1047, 'TABL', 'location_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1048, 'TABL', 'location_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1049, 'TABL', 'mail_type_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1050, 'TABL', 'mail_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1051, 'TABL', 'mail_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1052, 'TABL', 'mail_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1053, 'TABL', 'mail_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1054, 'TABL', 'mail_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1055, 'TABL', 'mail_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1056, 'TABL', 'mail_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1057, 'TABL', 'mail_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1058, 'TABL', 'mail_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1059, 'TABL', 'mail_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1060, 'TABL', 'mail_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1061, 'TABL', 'mail_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1062, 'TABL', 'manager_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1063, 'TABL', 'manager_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1064, 'TABL', 'manager_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1065, 'TABL', 'manager_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1066, 'TABL', 'manager_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1067, 'TABL', 'manager_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1068, 'TABL', 'manager_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1069, 'TABL', 'manager_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1070, 'TABL', 'manager_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1071, 'TABL', 'manager_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1072, 'TABL', 'manager_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1073, 'TABL', 'manager_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1074, 'TABL', 'manager_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1075, 'TABL', 'marrital_status_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1076, 'TABL', 'marrital_status_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1077, 'TABL', 'marrital_status_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1078, 'TABL', 'marrital_status_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1079, 'TABL', 'marrital_status_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1080, 'TABL', 'marrital_status_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1081, 'TABL', 'marrital_status_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1082, 'TABL', 'marrital_status_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1083, 'TABL', 'marrital_status_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1084, 'TABL', 'marrital_status_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1085, 'TABL', 'marrital_status_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1086, 'TABL', 'marrital_status_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1087, 'TABL', 'marrital_status_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1088, 'TABL', 'menu_hier_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1089, 'TABL', 'menu_hier_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1090, 'TABL', 'menu_hier_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1091, 'TABL', 'menu_hier_vw', 'TYP_ID', 'int', 10, 0, 1),
(1092, 'TABL', 'menu_hier_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1093, 'TABL', 'menu_hier_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1094, 'TABL', 'menu_hier_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1095, 'TABL', 'menu_hier_vw', 'OA_ID', 'int', 10, 0, 1),
(1096, 'TABL', 'menu_hier_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1097, 'TABL', 'menu_hier_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1098, 'TABL', 'menu_hier_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1099, 'TABL', 'menu_hier_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1100, 'TABL', 'menu_hier_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1101, 'TABL', 'menu_item_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1102, 'TABL', 'menu_item_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1103, 'TABL', 'menu_item_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1104, 'TABL', 'menu_item_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1105, 'TABL', 'menu_item_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1106, 'TABL', 'menu_item_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1107, 'TABL', 'menu_item_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1108, 'TABL', 'menu_item_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1109, 'TABL', 'menu_item_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1110, 'TABL', 'menu_item_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1111, 'TABL', 'menu_item_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1112, 'TABL', 'menu_item_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1113, 'TABL', 'message_mst', 'MSG_ID', 'int', 10, 0, 1),
(1114, 'TABL', 'message_mst', 'SYSTEM_MSG_ID', 'int', 10, 0, 1),
(1115, 'TABL', 'message_mst', 'MSG_SHORT_TEXT', 'varchar', 50, NULL, 1),
(1116, 'TABL', 'message_mst', 'MSG_LONG_TEXT', 'varchar', 250, NULL, 1),
(1117, 'TABL', 'message_mst', 'MSG_TYPE_ID', 'int', 10, 0, 1),
(1118, 'TABL', 'message_mst', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1119, 'TABL', 'message_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1120, 'TABL', 'message_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1121, 'TABL', 'message_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1122, 'TABL', 'message_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1123, 'TABL', 'mngt_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1124, 'TABL', 'mngt_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1125, 'TABL', 'mngt_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1126, 'TABL', 'mngt_hier_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1127, 'TABL', 'mngt_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1128, 'TABL', 'mngt_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1129, 'TABL', 'mngt_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1130, 'TABL', 'mngt_hier_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1131, 'TABL', 'mngt_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1132, 'TABL', 'mngt_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1133, 'TABL', 'mngt_hier_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1134, 'TABL', 'mngt_hier_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1135, 'TABL', 'mngt_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1136, 'TABL', 'model_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1137, 'TABL', 'model_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1138, 'TABL', 'model_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1139, 'TABL', 'model_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1140, 'TABL', 'model_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1141, 'TABL', 'model_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1142, 'TABL', 'model_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1143, 'TABL', 'model_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1144, 'TABL', 'model_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1145, 'TABL', 'model_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1146, 'TABL', 'model_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1147, 'TABL', 'model_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1148, 'TABL', 'module_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1149, 'TABL', 'module_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1150, 'TABL', 'module_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1151, 'TABL', 'module_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1152, 'TABL', 'module_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1153, 'TABL', 'module_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1154, 'TABL', 'module_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1155, 'TABL', 'module_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1156, 'TABL', 'module_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1157, 'TABL', 'module_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1158, 'TABL', 'module_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1159, 'TABL', 'module_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1160, 'TABL', 'module_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1161, 'TABL', 'nationality_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1162, 'TABL', 'nationality_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1163, 'TABL', 'nationality_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1164, 'TABL', 'nationality_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1165, 'TABL', 'nationality_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1166, 'TABL', 'nationality_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1167, 'TABL', 'nationality_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1168, 'TABL', 'nationality_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1169, 'TABL', 'nationality_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1170, 'TABL', 'nationality_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1171, 'TABL', 'nationality_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1172, 'TABL', 'nationality_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1173, 'TABL', 'nationality_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1174, 'TABL', 'non_personal_contact_type_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1175, 'TABL', 'non_personal_contact_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1176, 'TABL', 'non_personal_contact_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1177, 'TABL', 'non_personal_contact_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1178, 'TABL', 'non_personal_contact_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1179, 'TABL', 'non_personal_contact_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1180, 'TABL', 'non_personal_contact_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1181, 'TABL', 'non_personal_contact_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1182, 'TABL', 'non_personal_contact_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1183, 'TABL', 'non_personal_contact_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1184, 'TABL', 'non_personal_contact_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1185, 'TABL', 'non_personal_contact_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1186, 'TABL', 'non_personal_contact_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1187, 'TABL', 'oa_brand_settings', 'OAB_SETTING_ID', 'int', 10, 0, 1),
(1188, 'TABL', 'oa_brand_settings', 'OABS_ATTRBUTE_ID', 'int', 10, 0, 1),
(1189, 'TABL', 'oa_brand_settings', 'OABS_SETTING_VALUE', 'varchar', 40, NULL, 1),
(1190, 'TABL', 'oa_brand_settings', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1191, 'TABL', 'oa_brand_settings', 'REF_ID', 'int', 10, 0, 1),
(1192, 'TABL', 'oa_brand_settings', 'DESCRIPTION', 'varchar', 255, NULL, 1),
(1193, 'TABL', 'oa_brand_settings', 'VALIDATION', 'varchar', 255, NULL, 1),
(1194, 'TABL', 'oa_brand_settings', 'IS_ACTIVE', 'tinyint', 3, 0, 1),
(1195, 'TABL', 'oa_brand_settings', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1196, 'TABL', 'oa_brand_settings', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1197, 'TABL', 'oa_brand_settings', 'CREATED_BY', 'int', 10, 0, 1),
(1198, 'TABL', 'oa_brand_settings', 'UPDATED_BY', 'int', 10, 0, 1),
(1199, 'TABL', 'oa_brands', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1200, 'TABL', 'oa_brands', 'OA_BRAND_CD', 'varchar', 5, NULL, 1),
(1201, 'TABL', 'oa_brands', 'OA_BRAND_NM', 'varchar', 40, NULL, 1),
(1202, 'TABL', 'oa_brands', 'OA_ID', 'int', 10, 0, 1),
(1203, 'TABL', 'oa_brands', 'REF_ID', 'int', 10, 0, 1),
(1204, 'TABL', 'oa_brands', 'OA_BRAND_LOGO', 'varchar', 100, NULL, 1),
(1205, 'TABL', 'oa_brands', 'OA_BRAND_INV_TMPLT', 'varchar', 100, NULL, 1),
(1206, 'TABL', 'oa_brands', 'IS_ACTIVE', 'tinyint', 3, 0, 1),
(1207, 'TABL', 'oa_brands', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(1208, 'TABL', 'oa_brands', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1209, 'TABL', 'oa_brands', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1210, 'TABL', 'oa_brands', 'CREATED_BY', 'int', 10, 0, 1),
(1211, 'TABL', 'oa_brands', 'UPDATED_BY', 'int', 10, 0, 1),
(1212, 'TABL', 'oa_contact_add_phoneno', 'OA_CNTCT_ADD_PHONENO_ID', 'int', 10, 0, 1),
(1213, 'TABL', 'oa_contact_add_phoneno', 'CNTCT_ADD_PHONENO_ID', 'int', 10, 0, 1),
(1214, 'TABL', 'oa_contact_add_phoneno', 'OA_ID', 'int', 10, 0, 1),
(1215, 'TABL', 'oa_contact_add_phoneno', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1216, 'TABL', 'oa_contact_add_phoneno', 'IS_PRIMARY_TELNO', 'tinyint', 3, 0, 1),
(1217, 'TABL', 'oa_contact_add_phoneno', 'CREATED_BY', 'int', 10, 0, 1),
(1218, 'TABL', 'oa_contact_add_phoneno', 'UPDATED_BY', 'int', 10, 0, 1),
(1219, 'TABL', 'oa_contact_add_phoneno', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1220, 'TABL', 'oa_contact_add_phoneno', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1221, 'TABL', 'oa_contact_address', 'OA_CNTCT_ADD_ID', 'int', 10, 0, 1),
(1222, 'TABL', 'oa_contact_address', 'CNTCT_ADD_ID', 'int', 10, 0, 1),
(1223, 'TABL', 'oa_contact_address', 'OA_ID', 'int', 10, 0, 1),
(1224, 'TABL', 'oa_contact_address', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1225, 'TABL', 'oa_contact_address', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(1226, 'TABL', 'oa_contact_address', 'CREATED_BY', 'int', 10, 0, 1),
(1227, 'TABL', 'oa_contact_address', 'UPDATED_BY', 'int', 10, 0, 1),
(1228, 'TABL', 'oa_contact_address', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1229, 'TABL', 'oa_contact_address', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1230, 'TABL', 'oa_contact_emails', 'OA_CNTCT_EML_ID', 'int', 10, 0, 1),
(1231, 'TABL', 'oa_contact_emails', 'CNTCT_EML_ID', 'int', 10, 0, 1),
(1232, 'TABL', 'oa_contact_emails', 'OA_ID', 'int', 10, 0, 1),
(1233, 'TABL', 'oa_contact_emails', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1234, 'TABL', 'oa_contact_emails', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(1235, 'TABL', 'oa_contact_emails', 'CREATED_BY', 'int', 10, 0, 1),
(1236, 'TABL', 'oa_contact_emails', 'UPDATED_BY', 'int', 10, 0, 1),
(1237, 'TABL', 'oa_contact_emails', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1238, 'TABL', 'oa_contact_emails', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1239, 'TABL', 'oa_contact_nationality', 'OA_CNTCT_NATIONALITY_ID', 'int', 10, 0, 1),
(1240, 'TABL', 'oa_contact_nationality', 'CNTCT_NATIONALITY_ID', 'int', 10, 0, 1),
(1241, 'TABL', 'oa_contact_nationality', 'OA_ID', 'int', 10, 0, 1),
(1242, 'TABL', 'oa_contact_nationality', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1243, 'TABL', 'oa_contact_nationality', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1244, 'TABL', 'oa_contact_nationality', 'CREATED_BY', 'int', 10, 0, 1),
(1245, 'TABL', 'oa_contact_nationality', 'UPDATED_BY', 'int', 10, 0, 1),
(1246, 'TABL', 'oa_contact_nationality', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1247, 'TABL', 'oa_contact_nationality', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1248, 'TABL', 'oa_contact_phones', 'OA_CNTCT_PHONE_ID', 'int', 10, 0, 1),
(1249, 'TABL', 'oa_contact_phones', 'CNTCT_PHONE_ID', 'int', 10, 0, 1),
(1250, 'TABL', 'oa_contact_phones', 'OA_ID', 'int', 10, 0, 1),
(1251, 'TABL', 'oa_contact_phones', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1252, 'TABL', 'oa_contact_phones', 'IS_PRIMARY', 'tinyint', 3, 0, 1),
(1253, 'TABL', 'oa_contact_phones', 'CREATED_BY', 'int', 10, 0, 1),
(1254, 'TABL', 'oa_contact_phones', 'UPDATED_BY', 'int', 10, 0, 1),
(1255, 'TABL', 'oa_contact_phones', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1256, 'TABL', 'oa_contact_phones', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1257, 'TABL', 'oa_contacts', 'OA_CNTCTS_ID', 'int', 10, 0, 1),
(1258, 'TABL', 'oa_contacts', 'OA_CNTCT_RELTYPE_ID', 'int', 10, 0, 1),
(1259, 'TABL', 'oa_contacts', 'CNTCT_ID', 'int', 10, 0, 1),
(1260, 'TABL', 'oa_contacts', 'NON_PRSNL', 'tinyint', 3, 0, 1),
(1261, 'TABL', 'oa_contacts', 'NON_PRSNL_CNTCT_TYP', 'int', 10, 0, 1),
(1262, 'TABL', 'oa_contacts', 'OA_ID', 'int', 10, 0, 1),
(1263, 'TABL', 'oa_contacts', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1264, 'TABL', 'oa_contacts', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1265, 'TABL', 'oa_contacts', 'IS_ACTIVE', 'tinyint', 3, 0, 1),
(1266, 'TABL', 'oa_contacts', 'CREATED_BY', 'int', 10, 0, 1),
(1267, 'TABL', 'oa_contacts', 'UPDATED_BY', 'int', 10, 0, 1),
(1268, 'TABL', 'oa_contacts', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1269, 'TABL', 'oa_contacts', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1270, 'TABL', 'obj_attrbt_previleges', 'OBJ_ATTRBT_PREVILEGES_ID', 'int', 10, 0, 1),
(1271, 'TABL', 'obj_attrbt_previleges', 'OBJ_ID', 'int', 10, 0, 1),
(1272, 'TABL', 'obj_attrbt_previleges', 'OBJ_ATTRBT_ID', 'int', 10, 0, 1),
(1273, 'TABL', 'obj_attrbt_previleges', 'OA_ID', 'int', 10, 0, 1),
(1274, 'TABL', 'obj_attrbt_previleges', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1275, 'TABL', 'obj_attrbt_previleges', 'USER_ID', 'int', 10, 0, 1),
(1276, 'TABL', 'obj_attrbt_previleges', 'CREATED_BY', 'int', 10, 0, 1),
(1277, 'TABL', 'obj_attrbt_previleges', 'UPDATED_BY', 'int', 10, 0, 1),
(1278, 'TABL', 'obj_attrbt_previleges', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1279, 'TABL', 'obj_attrbt_previleges', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1280, 'TABL', 'obj_layer_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1281, 'TABL', 'obj_layer_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(1282, 'TABL', 'obj_layer_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(1283, 'TABL', 'obj_layer_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(1284, 'TABL', 'obj_layer_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(1285, 'TABL', 'obj_layer_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1286, 'TABL', 'obj_layer_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1287, 'TABL', 'obj_layer_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1288, 'TABL', 'obj_layer_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1289, 'TABL', 'obj_layer_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1290, 'TABL', 'obj_layer_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1291, 'TABL', 'obj_layer_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1292, 'TABL', 'org_accounts', 'OA_ID', 'int', 10, 0, 1),
(1293, 'TABL', 'org_accounts', 'OA_CD', 'varchar', 5, NULL, 1),
(1294, 'TABL', 'org_accounts', 'OA_NM', 'varchar', 40, NULL, 1),
(1295, 'TABL', 'org_accounts', 'OA_EMAIL', 'varchar', 40, NULL, 1),
(1296, 'TABL', 'org_accounts', 'OA_WEB_DOMAIN', 'varchar', 40, NULL, 1),
(1297, 'TABL', 'org_accounts', 'OA_CONTACT_NO', 'varchar', 40, NULL, 1),
(1298, 'TABL', 'org_accounts', 'OA_STATUS_ID', 'int', 10, 0, 1),
(1299, 'TABL', 'org_accounts', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1300, 'TABL', 'org_accounts', 'UPDATED_ON', 'timestamp', NULL, NULL, 1),
(1301, 'TABL', 'org_accounts', 'CREATED_BY', 'int', 10, 0, 1),
(1302, 'TABL', 'org_accounts', 'UPDATED_BY', 'int', 10, 0, 1),
(1303, 'TABL', 'orgacct_settings_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1304, 'TABL', 'orgacct_settings_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1305, 'TABL', 'orgacct_settings_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1306, 'TABL', 'orgacct_settings_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1307, 'TABL', 'orgacct_settings_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1308, 'TABL', 'orgacct_settings_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1309, 'TABL', 'orgacct_settings_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1310, 'TABL', 'orgacct_settings_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1311, 'TABL', 'orgacct_settings_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1312, 'TABL', 'orgacct_settings_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1313, 'TABL', 'orgacct_settings_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1314, 'TABL', 'orgacct_settings_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1315, 'TABL', 'permission_dtl', 'PERMISSIONS_DTL_ID', 'int', 10, 0, 1),
(1316, 'TABL', 'permission_dtl', 'PERMISSIONS_REF_TYPE_ID', 'int', 10, 0, 1),
(1317, 'TABL', 'permission_dtl', 'PERMISSIONS_REF_ID', 'int', 10, 0, 1),
(1318, 'TABL', 'permission_dtl', 'PERMISSIONS_ID', 'int', 10, 0, 1),
(1319, 'TABL', 'permission_dtl', 'OBJ_ATTRBT_PREVILEGES_ID', 'int', 10, 0, 1),
(1320, 'TABL', 'permission_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(1321, 'TABL', 'permission_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(1322, 'TABL', 'permission_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1323, 'TABL', 'permission_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1324, 'TABL', 'phone_nbr_mst', 'PHONE_NBR_ID', 'int', 10, 0, 1),
(1325, 'TABL', 'phone_nbr_mst', 'PHONE_NBR', 'varchar', 14, NULL, 1),
(1326, 'TABL', 'phone_nbr_mst', 'PHONE_NBR_TYPE_ID', 'int', 10, 0, 1),
(1327, 'TABL', 'phone_nbr_mst', 'PHONE_COUNTRY_CD', 'varchar', 5, NULL, 1),
(1328, 'TABL', 'phone_nbr_mst', 'PHONE_AREA_CD', 'varchar', 5, NULL, 1),
(1329, 'TABL', 'phone_nbr_mst', 'PHONE_EXCHANGE_NBR', 'varchar', 5, NULL, 1),
(1330, 'TABL', 'phone_nbr_mst', 'PHONE_LINE_NBR', 'varchar', 6, NULL, 1),
(1331, 'TABL', 'phone_nbr_mst', 'PHONE_EXTN', 'varchar', 5, NULL, 1),
(1332, 'TABL', 'phone_nbr_mst', 'IS_FAXNBR', 'tinyint', 3, 0, 1),
(1333, 'TABL', 'phone_nbr_mst', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1334, 'TABL', 'phone_nbr_mst', 'OA_ID_ORIGINATED', 'int', 10, 0, 1),
(1335, 'TABL', 'phone_nbr_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1336, 'TABL', 'phone_nbr_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1337, 'TABL', 'phone_nbr_mst', 'CREATED_ON', 'timestamp', NULL, NULL, 1),
(1338, 'TABL', 'phone_nbr_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1339, 'TABL', 'phone_number_type_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1340, 'TABL', 'phone_number_type_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1341, 'TABL', 'phone_number_type_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1342, 'TABL', 'phone_number_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1343, 'TABL', 'phone_number_type_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1344, 'TABL', 'phone_number_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1345, 'TABL', 'phone_number_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1346, 'TABL', 'phone_number_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1347, 'TABL', 'phone_number_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1348, 'TABL', 'phone_number_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1349, 'TABL', 'phone_number_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1350, 'TABL', 'phone_number_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1351, 'TABL', 'phone_number_type_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1352, 'TABL', 'postcode_mst', 'POSTCODE_ID', 'int', 10, 0, 1),
(1353, 'TABL', 'postcode_mst', 'POSTCODE_PREFIX', 'varchar', 4, NULL, 1),
(1354, 'TABL', 'postcode_mst', 'POSTCODE_SUFFIX', 'varchar', 4, NULL, 1),
(1355, 'TABL', 'postcode_mst', 'POSTCODE', 'varchar', 9, NULL, 1),
(1356, 'TABL', 'postcode_mst', 'COUNTRY_ID', 'int', 10, 0, 1),
(1357, 'TABL', 'postcode_mst', 'COUNTY_STATE_ID', 'int', 10, 0, 1),
(1358, 'TABL', 'postcode_mst', 'TIME_ZONE_ID', 'int', 10, 0, 1),
(1359, 'TABL', 'postcode_mst', 'OA_ID', 'int', 10, 0, 1),
(1360, 'TABL', 'postcode_mst', 'ISDELETED', 'tinyint', 3, 0, 1),
(1361, 'TABL', 'postcode_mst', 'CREATEDBY', 'int', 10, 0, 1),
(1362, 'TABL', 'postcode_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(1363, 'TABL', 'postcode_mst', 'CREATEDON', 'datetime', NULL, NULL, 1),
(1364, 'TABL', 'postcode_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(1365, 'TABL', 'prcss_obj_type_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1366, 'TABL', 'prcss_obj_type_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(1367, 'TABL', 'prcss_obj_type_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(1368, 'TABL', 'prcss_obj_type_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(1369, 'TABL', 'prcss_obj_type_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(1370, 'TABL', 'prcss_obj_type_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1371, 'TABL', 'prcss_obj_type_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1372, 'TABL', 'prcss_obj_type_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1373, 'TABL', 'prcss_obj_type_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1374, 'TABL', 'prcss_obj_type_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1375, 'TABL', 'prcss_obj_type_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1376, 'TABL', 'prcss_obj_type_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1377, 'TABL', 'prsnttn_layer_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1378, 'TABL', 'prsnttn_layer_obj_mst_vw', 'TYP_CD', 'varchar', 5, NULL, 1),
(1379, 'TABL', 'prsnttn_layer_obj_mst_vw', 'TYP_NM', 'varchar', 40, NULL, 1),
(1380, 'TABL', 'prsnttn_layer_obj_mst_vw', 'VIEW_NM', 'varchar', 40, NULL, 1),
(1381, 'TABL', 'prsnttn_layer_obj_mst_vw', 'PARENT_TYP_ID', 'int', 10, 0, 1),
(1382, 'TABL', 'prsnttn_layer_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1383, 'TABL', 'prsnttn_layer_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1384, 'TABL', 'prsnttn_layer_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1385, 'TABL', 'prsnttn_layer_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1386, 'TABL', 'prsnttn_layer_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1387, 'TABL', 'prsnttn_layer_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1388, 'TABL', 'prsnttn_layer_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1389, 'TABL', 'race_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1390, 'TABL', 'race_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1391, 'TABL', 'race_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1392, 'TABL', 'race_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1393, 'TABL', 'race_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1394, 'TABL', 'race_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1395, 'TABL', 'race_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1396, 'TABL', 'race_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1397, 'TABL', 'race_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1398, 'TABL', 'race_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1399, 'TABL', 'race_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1400, 'TABL', 'race_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1401, 'TABL', 'race_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1402, 'TABL', 'relationship_dtl', 'REL_DET_ID', 'int', 10, 0, 1),
(1403, 'TABL', 'relationship_dtl', 'HIER_LEVEL_CONFIG_ID', 'int', 10, 0, 1),
(1404, 'TABL', 'relationship_dtl', 'CHILD_ID', 'int', 10, 0, 1),
(1405, 'TABL', 'relationship_dtl', 'PARENT_ID', 'int', 10, 0, 1),
(1406, 'TABL', 'relationship_dtl', 'HIER_TYPE_ID', 'int', 10, 0, 1),
(1407, 'TABL', 'relationship_dtl', 'HIER_CHILD_ENTITY_TYPE_ID', 'int', 10, 0, 1),
(1408, 'TABL', 'relationship_dtl', 'HIER_PARENT_ENTITY_TYPE_ID', 'int', 10, 0, 1),
(1409, 'TABL', 'relationship_dtl', 'LEVEL_SEQ', 'int', 10, 0, 1),
(1410, 'TABL', 'relationship_dtl', 'OA_ID', 'int', 10, 0, 1),
(1411, 'TABL', 'relationship_dtl', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1412, 'TABL', 'relationship_dtl', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1413, 'TABL', 'relationship_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(1414, 'TABL', 'relationship_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(1415, 'TABL', 'relationship_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1416, 'TABL', 'relationship_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1417, 'TABL', 'relegion_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1418, 'TABL', 'relegion_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1419, 'TABL', 'relegion_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1420, 'TABL', 'relegion_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1421, 'TABL', 'relegion_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1422, 'TABL', 'relegion_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1423, 'TABL', 'relegion_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1424, 'TABL', 'relegion_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1425, 'TABL', 'relegion_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1426, 'TABL', 'relegion_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1427, 'TABL', 'relegion_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1428, 'TABL', 'relegion_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1429, 'TABL', 'relegion_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1430, 'TABL', 'role_mst', 'ROLE_ID', 'int', 10, 0, 1),
(1431, 'TABL', 'role_mst', 'ROLE_NM', 'varchar', 40, NULL, 1),
(1432, 'TABL', 'role_mst', 'ROLE_DSCRPTN', 'varchar', 255, NULL, 1),
(1433, 'TABL', 'role_mst', 'DMN_ID', 'int', 10, 0, 1),
(1434, 'TABL', 'role_mst', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1435, 'TABL', 'role_mst', 'IS_ADMIN_ROLE', 'tinyint', 3, 0, 1),
(1436, 'TABL', 'role_mst', 'IS_ASSIGNABLE', 'tinyint', 3, 0, 1),
(1437, 'TABL', 'role_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1438, 'TABL', 'role_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1439, 'TABL', 'role_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1440, 'TABL', 'role_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1441, 'TABL', 'role_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1442, 'TABL', 'salutation_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1443, 'TABL', 'salutation_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1444, 'TABL', 'salutation_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1445, 'TABL', 'salutation_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1446, 'TABL', 'salutation_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1447, 'TABL', 'salutation_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1448, 'TABL', 'salutation_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1449, 'TABL', 'salutation_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1450, 'TABL', 'salutation_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1451, 'TABL', 'salutation_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1452, 'TABL', 'salutation_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1453, 'TABL', 'salutation_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1454, 'TABL', 'salutation_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1455, 'TABL', 'shift_mst', 'SHIFT_ID', 'int', 10, 0, 1),
(1456, 'TABL', 'shift_mst', 'NAME', 'varchar', 250, NULL, 1),
(1457, 'TABL', 'shift_mst', 'HOURS_PER_DAY', 'decimal', 4, 2, 1),
(1458, 'TABL', 'shift_mst', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1459, 'TABL', 'shift_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1460, 'TABL', 'shift_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1461, 'TABL', 'shift_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1462, 'TABL', 'shift_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1463, 'TABL', 'state_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1);
INSERT INTO `entity_obj_tmp` (`TMP_OBJ_ID`, `OBJ_TYP`, `OBJ_NM`, `OBJ_ATTRBT_NM`, `OBJ_ATTRBT_DT_TYP`, `OBJ_SZ`, `OBJ_PRCSN`, `OBJ_NW_RCRD_FLG`) VALUES
(1464, 'TABL', 'state_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1465, 'TABL', 'state_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1466, 'TABL', 'state_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1467, 'TABL', 'state_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1468, 'TABL', 'state_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1469, 'TABL', 'state_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1470, 'TABL', 'state_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1471, 'TABL', 'state_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1472, 'TABL', 'state_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1473, 'TABL', 'state_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1474, 'TABL', 'state_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1475, 'TABL', 'state_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1476, 'TABL', 'street_mst', 'STREET_ID', 'int', 10, 0, 1),
(1477, 'TABL', 'street_mst', 'STREET_NAME', 'varchar', 40, NULL, 1),
(1478, 'TABL', 'street_mst', 'LOCALITY', 'varchar', 40, NULL, 1),
(1479, 'TABL', 'street_mst', 'AREA', 'varchar', 40, NULL, 1),
(1480, 'TABL', 'street_mst', 'TOWN_ID', 'int', 10, 0, 1),
(1481, 'TABL', 'street_mst', 'CENSUS_BLOCK_ID', 'int', 10, 0, 1),
(1482, 'TABL', 'street_mst', 'CITY_ID', 'int', 10, 0, 1),
(1483, 'TABL', 'street_mst', 'TERRITORY_ID', 'int', 10, 0, 1),
(1484, 'TABL', 'street_mst', 'DISTRICT_ID', 'int', 10, 0, 1),
(1485, 'TABL', 'street_mst', 'POSTCODE_ID', 'int', 10, 0, 1),
(1486, 'TABL', 'street_mst', 'OA_ID', 'int', 10, 0, 1),
(1487, 'TABL', 'street_mst', 'COURIER_ROUTE_DESC', 'varchar', 100, NULL, 1),
(1488, 'TABL', 'street_mst', 'ISDELETED', 'tinyint', 3, 0, 1),
(1489, 'TABL', 'street_mst', 'CREATEDBY', 'int', 10, 0, 1),
(1490, 'TABL', 'street_mst', 'UPDATEDBY', 'int', 10, 0, 1),
(1491, 'TABL', 'street_mst', 'CREATEDON', 'datetime', NULL, NULL, 1),
(1492, 'TABL', 'street_mst', 'UPDATEDON', 'datetime', NULL, NULL, 1),
(1493, 'TABL', 'subdept_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1494, 'TABL', 'subdept_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1495, 'TABL', 'subdept_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1496, 'TABL', 'subdept_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1497, 'TABL', 'subdept_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1498, 'TABL', 'subdept_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1499, 'TABL', 'subdept_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1500, 'TABL', 'subdept_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1501, 'TABL', 'subdept_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1502, 'TABL', 'subdept_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1503, 'TABL', 'subdept_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1504, 'TABL', 'subdept_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1505, 'TABL', 'subdept_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1506, 'TABL', 'sw_app_hier_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1507, 'TABL', 'sw_app_hier_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1508, 'TABL', 'sw_app_hier_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1509, 'TABL', 'sw_app_hier_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1510, 'TABL', 'sw_app_hier_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1511, 'TABL', 'sw_app_hier_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1512, 'TABL', 'sw_app_hier_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1513, 'TABL', 'sw_app_hier_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1514, 'TABL', 'sw_app_hier_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1515, 'TABL', 'sw_app_hier_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1516, 'TABL', 'sw_app_hier_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1517, 'TABL', 'sw_app_hier_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1518, 'TABL', 'sw_app_hier_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1519, 'TABL', 'systempermisiontype_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1520, 'TABL', 'systempermisiontype_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1521, 'TABL', 'systempermisiontype_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1522, 'TABL', 'systempermisiontype_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1523, 'TABL', 'systempermisiontype_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1524, 'TABL', 'systempermisiontype_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1525, 'TABL', 'systempermisiontype_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1526, 'TABL', 'systempermisiontype_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1527, 'TABL', 'systempermisiontype_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1528, 'TABL', 'systempermisiontype_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1529, 'TABL', 'systempermisiontype_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1530, 'TABL', 'systempermisiontype_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1531, 'TABL', 'systm_glssry', 'GLSSRY_ID', 'int', 10, 0, 1),
(1532, 'TABL', 'systm_glssry', 'GLSSRY_CD', 'varchar', 10, NULL, 1),
(1533, 'TABL', 'systm_glssry', 'GLSSRY_MNNG', 'varchar', 25, NULL, 1),
(1534, 'TABL', 'systm_glssry', 'GLSSRY_DSCRPTN', 'varchar', 100, NULL, 1),
(1535, 'TABL', 'systm_lst_dtl', 'TBL_NM', 'varchar', 50, NULL, 1),
(1536, 'TABL', 'systm_lst_dtl', 'LST_NMBR', 'int', 10, 0, 1),
(1537, 'TABL', 'theme_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1538, 'TABL', 'theme_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1539, 'TABL', 'theme_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1540, 'TABL', 'theme_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1541, 'TABL', 'theme_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1542, 'TABL', 'theme_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1543, 'TABL', 'theme_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1544, 'TABL', 'theme_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1545, 'TABL', 'theme_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1546, 'TABL', 'theme_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1547, 'TABL', 'theme_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1548, 'TABL', 'theme_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1549, 'TABL', 'theme_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1550, 'TABL', 'timezone_mst', 'TIME_ZONE_ID', 'int', 10, 0, 1),
(1551, 'TABL', 'timezone_mst', 'TIMEZONE', 'varchar', 4, NULL, 1),
(1552, 'TABL', 'timezone_mst', 'TIMEZONE_TYPE_ID', 'int', 10, 0, 1),
(1553, 'TABL', 'timezone_mst', 'ISDELETED', 'tinyint', 3, 0, 1),
(1554, 'TABL', 'timezone_mst', 'CREATEDBY', 'int', 10, 0, 1),
(1555, 'TABL', 'timezone_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1556, 'TABL', 'timezone_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1557, 'TABL', 'timezone_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1558, 'TABL', 'toolbar_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1559, 'TABL', 'toolbar_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1560, 'TABL', 'toolbar_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1561, 'TABL', 'toolbar_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1562, 'TABL', 'toolbar_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1563, 'TABL', 'toolbar_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1564, 'TABL', 'toolbar_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1565, 'TABL', 'toolbar_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1566, 'TABL', 'toolbar_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1567, 'TABL', 'toolbar_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1568, 'TABL', 'toolbar_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1569, 'TABL', 'toolbar_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1570, 'TABL', 'town_name_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1571, 'TABL', 'town_name_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1572, 'TABL', 'town_name_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1573, 'TABL', 'town_name_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1574, 'TABL', 'town_name_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1575, 'TABL', 'town_name_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1576, 'TABL', 'town_name_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1577, 'TABL', 'town_name_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1578, 'TABL', 'town_name_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1579, 'TABL', 'town_name_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1580, 'TABL', 'town_name_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1581, 'TABL', 'town_name_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1582, 'TABL', 'town_name_mst_vw', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1583, 'TABL', 'user_contact_type_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1584, 'TABL', 'user_contact_type_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1585, 'TABL', 'user_contact_type_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1586, 'TABL', 'user_contact_type_vw', 'TYP_ID', 'int', 10, 0, 1),
(1587, 'TABL', 'user_contact_type_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1588, 'TABL', 'user_contact_type_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1589, 'TABL', 'user_contact_type_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1590, 'TABL', 'user_contact_type_vw', 'OA_ID', 'int', 10, 0, 1),
(1591, 'TABL', 'user_contact_type_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1592, 'TABL', 'user_contact_type_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1593, 'TABL', 'user_contact_type_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1594, 'TABL', 'user_contact_type_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1595, 'TABL', 'user_contacts', 'USER_CNTCT_ID', 'int', 10, 0, 1),
(1596, 'TABL', 'user_contacts', 'USER_ID', 'int', 10, 0, 1),
(1597, 'TABL', 'user_contacts', 'CNTCT_ID', 'int', 10, 0, 1),
(1598, 'TABL', 'user_contacts', 'USER_CNTCT_TYPE_ID', 'int', 10, 0, 1),
(1599, 'TABL', 'user_contacts', 'EXT_REF_NBR', 'varchar', 40, NULL, 1),
(1600, 'TABL', 'user_contacts', 'CREATED_BY', 'int', 10, 0, 1),
(1601, 'TABL', 'user_contacts', 'UPDATED_BY', 'int', 10, 0, 1),
(1602, 'TABL', 'user_contacts', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1603, 'TABL', 'user_contacts', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1604, 'TABL', 'user_domain', 'DMN_ID', 'int', 10, 0, 1),
(1605, 'TABL', 'user_domain', 'DMN_NM', 'varchar', 40, NULL, 1),
(1606, 'TABL', 'user_domain', 'DSCRPTN', 'varchar', 100, NULL, 1),
(1607, 'TABL', 'user_domain', 'OA_ID', 'int', 10, 0, 1),
(1608, 'TABL', 'user_domain', 'OA_BRAND_ID', 'int', 10, 0, 1),
(1609, 'TABL', 'user_domain', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1610, 'TABL', 'user_domain', 'CREATED_BY', 'int', 10, 0, 1),
(1611, 'TABL', 'user_domain', 'UPDATED_BY', 'int', 10, 0, 1),
(1612, 'TABL', 'user_domain', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1613, 'TABL', 'user_domain', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1614, 'TABL', 'user_group', 'USER_GRP_ID', 'int', 10, 0, 1),
(1615, 'TABL', 'user_group', 'USER_GRP_NM', 'varchar', 40, NULL, 1),
(1616, 'TABL', 'user_group', 'DMN_ID', 'int', 10, 0, 1),
(1617, 'TABL', 'user_group', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1618, 'TABL', 'user_group', 'CREATED_BY', 'int', 10, 0, 1),
(1619, 'TABL', 'user_group', 'UPDATED_BY', 'int', 10, 0, 1),
(1620, 'TABL', 'user_group', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1621, 'TABL', 'user_group', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1622, 'TABL', 'user_group_dtl', 'USER_GRP_DTL_ID', 'int', 10, 0, 1),
(1623, 'TABL', 'user_group_dtl', 'USER_GRP_ID', 'int', 10, 0, 1),
(1624, 'TABL', 'user_group_dtl', 'USER_ID', 'int', 10, 0, 1),
(1625, 'TABL', 'user_group_dtl', 'CREATED_BY', 'int', 10, 0, 1),
(1626, 'TABL', 'user_group_dtl', 'UPDATED_BY', 'int', 10, 0, 1),
(1627, 'TABL', 'user_group_dtl', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1628, 'TABL', 'user_group_dtl', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1629, 'TABL', 'user_mst', 'USER_ID', 'int', 10, 0, 1),
(1630, 'TABL', 'user_mst', 'USER_NAME', 'varchar', 40, NULL, 1),
(1631, 'TABL', 'user_mst', 'REG_EMAIL_ID', 'varchar', 40, NULL, 1),
(1632, 'TABL', 'user_mst', 'PASSWORD', 'varchar', 40, NULL, 1),
(1633, 'TABL', 'user_mst', 'USER_STATUS_ID', 'int', 10, 0, 1),
(1634, 'TABL', 'user_mst', 'EXT_REF_NBR', 'varchar', 40, NULL, 1),
(1635, 'TABL', 'user_mst', 'LAST_LOGIN_AT', 'datetime', NULL, NULL, 1),
(1636, 'TABL', 'user_mst', 'DMN_ID', 'int', 10, 0, 1),
(1637, 'TABL', 'user_mst', 'ACTIVATION', 'varchar', 100, NULL, 1),
(1638, 'TABL', 'user_mst', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1639, 'TABL', 'user_mst', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1640, 'TABL', 'user_mst', 'IS_ADMIN', 'tinyint', 3, 0, 1),
(1641, 'TABL', 'user_mst', 'IS_ASSIGNABLE', 'tinyint', 3, 0, 1),
(1642, 'TABL', 'user_mst', 'IS_PREDEFINED', 'tinyint', 3, 0, 1),
(1643, 'TABL', 'user_mst', 'CREATED_BY', 'int', 10, 0, 1),
(1644, 'TABL', 'user_mst', 'UPDATED_BY', 'int', 10, 0, 1),
(1645, 'TABL', 'user_mst', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1646, 'TABL', 'user_mst', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1647, 'TABL', 'user_role', 'USER_ROLE_ID', 'int', 10, 0, 1),
(1648, 'TABL', 'user_role', 'ROLE_ID', 'int', 10, 0, 1),
(1649, 'TABL', 'user_role', 'USER_ID', 'int', 10, 0, 1),
(1650, 'TABL', 'user_role', 'CREATED_BY', 'int', 10, 0, 1),
(1651, 'TABL', 'user_role', 'UPDATED_BY', 'int', 10, 0, 1),
(1652, 'TABL', 'user_role', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1653, 'TABL', 'user_role', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1654, 'TABL', 'user_status_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1655, 'TABL', 'user_status_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1656, 'TABL', 'user_status_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1657, 'TABL', 'user_status_vw', 'TYP_ID', 'int', 10, 0, 1),
(1658, 'TABL', 'user_status_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1659, 'TABL', 'user_status_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1660, 'TABL', 'user_status_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1661, 'TABL', 'user_status_vw', 'OA_ID', 'int', 10, 0, 1),
(1662, 'TABL', 'user_status_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1663, 'TABL', 'user_status_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1664, 'TABL', 'user_status_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1665, 'TABL', 'user_status_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1666, 'TABL', 'view_obj_mst_vw', 'MSTR_ID', 'int', 10, 0, 1),
(1667, 'TABL', 'view_obj_mst_vw', 'MSTR_CD', 'varchar', 10, NULL, 1),
(1668, 'TABL', 'view_obj_mst_vw', 'MSTR_NM', 'varchar', 40, NULL, 1),
(1669, 'TABL', 'view_obj_mst_vw', 'TYP_ID', 'int', 10, 0, 1),
(1670, 'TABL', 'view_obj_mst_vw', 'RECORD_TYP', 'int', 10, 0, 1),
(1671, 'TABL', 'view_obj_mst_vw', 'IS_EDITABLE', 'tinyint', 3, 0, 1),
(1672, 'TABL', 'view_obj_mst_vw', 'IS_DELETED', 'tinyint', 3, 0, 1),
(1673, 'TABL', 'view_obj_mst_vw', 'OA_ID', 'int', 10, 0, 1),
(1674, 'TABL', 'view_obj_mst_vw', 'CREATED_BY', 'int', 10, 0, 1),
(1675, 'TABL', 'view_obj_mst_vw', 'UPDATED_BY', 'int', 10, 0, 1),
(1676, 'TABL', 'view_obj_mst_vw', 'CREATED_ON', 'datetime', NULL, NULL, 1),
(1677, 'TABL', 'view_obj_mst_vw', 'UPDATED_ON', 'datetime', NULL, NULL, 1),
(1678, 'typ2', 'num2', 'atrr_num2', 'det2', 11, 2, 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `entity_obj_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `entity_obj_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `epic_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `epic_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `ethinicity_mst_vw`
--
CREATE TABLE IF NOT EXISTS `ethinicity_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `exception_log`
--

CREATE TABLE IF NOT EXISTS `exception_log` (
  `EXCEPTION_LOG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Exception log id. This is a primary key of the table. It is a auto generated sequence number',
  `EXCEPTION_TYPE_ID` int(10) DEFAULT NULL COMMENT 'Exception type. This is master information coming from independent master entity. The values would be information, warning or error',
  `SESSION_ID` varchar(500) DEFAULT NULL COMMENT 'User session id',
  `APP_ID` int(10) DEFAULT NULL COMMENT 'Source application logging the error',
  `MODULE_ID` int(10) DEFAULT NULL COMMENT 'Source module logging the error',
  `PROCESS_ID` int(10) DEFAULT NULL COMMENT 'Source process logging the error',
  `LOCATION_NO` int(10) DEFAULT NULL COMMENT 'Source location logging the error',
  `ERROR_NBR` int(10) DEFAULT NULL COMMENT 'Exception number',
  `ERROR_DESC` varchar(4000) DEFAULT NULL COMMENT 'Error description',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Source organisation account id',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Source organisation brand',
  `ERROR_STACK` varchar(4000) DEFAULT NULL COMMENT 'Error stack enables the developer to readily drill down into errors. This can quickly show you where the problem originated, and will help you to walk the call tree back to where the error condition began. Developers may also find it useful to include when reporting errors that occurred on the site post-deployment, in client-facing scenarios that are typically more difficult to track on the server.',
  `CALL_STACK` varchar(4000) DEFAULT NULL COMMENT 'A call stack is a stack data structure that stores information about the active subroutines of a computer program. This kind of stack is also known as an execution stack, control stack, run-time stack, or machine stack. A call stack is used to keep track of the point to which each active subroutine should return control when it finishes executing',
  `MESSAGE_LEVEL` int(10) DEFAULT NULL COMMENT 'Message severity levels',
  `MSG_ID` int(10) DEFAULT NULL COMMENT 'Customised message id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'Created by user id',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the logged exception',
  PRIMARY KEY (`EXCEPTION_LOG_ID`),
  KEY `FK_EXCEPTIONLOG_EXCEPTIONTYPEID` (`EXCEPTION_TYPE_ID`),
  KEY `FK_EXCEPTIONLOG_APPID` (`APP_ID`),
  KEY `FK_EXCEPTIONLOG_MODULEID` (`MODULE_ID`),
  KEY `FK_EXCEPTIONLOG_PROCESSID` (`PROCESS_ID`),
  KEY `FK_EXCEPTIONLOG_MSGID` (`MSG_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores all the details of an exception messages of the system. The information maintained in the table are of 3 types, Information (I), Error (E), and Warnings (W)' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exception_log`
--

INSERT INTO `exception_log` (`EXCEPTION_LOG_ID`, `EXCEPTION_TYPE_ID`, `SESSION_ID`, `APP_ID`, `MODULE_ID`, `PROCESS_ID`, `LOCATION_NO`, `ERROR_NBR`, `ERROR_DESC`, `OA_ID`, `OA_BRAND_ID`, `ERROR_STACK`, `CALL_STACK`, `MESSAGE_LEVEL`, `MSG_ID`, `CREATED_BY`, `CREATED_ON`) VALUES
(1, 2, '2', 3, 4, 5, 2, 2, '2', 2, 2, '2', '2', 2, 1, NULL, '2014-04-07 09:47:42');

-- --------------------------------------------------------

--
-- Stand-in structure for view `exception_message_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `exception_message_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `exe_mngmnt_mst_vw`
--
CREATE TABLE IF NOT EXISTS `exe_mngmnt_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `feature_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `feature_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `form_mst_vw`
--
CREATE TABLE IF NOT EXISTS `form_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `gender_mst_vw`
--
CREATE TABLE IF NOT EXISTS `gender_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `geo_hier_mst_vw`
--
CREATE TABLE IF NOT EXISTS `geo_hier_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `global_setting_item_mst_vw`
--
CREATE TABLE IF NOT EXISTS `global_setting_item_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `group_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `group_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `group_role`
--

CREATE TABLE IF NOT EXISTS `group_role` (
  `GRP_ROLE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for group Role. It is a Auto generated primary key column',
  `ROLE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Role master table',
  `USER_GRP_ID` int(10) NOT NULL COMMENT 'Id of an user group assigned with group role',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`GRP_ROLE_ID`),
  UNIQUE KEY `UK_GROUPROLE_ROLEIDUSERGRPID` (`ROLE_ID`,`USER_GRP_ID`),
  KEY `FK_GROUPROLE_USERGRPID` (`USER_GRP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This Stores the Master Data definitions of all the Groups Roles' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `gsdatavaluetype_mst_vw`
--
CREATE TABLE IF NOT EXISTS `gsdatavaluetype_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `hierarchy_type_vw`
--
CREATE TABLE IF NOT EXISTS `hierarchy_type_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `hier_level_config`
--

CREATE TABLE IF NOT EXISTS `hier_level_config` (
  `HIER_LEVEL_CONFIG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'This is the unique primary key of the table. Its an auto generated number',
  `HIER_TYPE_ID` int(10) NOT NULL COMMENT 'Hierarchy type ID is the ID Related to various hierarchy types. The examples of a hierarchy types are Company Hierarchy, Geographical Hierarchy, Management Hierarchy, Application Hierarchy, Menu hierarchy etc',
  `HIER_CHILD_ENTITY_TYPE_ID` int(10) NOT NULL COMMENT 'This is the ID of the Element of the Hierarchy  type. Company hierarchy is made up of elements such as company, dept sub dept etc. ',
  `HIER_PARENT_ENTITY_TYPE_ID` int(10) NOT NULL COMMENT 'This indicates the parent element type of the hierarchy',
  `LEVEL_SEQ` int(10) NOT NULL COMMENT 'This is an Free flow user text field which will dictate the level of the elements in the given hierarchy',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account ID',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `IS_EDITABLE` tinyint(1) DEFAULT '1' COMMENT 'Flag to mark the record editable. True means editable, false means non editable',
  `IS_PREDEFINED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark that the role is a predefined system value',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark the hierarchy for deletion',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'Created by user name',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'updated by user name',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was updated',
  PRIMARY KEY (`HIER_LEVEL_CONFIG_ID`),
  KEY `FK_HIERLEVELCONFIG_HIERTYPEID` (`HIER_TYPE_ID`),
  KEY `FK_HIERLEVELCONFIG_HIERENTITYTYPEID` (`HIER_CHILD_ENTITY_TYPE_ID`),
  KEY `FK_HIERLEVELCONFIG_HIERENTITYPARENTTYPEID` (`HIER_PARENT_ENTITY_TYPE_ID`),
  KEY `FK_HIERLEVELCONFIG_OAID` (`OA_ID`),
  KEY `FK_HIERLEVELCONFIG_OABRANDID` (`OA_BRAND_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This entity stores the Hireachy level configurations. ' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hier_level_config`
--

INSERT INTO `hier_level_config` (`HIER_LEVEL_CONFIG_ID`, `HIER_TYPE_ID`, `HIER_CHILD_ENTITY_TYPE_ID`, `HIER_PARENT_ENTITY_TYPE_ID`, `LEVEL_SEQ`, `OA_ID`, `OA_BRAND_ID`, `IS_EDITABLE`, `IS_PREDEFINED`, `IS_DELETED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(3, 74, 75, 0, 1, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL),
(4, 74, 76, 75, 2, NULL, NULL, 1, 0, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `hod_mst_vw`
--
CREATE TABLE IF NOT EXISTS `hod_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `holiday_mst`
--

CREATE TABLE IF NOT EXISTS `holiday_mst` (
  `HOLIDAY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'A flag to mark a record for recurring holiday the value can be true or false the default value is false',
  `RECURRING` tinyint(1) NOT NULL COMMENT 'A flag to mark a record for recurring holiday the value can be true or false the default value is false',
  `LENGTH` int(10) DEFAULT '0' COMMENT 'Holiday Length',
  `OPERATIONAL_COUNTRY_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from Operional conutry master table',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`HOLIDAY_ID`),
  KEY `FK_HOLIDAYMST_OPERATIONALCOUNTRYID` (`OPERATIONAL_COUNTRY_ID`),
  KEY `FK_HOLIDAYMST_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_HOLIDAYMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_HOLIDAYMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the  Data definitions of employees holidays' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `independent_mst`
--

CREATE TABLE IF NOT EXISTS `independent_mst` (
  `MSTR_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Master data identifier',
  `MSTR_CD` varchar(10) DEFAULT NULL COMMENT 'Master data Code. This is an optional field',
  `MSTR_NM` varchar(40) NOT NULL COMMENT 'Master Data Name. This is a mandatory field',
  `TYP_ID` int(10) NOT NULL COMMENT 'Defining the parent type associated with the master data set',
  `RECORD_TYP` int(10) DEFAULT NULL COMMENT 'Indiate the type of the record viz. System data or user data. System data record cannnot be edited by the users',
  `IS_EDITABLE` tinyint(1) DEFAULT '1' COMMENT 'Flag to mark the record editable. True means editable, false means non editable',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark the record for soft delete. Once Spft deleted the record willnot be visible to non admin users. Non editable records cannnot be deleted',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Optional Organisation account identifier',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who crrated this record',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated the record',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record is created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'date and time when the record was editable',
  `IS_PREDEFINED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark that the role is a predefined system value',
  PRIMARY KEY (`MSTR_ID`),
  UNIQUE KEY `UK_INDEPENDENTMST_MSTRCDOAID` (`MSTR_CD`,`OA_ID`),
  UNIQUE KEY `UK_INDEPENDENTMST_MSTRNMOAID` (`MSTR_NM`,`OA_ID`),
  KEY `FK_INDEPENDENTMST_TYPID` (`TYP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the common types' AUTO_INCREMENT=544 ;

--
-- Dumping data for table `independent_mst`
--

INSERT INTO `independent_mst` (`MSTR_ID`, `MSTR_CD`, `MSTR_NM`, `TYP_ID`, `RECORD_TYP`, `IS_EDITABLE`, `IS_DELETED`, `OA_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`, `IS_PREDEFINED`) VALUES
(1, 'SPTA', 'Add New', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(2, 'SPTM', 'Modify', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(3, 'SPTD', 'Delete', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(4, 'SPTV', 'View', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(5, 'SPTP', 'Print', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(6, 'SPTE', 'Execute Process', 1, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(7, 'GSDVTB', 'Boolean', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(8, 'GSDVTD', 'Date', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(9, 'GSDVTN', 'Number', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(10, 'GSDVTS', 'String', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(11, 'GSDVTDR', 'DateRange', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(12, 'GSDVTVR', 'ValueRange', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(13, 'GSDVTL', 'List', 2, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(14, 'EMTSIAR', 'Record created successfully', 7, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(15, 'EMTSIUR', 'Record updated successfully', 7, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(16, 'EMTSIDR', 'Record deleted successfully', 7, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(17, 'EMTSEAR', 'Unable to create Record', 9, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(18, 'EMTSEUR', 'Unable to update Record', 9, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(19, 'EMTSEDR', 'Unable to delete Record', 9, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(20, 'EMTSEDRPV', 'Voilation of primary Key. Unable to dele', 9, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(21, 'GGL', 'Geecon Group', 10, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(22, 'GSPL', 'Geecon System Pvt Limited', 11, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(25, 'OASTOATS', 'Org Accounts Thousand Seperator', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(26, 'OASTOADP', 'Org Accounts Decimal Point', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(27, 'OASTODPL', 'Org Accounts Decimal Places', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(28, 'OASTODPR', 'Org Accounts Decimal Precesion', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(29, 'OASTOABC', 'Org Accounts Base Currency', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(30, 'OASTOADN', 'Org Accounts Application Display Name', 41, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(31, 'USA', 'Active', 46, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(32, 'USI', 'Inactive', 46, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(33, 'UCTE', 'Employee', 47, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(34, 'UCTS', 'Supplier', 47, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(35, 'UCTV', 'Vendor', 47, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(36, 'UCTC', 'Customer', 47, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(37, 'GGL', 'Geecon Group', 10, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(38, 'GSPL', 'Geecon System Pvt Limited', 11, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(41, 'GGL', 'Geecon Group', 53, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(42, 'GSPL', 'Geecon System Pvt Limited', 54, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(43, 'MCRS', 'Microsoft', 55, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(52, 'MTSMTP', 'SMTP', 101, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(53, 'ENLA', 'Leave Application', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(54, 'ENLAS', 'Leave Assignments', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(55, 'ENLAP', 'Leave Approvals', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(56, 'ENLC', 'Leave Cancellations', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(57, 'ENLR', 'Leave Rejection', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(58, 'ENPRS', 'Performance Review Submission', 102, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(59, 'CONTEUR', 'Africa', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(60, 'CONTASIA', 'Asia', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(61, 'CONTEUR', 'Europe', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(62, 'CONTNA', 'North America', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(63, 'CONTSA', 'South America', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(64, 'CONTANT', 'Antarctica', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(65, 'CONTAUS', 'Australia', 121, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 1),
(246, 'AED', 'United Arab Emirates dirham', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(247, 'AFN', 'Afghani', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(248, 'ALL', 'Lek', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(249, 'AMD', 'Armenian Dram', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(250, 'ANG', 'Netherlands Antillian Guilder', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(251, 'AOA', 'Kwanza', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(252, 'ARS', 'Argentine Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(253, 'AUD', 'Australian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(254, 'AWG', 'Aruban Guilder', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(255, 'AZN', 'Azerbaijanian Manat', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(256, 'BAM', 'Convertible Marks', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(257, 'BBD', 'Barbados Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(258, 'BDT', 'Bangladeshi Taka', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(259, 'BGN', 'Bulgarian Lev', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(260, 'BHD', 'Bahraini Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(261, 'BIF', 'Burundian Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(262, 'BMD', 'Bermudian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(263, 'BND', 'Brunei Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(264, 'BOB', 'Boliviano', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(265, 'BOV', 'Bolivian Mvdol (Funds code)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(266, 'BRL', 'Brazilian Real', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(267, 'BSD', 'Bahamian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(268, 'BTN', 'Ngultrum', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(269, 'BWP', 'Pula', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(270, 'BYR', 'Belarussian Ruble', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(271, 'BZD', 'Belize Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(272, 'CAD', 'Canadian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(273, 'CDF', 'Franc Congolais', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(274, 'CHE', 'WIR Euro (complementary currency)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(275, 'CHF', 'Swiss Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(276, 'CHW', 'WIR Franc (complementary currency)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(277, 'CLF', 'Unidades de formento (Funds code)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(278, 'CLP', 'Chilean Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(279, 'CNY', 'Yuan Renminbi', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(280, 'COP', 'Colombian Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(281, 'COU', 'Unidad de Valor Real', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(282, 'CRC', 'Costa Rican Colon', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(283, 'CUP', 'Cuban Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(284, 'CVE', 'Cape Verde Escudo', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(285, 'CYP', 'Cyprus Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(286, 'CZK', 'Czech Koruna', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(287, 'DJF', 'Djibouti Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(288, 'DKK', 'Danish Krone', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(289, 'DOP', 'Dominican Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(290, 'DZD', 'Algerian Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(291, 'EEK', 'Kroon', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(292, 'EGP', 'Egyptian Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(293, 'ERN', 'Nakfa', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(294, 'ETB', 'Ethiopian Birr', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(295, 'EUR', 'Euro', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(296, 'FJD', 'Fiji Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(297, 'FKP', 'Falkland Islands Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(298, 'GBP', 'Pound Sterling', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(299, 'GEL', 'Lari', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(300, 'GHS', 'Cedi', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(301, 'GIP', 'Gibraltar pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(302, 'GMD', 'Dalasi', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(303, 'GNF', 'Guinea Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(304, 'GTQ', 'Quetzal', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(305, 'GYD', 'Guyana Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(306, 'HKD', 'Hong Kong Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(307, 'HNL', 'Lempira', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(308, 'HRK', 'Croatian Kuna', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(309, 'HTG', 'Haiti Gourde', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(310, 'HUF', 'Forint', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(311, 'IDR', 'Rupiah', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(312, 'ILS', 'New Israeli Shekel', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(313, 'INR', 'Indian Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(314, 'IQD', 'Iraqi Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(315, 'IRR', 'Iranian Rial', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(316, 'ISK', 'Iceland Krona', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(317, 'JMD', 'Jamaican Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(318, 'JOD', 'Jordanian Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(319, 'JPY', 'Japanese yen', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(320, 'KES', 'Kenyan Shilling', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(321, 'KGS', 'Som', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(322, 'KHR', 'Riel', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(323, 'KMF', 'Comoro Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(324, 'KPW', 'North Korean Won', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(325, 'KRW', 'South Korean Won', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(326, 'KWD', 'Kuwaiti Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(327, 'KYD', 'Cayman Islands Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(328, 'KZT', 'Tenge', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(329, 'LAK', 'Kip', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(330, 'LBP', 'Lebanese Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(331, 'LKR', 'Sri Lanka Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(332, 'LRD', 'Liberian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(333, 'LSL', 'Loti', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(334, 'LTL', 'Lithuanian Litas', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(335, 'LVL', 'Latvian Lats', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(336, 'LYD', 'Libyan Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(337, 'MAD', 'Moroccan Dirham', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(338, 'MDL', 'Moldovan Leu', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(339, 'MGA', 'Malagasy Ariary', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(340, 'MKD', 'Denar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(341, 'MMK', 'Kyat', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(342, 'MNT', 'Tugrik', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(343, 'MOP', 'Pataca', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(344, 'MRO', 'Ouguiya', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(345, 'MTL', 'Maltese Lira', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(346, 'MUR', 'Mauritius Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(347, 'MVR', 'Rufiyaa', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(348, 'MWK', 'Kwacha', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(349, 'MXN', 'Mexican Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(350, 'MYR', 'Malaysian Ringgit', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(351, 'MZN', 'Metical', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(352, 'NAD', 'Namibian Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(353, 'NGN', 'Naira', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(354, 'NIO', 'Cordoba Oro', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(355, 'NOK', 'Norwegian Krone', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(356, 'NPR', 'Nepalese Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(357, 'NZD', 'New Zealand Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(358, 'OMR', 'Rial Omani', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(359, 'PAB', 'Balboa', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(360, 'PEN', 'Nuevo Sol', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(361, 'PGK', 'Kina', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(362, 'PHP', 'Philippine Peso', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(363, 'PKR', 'Pakistan Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(364, 'PLN', 'Zloty', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(365, 'PYG', 'Guarani', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(366, 'QAR', 'Qatari Rial', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(367, 'RON', 'Romanian New Leu', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(368, 'RSD', 'Serbian Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(369, 'RUB', 'Russian Ruble', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(370, 'RWF', 'Rwanda Franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(371, 'SAR', 'Saudi Riyal', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(372, 'SBD', 'Solomon Islands Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(373, 'SCR', 'Seychelles Rupee', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(374, 'SDG', 'Sudanese Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(375, 'SEK', 'Swedish Krona', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(376, 'SGD', 'Singapore Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(377, 'SHP', 'Saint Helena Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(378, 'SKK', 'Slovak Koruna', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(379, 'SLL', 'Leone', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(380, 'SOS', 'Somali Shilling', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(381, 'SRD', 'Surinam Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(382, 'STD', 'Dobra', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(383, 'SYP', 'Syrian Pound', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(384, 'SZL', 'Lilangeni', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(385, 'THB', 'Baht', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(386, 'TJS', 'Somoni', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(387, 'TMM', 'Manat', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(388, 'TND', 'Tunisian Dinar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(389, 'TOP', 'Paanga', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(390, 'TRY', 'New Turkish Lira', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(391, 'TTD', 'Trinidad and Tobago Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(392, 'TWD', 'New Taiwan Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(393, 'TZS', 'Tanzanian Shilling', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(394, 'UAH', 'Hryvnia', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(395, 'UGX', 'Uganda Shilling', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(396, 'USD', 'US Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(397, 'USN', 'USN', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(398, 'USS', 'USS', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(399, 'UYU', 'Peso Uruguayo', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(400, 'UZS', 'Uzbekistan Som', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(401, 'VEB', 'Venezuelan bolívar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(402, 'VND', 'Vietnamese đồng', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(403, 'VUV', 'Vatu', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(404, 'WST', 'Samoan Tala', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(405, 'XAF', 'CFA Franc BEAC', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(406, 'XAG', 'Silver (one Troy ounce)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(407, 'XAU', 'Gold (one Troy ounce)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(408, 'XCD', 'East Caribbean Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(409, 'XDR', 'Special Drawing Rights', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(410, 'XOF', 'CFA Franc BCEAO', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(411, 'XPD', 'Palladium (one Troy ounce)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(412, 'XPF', 'CFP franc', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(413, 'XPT', 'Platinum (one Troy ounce)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(414, 'XTS', 'Code reserved for testing purposes', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(415, 'XXX', 'No currency', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(416, 'YER', 'Yemeni Rial', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(417, 'ZAR', 'South African Rand', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(418, 'ZMK', 'Kwacha', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(419, 'ZWD', 'Zimbabwe Dollar', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(420, 'MXV', 'Mexican Unidad de Inversion (UDI) (Funds', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(421, 'XBA', 'European Composite Unit (EURCO) (Bonds m', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(422, 'XBB', 'European Monetary Unit (E.M.U.-6) (Bonds', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(423, 'XBC', 'European Unit of Account 9 (E.U.A.-9) (B', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(424, 'XBD', 'European Unit of Account 17 (E.U.A.-17) ', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(425, 'XFO', 'Gold franc (special settlement currency)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(426, 'XFU', 'UIC franc (special settlement currency)', 131, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(427, 'SLTTMR', 'Mr', 132, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(428, 'SLTTMRS', 'Mrs', 132, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(429, 'SLTTMS', 'Ms', 132, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(430, 'SLTTMSTR', 'Mstr', 132, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(431, 'GNDRM', 'Male', 133, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(432, 'GNDRF', 'Female', 133, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(433, 'GNDRU', 'Undisclosed', 133, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(434, 'MSTTM', 'Married', 134, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(435, 'MSTTU', 'Unmarried', 134, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(436, 'MSTTW', 'Widow', 134, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(437, 'MSTTD', 'Diversed', 134, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(438, 'MSTTUD', 'Undisclosed', 134, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(439, 'CRTF', 'Father', 137, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(440, 'CRTM', 'Mother', 137, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(441, 'CRTB', 'Brother', 137, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(442, 'CRTS', 'Sister', 137, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(443, 'CRTC', 'Cousine', 137, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(444, 'NPCT', 'Department Contact', 138, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(445, 'NPCT', 'Company Contact', 138, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(446, 'NPCT', 'Location Contact', 138, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(447, 'PNTL', 'Landline ', 140, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(448, 'PNTM', 'Mobile', 140, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(449, 'PNTP', 'Pager', 140, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(450, 'PNTS', 'Satelite Phone', 140, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(451, 'EAUT', 'Personal Email', 141, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(452, 'EAUT', 'Office Email ', 141, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(453, 'CATH', 'Home Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(454, 'CATO', 'Office Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(455, 'CATPA', 'Permanent Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(456, 'CATCA', 'Communication Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(457, 'CATPOBA', 'PO Box Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(458, 'CATMD', 'Millitray Address', 142, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(459, 'CL', 'Casual Leave', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(460, 'SL', 'Sick Leave ', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(461, 'BH', 'Bank Holidays', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(462, 'ML', 'Maternity Leave', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(463, 'SL', 'Special Leave', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(464, 'LD', 'Lieu Days', 186, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(465, 'CL', 'Scheduled', 196, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(466, 'SL', 'Being Reviewed', 196, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(467, 'BH', 'Reviewed', 196, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(468, 'OASC', 'Created', 42, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(469, 'OASA', 'Activated', 42, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(470, 'OASI', 'Inactivated', 42, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, 0),
(473, 'TSMN', 'Test Menu', 30, NULL, 1, 1, 0, 0, NULL, '2014-04-04 07:07:55', NULL, 0),
(474, 'IMSA', 'Identity Management System', 75, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:13:39', NULL, 0),
(475, 'CUMS', 'Currency Master', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:14:39', NULL, 0),
(476, 'CRME', 'Currency Rate Menu', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:18:54', NULL, 0),
(477, 'CTMN', 'Common Type', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:19:21', NULL, 0),
(478, 'IMMN', 'Independent Master', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:19:43', NULL, 0),
(479, 'CMMN', 'Config Mapping', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:20:02', NULL, 0),
(480, 'EOMN', 'Entity Object', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:20:22', NULL, 0),
(481, 'EMMN', 'Entity Object Attribute Mapping', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:20:53', NULL, 0),
(482, 'ETMN', 'Entity Object Tmp', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:21:09', NULL, 0),
(483, 'OMMN', 'Object Mapping', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:21:23', NULL, 0),
(484, 'ELMN', 'Exception Log', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:21:39', NULL, 0),
(485, 'ADMN', 'Applications Details', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:22:35', NULL, 0),
(486, 'HLMN', 'Hierarchy Level', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:22:49', NULL, 0),
(487, 'RNMN', 'Relationship Details', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:23:02', NULL, 0),
(488, 'SGMN', 'System Glossary', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:23:20', NULL, 0),
(489, 'SLMN', 'System Last Details', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:23:33', NULL, 0),
(490, 'RMMN', 'Role Master', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:24:08', NULL, 0),
(491, 'USMN', 'User Domain', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:24:21', NULL, 0),
(492, 'UGMN', 'User Group', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:24:34', NULL, 0),
(493, 'URMN', 'User Group Role', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:24:48', NULL, 0),
(494, 'UMMN', 'User Master', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:25:01', NULL, 0),
(495, 'UOMN', 'User Role', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:26:38', NULL, 0),
(496, 'PDMN', 'Permission Details', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:26:53', NULL, 0),
(497, 'EAMN', 'Entity Object Attribute', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:27:06', NULL, 0),
(498, 'CMTY', 'Common Type Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:29:32', NULL, 0),
(499, 'INDP', 'Independent Master Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:30:30', NULL, 0),
(500, 'CGMP', 'Config Mapping Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:31:06', NULL, 0),
(501, 'ENOB', 'Entity Object Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:32:03', NULL, 0),
(502, 'ENOA', 'Entity Object Attribute Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:32:32', NULL, 0),
(503, 'EOBM', 'Entity Object Attribute Mapping Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:33:10', NULL, 0),
(504, 'ENOT', 'Entity Object Tmp Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:33:40', NULL, 0),
(505, 'OBMA', 'Object Mapping Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:34:57', NULL, 0),
(506, 'EXLG', 'Exception Log Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:35:22', NULL, 0),
(507, 'APPL', 'Application Details Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:35:47', NULL, 0),
(508, 'PRMS', 'Permission Details Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:36:16', NULL, 0),
(509, 'HRCY', 'Hierarchy Level Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:36:39', NULL, 0),
(510, 'RTLP', 'Relationship Details Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:37:17', NULL, 0),
(511, 'SYGL', 'System Glossary Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:37:45', NULL, 0),
(512, 'SYLD', 'System Last Details Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:38:17', NULL, 0),
(513, 'ROMS', 'Role Master Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:38:46', NULL, 0),
(514, 'USDM', 'User Domain Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:39:14', NULL, 0),
(515, 'USGR', 'User Group Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:39:56', NULL, 0),
(516, 'UGRO', 'User Group Role Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:40:23', NULL, 0),
(517, 'USRM', 'User Master Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:40:50', NULL, 0),
(518, 'USRO', 'User Role Module', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 05:41:15', NULL, 0),
(524, 'TSM1', 'Test Menu 1', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 07:04:05', NULL, 0),
(525, 'TEMO', 'Testing Module 1', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 07:06:11', NULL, 0),
(526, 'TST2', 'TEST MENU 2', 30, NULL, 1, 0, 0, 0, NULL, '2014-04-05 09:25:25', NULL, 0),
(527, 'TSG2', 'TEST GLOBAL SETTINGS', 36, NULL, 1, 0, 0, 0, NULL, '2014-04-05 09:25:54', NULL, 0),
(528, 'TSM2', 'TEST MODULE 2', 76, NULL, 1, 0, 0, 0, NULL, '2014-04-05 09:26:30', NULL, 0),
(529, 'IND', 'India', 122, NULL, 1, 0, 10, 0, NULL, '2014-04-07 05:02:40', NULL, 0),
(530, 'PRTG', 'Group', 67, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:28:45', NULL, 0),
(531, 'PRTR', 'Role', 67, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:29:06', NULL, 0),
(532, 'PRTU', 'User', 67, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:29:22', NULL, 0),
(533, 'PR', 'Read', 68, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:35:40', NULL, 0),
(534, 'PW', 'Write', 68, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:36:01', NULL, 0),
(535, 'PRM', 'Remove', 68, 1, 1, 0, NULL, 0, NULL, '2014-03-12 05:37:46', NULL, 0),
(536, 'OPMN', 'Object Attribute Previleges', 30, NULL, 1, 0, 9, 0, 0, '2014-04-08 04:27:30', '2014-04-08 04:51:36', 0),
(543, 'OAPM', 'Object Attribute Privileges Module', 76, NULL, 1, 0, 9, 0, NULL, '2014-04-08 05:35:01', NULL, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `inface_obj_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `inface_obj_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `leavetype_dtl`
--

CREATE TABLE IF NOT EXISTS `leavetype_dtl` (
  `LEAVE_TYPE_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'leave type id identifier. This is a Unique primary key column of this entity',
  `LEAVE_TYPE_ID` int(10) NOT NULL COMMENT 'Leave type Name',
  `AVAILABLE_FLAG` smallint(10) DEFAULT NULL COMMENT 'Leave type status',
  `OPERATIONAL_COUNTRY_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from Operional conutry master table',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`LEAVE_TYPE_DTL_ID`),
  KEY `FK_LEAVETYPEDTL_LEAVETYPEID` (`LEAVE_TYPE_ID`),
  KEY `FK_LEAVETYPEDTL_OPERATIONALCOUNTRYID` (`OPERATIONAL_COUNTRY_ID`),
  KEY `FK_LEAVETYPEDTL_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVETYPEDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVETYPEDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the leave types' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leave_dtl`
--

CREATE TABLE IF NOT EXISTS `leave_dtl` (
  `LEAVE_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Leave dtl id id identifier. This is a Unique auto generated primary key column of this entity',
  `LEAVE_DATE` date DEFAULT NULL COMMENT 'Leave date',
  `LEACE_LENGTH_HOURS` decimal(6,0) DEFAULT NULL COMMENT 'Total hour of the leave',
  `LEACE_LENGTH_DAYS` decimal(4,0) DEFAULT NULL COMMENT 'total no of days of leave',
  `LEAVE_STATUS` smallint(6) DEFAULT NULL COMMENT 'Leave status',
  `LEAVE_COMMENTS` varchar(256) DEFAULT NULL COMMENT 'Leave comment',
  `LEAVE_REQUEST_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from leave type master table',
  `LEAVE_TYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee  master table',
  `LEAVE_EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `START_TIME` time DEFAULT NULL COMMENT 'Start time of the applied leave',
  `END_TIME` time DEFAULT NULL COMMENT 'End time of the applied leave',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`LEAVE_DTL_ID`),
  KEY `FK_LEAVEDTL_LEAVEREQUESTID` (`LEAVE_REQUEST_ID`),
  KEY `FK_LEAVEDTL_LEAVEEMPID` (`LEAVE_EMP_ID`),
  KEY `FK_LEAVEDTL_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVEDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVEDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the  Data definitions of employee leaves' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leave_employee`
--

CREATE TABLE IF NOT EXISTS `leave_employee` (
  `LEAVE_EMP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Timesheet id   identifier is the unique primary key of this entity. It is a auto generated number',
  `EMP_ID` int(10) DEFAULT NULL COMMENT 'Status of the timesheet',
  `EMP_NM` varchar(100) NOT NULL COMMENT 'Timesheet start date',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`LEAVE_EMP_ID`),
  UNIQUE KEY `UK_LEAVEEMPLOYEE` (`EMP_ID`,`EMP_NM`,`OA_BRAND_ID`),
  KEY `FK_LEAVEEMPLOYEE_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVEEMPLOYEE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVEEMPLOYEE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Leave related employee Details' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leave_period_mst`
--

CREATE TABLE IF NOT EXISTS `leave_period_mst` (
  `LEAVE_PERIOD_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'leave period id identifier. This is a Unique auto generated primary key column of this entity',
  `LEAVE_PERIOD_START_DATE` date NOT NULL COMMENT 'Leave period start date',
  `LEAVE_PERIOD_END_DATE` date NOT NULL COMMENT 'Leave period end date',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`LEAVE_PERIOD_ID`),
  KEY `FK_LEAVEPERIODMST_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVEPERIODMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVEPERIODMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of Leave period' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leave_quota`
--

CREATE TABLE IF NOT EXISTS `leave_quota` (
  `LEAVE_QUOTE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Holiday id identifier. This is a Unique auto generated primary key column of this entity',
  `LEAVE_TYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from leave type master table',
  `LEAVE_PERIOD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from leave period master table',
  `LEAVE_EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `NO_OF_DAYS_ALLOTED` decimal(6,2) DEFAULT NULL COMMENT 'No of days alloted',
  `LEAVE_TAKEN` decimal(6,2) DEFAULT '0.00' COMMENT 'No of leaves taken',
  `LEAVE_BROUGHT_FORWARD` decimal(6,2) DEFAULT '0.00' COMMENT 'No of leaves brought forward',
  `LEAVE_CARRIED_FORWARD` decimal(6,2) DEFAULT '0.00' COMMENT 'No of leaves carried forward',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`LEAVE_QUOTE_ID`),
  KEY `FK_LEAVEQUOTA_LEAVETYPEID` (`LEAVE_TYPE_ID`),
  KEY `FK_LEAVEQUOTA_LEAVEPERIODID` (`LEAVE_PERIOD_ID`),
  KEY `FK_LEAVEQUOTA_LEAVEEMPID` (`LEAVE_EMP_ID`),
  KEY `FK_LEAVEQUOTA_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVEQUOTA_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVEQUOTA_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the  Data definitions of employee leave quota' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests_dtl`
--

CREATE TABLE IF NOT EXISTS `leave_requests_dtl` (
  `LEAVE_REQUEST_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Leave request id id identifier. This is a Unique auto generated primary key column of this entity',
  `LEAVE_TYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from leave type  master table',
  `LEAVE_PERIOD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from leave period master table',
  `LEAVE_TYPE_NAME` varchar(50) DEFAULT NULL COMMENT 'Type of the leave requested',
  `DATE_APPLIED` date NOT NULL COMMENT 'Date of a leave requested',
  `LEAVE_EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `LEAVE_COMMENTS` varchar(256) DEFAULT NULL COMMENT 'Comment for a requested leave',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`LEAVE_REQUEST_ID`),
  KEY `FK_LEAVEREQUESTSDTL_LEAVETYPEID` (`LEAVE_TYPE_ID`),
  KEY `FK_LEAVEREQUESTSDTL_LEAVEPERIODID` (`LEAVE_PERIOD_ID`),
  KEY `FK_LEAVEREQUESTSDTL_LEAVEEMPID` (`LEAVE_EMP_ID`),
  KEY `FK_LEAVEREQUESTSDTL_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_LEAVEREQUESTSDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_LEAVEREQUESTSDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the  Data definitions of employee leave rwquest' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `leave_type_vw`
--
CREATE TABLE IF NOT EXISTS `leave_type_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `location_mst`
--

CREATE TABLE IF NOT EXISTS `location_mst` (
  `LOC_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Loc id is the unique primary key of this table',
  `LOC_CODE` varchar(5) NOT NULL COMMENT 'Code assigned to different locations',
  `LOC_NAME` varchar(40) DEFAULT NULL COMMENT 'Location name',
  `LOC_TYPE_ID` int(10) NOT NULL COMMENT 'Type id of the location',
  `LOC_DIAL_CD` varchar(5) DEFAULT NULL COMMENT 'Location dial code',
  `LOC_TIMEZONE_CD` int(10) DEFAULT NULL COMMENT 'Locations time zone code',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `ISDELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`LOC_ID`),
  KEY `FK_LOCATIONMST_LOCTYPEID` (`LOC_TYPE_ID`),
  KEY `FK_LOCATIONMST_LOCTIMEZONECD` (`LOC_TIMEZONE_CD`),
  KEY `FK_LOCATIONMST_OAID` (`OA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Different Locations' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `location_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `location_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `mail_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `mail_type_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_mst_vw`
--
CREATE TABLE IF NOT EXISTS `manager_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `marrital_status_mst_vw`
--
CREATE TABLE IF NOT EXISTS `marrital_status_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `menu_hier_vw`
--
CREATE TABLE IF NOT EXISTS `menu_hier_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `menu_item_mst_vw`
--
CREATE TABLE IF NOT EXISTS `menu_item_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `message_mst`
--

CREATE TABLE IF NOT EXISTS `message_mst` (
  `MSG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Message Identifier',
  `SYSTEM_MSG_ID` int(10) DEFAULT NULL COMMENT 'System message id',
  `MSG_SHORT_TEXT` varchar(50) NOT NULL COMMENT 'message  short text',
  `MSG_LONG_TEXT` varchar(250) DEFAULT NULL COMMENT 'message  long text',
  `MSG_TYPE_ID` int(10) NOT NULL COMMENT 'message type id. A foreign key from indepenent master of type message Type',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Company',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'created by',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Updated by',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'Date and time created',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'Date and Time Updated',
  PRIMARY KEY (`MSG_ID`),
  KEY `FK_MESSAGESMST_SYSTEMMSGID` (`SYSTEM_MSG_ID`),
  KEY `FK_MESSAGESMST_MSGTYPEID` (`MSG_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores all the messages used in the system. ' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `message_mst`
--

INSERT INTO `message_mst` (`MSG_ID`, `SYSTEM_MSG_ID`, `MSG_SHORT_TEXT`, `MSG_LONG_TEXT`, `MSG_TYPE_ID`, `OA_BRAND_ID`, `CREATED_ON`, `UPDATED_ON`, `CREATED_BY`, `UPDATED_BY`) VALUES
(1, 1, 'test', 'test', 2, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `mngt_hier_mst_vw`
--
CREATE TABLE IF NOT EXISTS `mngt_hier_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `model_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `model_obj_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `module_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `module_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `nationality_mst_vw`
--
CREATE TABLE IF NOT EXISTS `nationality_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `non_personal_contact_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `non_personal_contact_type_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `oa_brands`
--

CREATE TABLE IF NOT EXISTS `oa_brands` (
  `OA_BRAND_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'A',
  `OA_BRAND_CD` varchar(5) NOT NULL COMMENT 'A',
  `OA_BRAND_NM` varchar(40) NOT NULL COMMENT 'A',
  `OA_ID` int(10) NOT NULL COMMENT 'A',
  `REF_ID` int(10) DEFAULT NULL COMMENT 'A',
  `OA_BRAND_LOGO` varchar(100) DEFAULT NULL COMMENT 'A',
  `OA_BRAND_INV_TMPLT` varchar(100) DEFAULT NULL COMMENT 'A',
  `IS_ACTIVE` tinyint(1) DEFAULT '1' COMMENT 'A',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'A',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'A',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'A',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  PRIMARY KEY (`OA_BRAND_ID`),
  UNIQUE KEY `UK_OABRANDS_OABRANDCD` (`OA_BRAND_CD`),
  UNIQUE KEY `UK_OABRANDS_OABRANDNM` (`OA_BRAND_NM`),
  KEY `FK_OABRANDS_OAID` (`OA_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='A' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `oa_brands`
--

INSERT INTO `oa_brands` (`OA_BRAND_ID`, `OA_BRAND_CD`, `OA_BRAND_NM`, `OA_ID`, `REF_ID`, `OA_BRAND_LOGO`, `OA_BRAND_INV_TMPLT`, `IS_ACTIVE`, `IS_PRIMARY`, `CREATED_ON`, `UPDATED_ON`, `CREATED_BY`, `UPDATED_BY`) VALUES
(2, 'GEE', 'Geecon', 9, NULL, NULL, NULL, 1, 1, '2014-04-04 06:08:55', '0000-00-00 00:00:00', NULL, NULL),
(3, 'ABC', 'ABC', 10, NULL, NULL, NULL, 1, 1, '2014-04-05 14:44:15', '0000-00-00 00:00:00', NULL, NULL),
(4, 'TES', 'Test ORG', 11, NULL, NULL, NULL, 1, 1, '2014-04-07 04:33:49', '0000-00-00 00:00:00', NULL, NULL),
(5, 'dem', 'Demo ORG', 12, NULL, NULL, NULL, 1, 1, '2014-04-07 04:58:03', '0000-00-00 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `oa_brand_settings`
--

CREATE TABLE IF NOT EXISTS `oa_brand_settings` (
  `OAB_SETTING_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'A',
  `OABS_ATTRBUTE_ID` int(10) NOT NULL COMMENT 'A',
  `OABS_SETTING_VALUE` varchar(40) NOT NULL COMMENT 'A',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'A',
  `REF_ID` int(10) DEFAULT NULL COMMENT 'A',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT 'A',
  `VALIDATION` varchar(255) DEFAULT NULL COMMENT 'A',
  `IS_ACTIVE` tinyint(1) DEFAULT '1' COMMENT 'A',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'A',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'A',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'A',
  PRIMARY KEY (`OAB_SETTING_ID`),
  KEY `FK_OABRANDSETTINGS_OABSATTRBUTEID` (`OABS_ATTRBUTE_ID`),
  KEY `FK_OABRANDSETTINGS_OABRANDID` (`OA_BRAND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='A' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contacts`
--

CREATE TABLE IF NOT EXISTS `oa_contacts` (
  `OA_CNTCTS_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Organisation contact id is ',
  `OA_CNTCT_RELTYPE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from independent master table',
  `CNTCT_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact master table',
  `NON_PRSNL` tinyint(1) DEFAULT '0' COMMENT 'Non personal',
  `NON_PRSNL_CNTCT_TYP` int(10) DEFAULT NULL COMMENT 'Non personal contact type',
  `OA_ID` int(10) NOT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `IS_ACTIVE` tinyint(1) DEFAULT '1' COMMENT 'A flag to mark a record for active value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCTS_ID`),
  KEY `FK_OACONTACTS_OACNTCTRELTYPEID` (`OA_CNTCT_RELTYPE_ID`),
  KEY `FK_OACONTACTS_CNTCTID` (`CNTCT_ID`),
  KEY `FK_OACONTACTS_OAID` (`OA_ID`),
  KEY `FK_OACONTACTS_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contacts definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contact_address`
--

CREATE TABLE IF NOT EXISTS `oa_contact_address` (
  `OA_CNTCT_ADD_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key  of the organisation contact address table  ',
  `CNTCT_ADD_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation contact address table',
  `OA_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation account table',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'Is primary',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCT_ADD_ID`),
  KEY `FK_OACONTACTADDRESS_CNTCTADDID` (`CNTCT_ADD_ID`),
  KEY `FK_OACONTACTADDRESS_OAID` (`OA_ID`),
  KEY `FK_OACONTACTADDRESS_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTADDRESS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTADDRESS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contact Address definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contact_add_phoneno`
--

CREATE TABLE IF NOT EXISTS `oa_contact_add_phoneno` (
  `OA_CNTCT_ADD_PHONENO_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key  of the  organisation contact address phone number table  ',
  `CNTCT_ADD_PHONENO_ID` int(10) NOT NULL COMMENT 'Contact address phone id is the id of the contact  person address ',
  `OA_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation account table',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `IS_PRIMARY_TELNO` tinyint(1) DEFAULT '0' COMMENT 'Flag to check whether it is primary telephone number or not',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCT_ADD_PHONENO_ID`),
  KEY `FK_OACONTACTADDPHONENO_OAID` (`OA_ID`),
  KEY `FK_OACONTACTADDPHONENO_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTADDPHONENO_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTADDPHONENO_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contact Add Phone Number definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contact_emails`
--

CREATE TABLE IF NOT EXISTS `oa_contact_emails` (
  `OA_CNTCT_EML_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key  of the organisation contact emails table  ',
  `CNTCT_EML_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation contact emails table',
  `OA_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from organisation account table',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'Flag to check whether it is primary email address or not',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCT_EML_ID`),
  KEY `FK_OACONTACTEMAILS_CNTCTEMLID` (`CNTCT_EML_ID`),
  KEY `FK_OACONTACTEMAILS_OAID` (`OA_ID`),
  KEY `FK_OACONTACTEMAILS_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTEMAILS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTEMAILS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contact Emails definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contact_nationality`
--

CREATE TABLE IF NOT EXISTS `oa_contact_nationality` (
  `OA_CNTCT_NATIONALITY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Organisation contact nationality id is identifier represents the respective id of the organisation contact nationality',
  `CNTCT_NATIONALITY_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact nationality table',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCT_NATIONALITY_ID`),
  KEY `FK_OACONTACTNATIONALITY_CNTCTNATIONALITYID` (`CNTCT_NATIONALITY_ID`),
  KEY `FK_OACONTACTNATIONALITY_OAID` (`OA_ID`),
  KEY `FK_OACONTACTNATIONALITY_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTNATIONALITY_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTNATIONALITY_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contact Nationality definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oa_contact_phones`
--

CREATE TABLE IF NOT EXISTS `oa_contact_phones` (
  `OA_CNTCT_PHONE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Organisation phone number id is identifier represents the respective id of the phone number of an organisation',
  `CNTCT_PHONE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from contact phones table',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `IS_PRIMARY` tinyint(1) DEFAULT '0' COMMENT 'Is primary',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`OA_CNTCT_PHONE_ID`),
  KEY `FK_OACONTACTPHONES_CNTCTPHONEID` (`CNTCT_PHONE_ID`),
  KEY `FK_OACONTACTPHONES_OAID` (`OA_ID`),
  KEY `FK_OACONTACTPHONES_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OACONTACTPHONES_CREATEDBY` (`CREATED_BY`),
  KEY `FK_OACONTACTPHONES_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Organisation Contact Phones definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `obj_attrbt_previleges`
--

CREATE TABLE IF NOT EXISTS `obj_attrbt_previleges` (
  `OBJ_ATTRBT_PREVILEGES_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Object Attribute Setting Identifier is a auto generated primary key column of the entity',
  `OBJ_ID` int(10) NOT NULL COMMENT 'This represents the object identifier of an object. It is a foreign key of the entity object table',
  `OBJ_ATTRBT_ID` int(10) DEFAULT NULL COMMENT 'Object attributes Identifier. This is a foreign key value of the object attribute entity',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account Id. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand or Company identifier. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `USER_ID` int(10) DEFAULT NULL COMMENT 'User Identifier. This is the foreign key of the user table',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`OBJ_ATTRBT_PREVILEGES_ID`),
  UNIQUE KEY `UK_OBJATTRBTPREVILEGES` (`OBJ_ID`,`OBJ_ATTRBT_ID`,`OA_BRAND_ID`,`OA_ID`,`USER_ID`),
  KEY `FK_OBJATTRBTPREVILEGES_OBJATTRBTID` (`OBJ_ATTRBT_ID`),
  KEY `FK_OBJATTRBTPREVILEGES_OAID` (`OA_ID`),
  KEY `FK_OBJATTRBTPREVILEGES_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_OBJATTRBTPREVILEGES_USERID` (`USER_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This Stores the Master Data definitions of all the object settings' AUTO_INCREMENT=9 ;

--
-- Dumping data for table `obj_attrbt_previleges`
--

INSERT INTO `obj_attrbt_previleges` (`OBJ_ATTRBT_PREVILEGES_ID`, `OBJ_ID`, `OBJ_ATTRBT_ID`, `OA_ID`, `OA_BRAND_ID`, `USER_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 1, 1, 11, 4, 5, 5, NULL, '2014-04-08 04:59:12', NULL),
(2, 1, 2, 9, 2, 1, 5, 5, '2014-04-08 05:13:24', '2014-04-08 06:15:32'),
(3, 1, 1, 9, 2, 5, 5, NULL, '2014-04-09 07:13:46', NULL),
(4, 33, 3, 10, 3, 4, 5, NULL, '2014-04-09 07:14:00', NULL),
(5, 2, 2, 10, 3, 5, 6, NULL, '2014-04-09 07:14:09', NULL),
(6, 1, 8, 11, 4, 7, 5, NULL, '2014-04-09 07:14:31', NULL),
(7, 3, 4, 11, 4, 6, 6, NULL, '2014-04-09 07:14:32', NULL),
(8, 7, 6, 11, 4, 6, 6, NULL, '2014-04-09 07:14:56', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `obj_layer_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `obj_layer_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `orgacct_settings_mst_vw`
--
CREATE TABLE IF NOT EXISTS `orgacct_settings_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `org_accounts`
--

CREATE TABLE IF NOT EXISTS `org_accounts` (
  `OA_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'A',
  `OA_CD` varchar(5) NOT NULL COMMENT 'A',
  `OA_NM` varchar(40) NOT NULL COMMENT 'A',
  `OA_EMAIL` varchar(40) NOT NULL COMMENT 'A',
  `OA_WEB_DOMAIN` varchar(40) NOT NULL COMMENT 'A',
  `OA_CONTACT_NO` varchar(40) NOT NULL COMMENT 'A',
  `OA_STATUS_ID` int(10) NOT NULL DEFAULT '1' COMMENT 'A',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'A',
  `UPDATED_ON` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'A',
  `CREATED_BY` int(10) NOT NULL COMMENT 'A',
  `UPDATED_BY` int(10) NOT NULL COMMENT 'A',
  `OA_ADDRESS` varchar(255) DEFAULT NULL COMMENT 'Address Of Organisation Account',
  PRIMARY KEY (`OA_ID`),
  UNIQUE KEY `UK_ORGACCOUNTS_OACD` (`OA_CD`),
  UNIQUE KEY `UK_ORGACCOUNTS_OANM` (`OA_NM`),
  UNIQUE KEY `UK_ORGACCOUNTS_OAEMAIL` (`OA_EMAIL`),
  UNIQUE KEY `UK_ORGACCOUNTS_OAWEBDOMAIN` (`OA_WEB_DOMAIN`),
  KEY `FK_ORGACCOUNTS_OASTATUSID` (`OA_STATUS_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='A' AUTO_INCREMENT=13 ;

--
-- Dumping data for table `org_accounts`
--

INSERT INTO `org_accounts` (`OA_ID`, `OA_CD`, `OA_NM`, `OA_EMAIL`, `OA_WEB_DOMAIN`, `OA_CONTACT_NO`, `OA_STATUS_ID`, `CREATED_ON`, `UPDATED_ON`, `CREATED_BY`, `UPDATED_BY`, `OA_ADDRESS`) VALUES
(9, 'GEE', 'Geecon', 'info@geeconglobal.com', 'http://www.geeconglobal.com', '98765432', 469, '2014-04-04 06:08:55', '0000-00-00 00:00:00', 0, 0, 'BKC'),
(10, 'ABC', 'ABC', 'demo@demo.com', '', '0987654', 469, '2014-04-05 14:44:15', '0000-00-00 00:00:00', 0, 0, 'mumbai'),
(11, 'TES', 'Test ORG', 'admin@geeconglobal.com', 'http://ellislab.com/codeigniter/user-gui', '7896321450', 469, '2014-04-07 04:33:49', '0000-00-00 00:00:00', 0, 0, 'Kandivali'),
(12, 'dem', 'Demo ORG', 'admindemo@geeconglobal.com', 'http://geeconglobal.com/', '7896321450', 469, '2014-04-07 04:58:03', '0000-00-00 00:00:00', 0, 0, 'xyz park');

-- --------------------------------------------------------

--
-- Table structure for table `performance_indicator`
--

CREATE TABLE IF NOT EXISTS `performance_indicator` (
  `PI_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Kpi id   Identifier is the unique primary key of this entity. It is a Auto generated number',
  `JOB_TITLE_ID` int(10) NOT NULL COMMENT 'Job title id. This is a master data driven from independent master table.the related entity is JOB TITLE Typ_id=158 on UI this will be a dropdown control',
  `DESCRIPTION` varchar(200) DEFAULT NULL COMMENT 'KPI description',
  `RATE_MIN` double DEFAULT NULL COMMENT 'Minimum performance rate',
  `RATE_MAX` double DEFAULT NULL COMMENT 'Maximum performance rate',
  `RATE_DEFAULT` tinyint(4) DEFAULT NULL COMMENT 'Set default kpi rate',
  `IS_ACTIVE` tinyint(1) NOT NULL COMMENT 'A flag to mark a record for is active the value can be true or false the default value is true',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`PI_ID`),
  KEY `FK_PERFORMANCEINDICATOR_JOBTITLEID` (`JOB_TITLE_ID`),
  KEY `FK_PERFORMANCEINDICATOR_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_PERFORMANCEINDICATOR_CREATEDBY` (`CREATED_BY`),
  KEY `FK_PERFORMANCEINDICATOR_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores all the details of an performance Indicator of an employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `performance_review`
--

CREATE TABLE IF NOT EXISTS `performance_review` (
  `PR_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Performance review id   Identifier is the unique primary key of this entity. It is a Auto generated number',
  `PI_EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `REVIEWER_ID` int(13) NOT NULL COMMENT 'Foreign key column value driven from employee master table',
  `JOB_TITLE_ID` int(10) NOT NULL COMMENT 'Job title id. This is a master data driven from independent master table.the related entity is JOB TITLE Typ_id=158 on UI this will be a dropdown control',
  `SUB_DIVISION_ID` int(13) DEFAULT NULL COMMENT 'id of an subunit',
  `PERIOD_FROM` date NOT NULL COMMENT 'From date',
  `PERIOD_TO` date NOT NULL COMMENT 'To Dare',
  `DUE_DATE` date NOT NULL COMMENT 'Due date',
  `PR_STATUS_ID` int(10) DEFAULT NULL COMMENT 'state',
  `KPIS` varchar(250) DEFAULT NULL COMMENT 'KPIS',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`PR_ID`),
  KEY `FK_PERFORMANCEREVIEW_PIEMPID` (`PI_EMP_ID`),
  KEY `FK_PERFORMANCEREVIEWCOMMENTS_REVIEWERID` (`REVIEWER_ID`),
  KEY `FK_PERFORMANCEREVIEW_JOBTITLEID` (`JOB_TITLE_ID`),
  KEY `FK_PERFORMANCEREVIEW_SUBDIVISIONID` (`SUB_DIVISION_ID`),
  KEY `FK_PERFORMANCEREVIEW_PRSTATUSID` (`PR_STATUS_ID`),
  KEY `FK_PERFORMANCEREVIEW_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_PERFORMANCEREVIEW_CREATEDBY` (`CREATED_BY`),
  KEY `FK_PERFORMANCEREVIEW_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores all the details of an performance review of an employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `performance_review_comments`
--

CREATE TABLE IF NOT EXISTS `performance_review_comments` (
  `PRC_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id   Identifier is the unique primary key of this entity. It is a Auto generated number',
  `PI_EMP_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Performance review table',
  `EMP_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from employee master table',
  `COMMENT` varchar(250) DEFAULT NULL COMMENT 'Comment',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`PRC_ID`),
  KEY `FK_PERFORMANCEREVIEWCOMMENTS_PIEMPID` (`PI_EMP_ID`),
  KEY `FK_PERFORMANCEREVIEWCOMMENTS_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_PERFORMANCEREVIEWCOMMENTS_CREATEDBY` (`CREATED_BY`),
  KEY `FK_PERFORMANCEREVIEWCOMMENTS_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores all the details of an performance review comments of an employee' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `performance_status_vw`
--
CREATE TABLE IF NOT EXISTS `performance_status_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `permission_dtl`
--

CREATE TABLE IF NOT EXISTS `permission_dtl` (
  `PERMISSIONS_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Permission detail identifier is a unique auto generated number used for primary key column of this entity',
  `PERMISSIONS_REF_TYPE_ID` int(10) NOT NULL COMMENT 'Permission reference type indicates of the permission is belonging to a user, Group or Role',
  `PERMISSIONS_REF_ID` int(10) NOT NULL COMMENT 'Permission reference  Id',
  `PERMISSIONS_ID` int(10) NOT NULL COMMENT 'Permission Identifier represents the respective ID of the Role, user or User group',
  `OBJ_ATTRBT_PREVILEGES_ID` int(10) DEFAULT NULL COMMENT 'Attribute settings Id is Identifier represents the respective ID of the object attribute privileges',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  `OBJ_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`PERMISSIONS_DTL_ID`),
  UNIQUE KEY `UK_PERMISSIONDTL` (`PERMISSIONS_REF_TYPE_ID`,`PERMISSIONS_REF_ID`,`PERMISSIONS_ID`,`OBJ_ATTRBT_PREVILEGES_ID`),
  KEY `FK_PERMISSIONDTL_PERMISSIONSID` (`PERMISSIONS_ID`),
  KEY `FK_PERMISSIONDTL_OBJATTRBTPREVILEGESID` (`OBJ_ATTRBT_PREVILEGES_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This Stores the Master Data definitions of all the Permissions settings' AUTO_INCREMENT=23 ;

--
-- Dumping data for table `permission_dtl`
--

INSERT INTO `permission_dtl` (`PERMISSIONS_DTL_ID`, `PERMISSIONS_REF_TYPE_ID`, `PERMISSIONS_REF_ID`, `PERMISSIONS_ID`, `OBJ_ATTRBT_PREVILEGES_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`, `OBJ_ID`) VALUES
(10, 530, 68, 534, 1, 5, 5, '2014-04-08 11:06:41', '2014-04-09 10:48:16', NULL),
(11, 531, 68, 534, 2, 5, NULL, '2014-04-09 07:27:29', NULL, NULL),
(12, 531, 68, 534, 4, 5, NULL, '2014-04-09 07:27:29', NULL, NULL),
(13, 531, 68, 534, 5, 5, NULL, '2014-04-09 07:27:29', NULL, NULL),
(16, 531, 68, 534, 8, 5, 5, '2014-04-09 09:43:00', '2014-04-09 10:12:17', NULL),
(18, 530, 67, 533, 4, 5, NULL, '2014-04-09 10:10:23', NULL, NULL),
(19, 530, 67, 533, 5, 5, NULL, '2014-04-09 10:10:23', NULL, NULL),
(20, 530, 67, 533, 6, 5, NULL, '2014-04-09 10:10:23', NULL, NULL),
(21, 531, 68, 534, 1, 5, NULL, '2014-04-09 10:12:17', NULL, NULL),
(22, 530, 67, 533, 1, 5, NULL, '2014-04-09 10:15:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `phone_nbr_mst`
--

CREATE TABLE IF NOT EXISTS `phone_nbr_mst` (
  `PHONE_NBR_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Phone number id is identifier represents the respective id of the phone number',
  `PHONE_NBR` varchar(14) NOT NULL COMMENT 'Contact person phone number',
  `PHONE_NBR_TYPE_ID` int(10) NOT NULL COMMENT 'Phone number type',
  `PHONE_COUNTRY_CD` varchar(5) DEFAULT NULL COMMENT 'Phone number country code',
  `PHONE_AREA_CD` varchar(5) DEFAULT NULL COMMENT 'Phone number area code',
  `PHONE_EXCHANGE_NBR` varchar(5) DEFAULT NULL COMMENT 'Phone number exchange code',
  `PHONE_LINE_NBR` varchar(6) DEFAULT NULL COMMENT 'Phone line number',
  `PHONE_EXTN` varchar(5) DEFAULT NULL COMMENT 'Phone extensions',
  `IS_FAXNBR` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark that it  is fax number or not',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `OA_ID_ORIGINATED` int(10) DEFAULT NULL COMMENT 'Organisation account id ',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`PHONE_NBR_ID`,`PHONE_NBR_TYPE_ID`),
  UNIQUE KEY `UK_PHONENBRMST_PHONENBR_PHONENBRTYPEID` (`PHONE_NBR`,`PHONE_NBR_TYPE_ID`),
  UNIQUE KEY `UK_PHONENBRMST_PHONENBRTYPEID` (`PHONE_NBR_TYPE_ID`,`PHONE_COUNTRY_CD`,`PHONE_AREA_CD`,`PHONE_EXCHANGE_NBR`,`PHONE_LINE_NBR`,`PHONE_EXTN`),
  KEY `FK_PHONENBRMST_OAIDORIGINATED` (`OA_ID_ORIGINATED`),
  KEY `FK_PHONENBRMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_PHONENBRMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Phone Number Management definitions of all the Contact person' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `phone_number_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `phone_number_type_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `pi_employee`
--

CREATE TABLE IF NOT EXISTS `pi_employee` (
  `PI_EMP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Timesheet id   identifier is the unique primary key of this entity. It is a auto generated number',
  `EMP_ID` int(10) DEFAULT NULL COMMENT 'Status of the timesheet',
  `EMP_NM` varchar(100) NOT NULL COMMENT 'Timesheet start date',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`PI_EMP_ID`),
  UNIQUE KEY `UK_PIEMPLOYEE_EMPIDEMPNMOABRANDID` (`EMP_ID`,`EMP_NM`,`OA_BRAND_ID`),
  KEY `FK_PIEMPLOYEE_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_PIEMPLOYEE_CREATEDBY` (`CREATED_BY`),
  KEY `FK_PIEMPLOYEE_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the PI records' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `postcode_mst`
--

CREATE TABLE IF NOT EXISTS `postcode_mst` (
  `POSTCODE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Postcode id is primary key of this table',
  `POSTCODE_PREFIX` varchar(4) DEFAULT NULL COMMENT 'Postcode id prefix',
  `POSTCODE_SUFFIX` varchar(4) DEFAULT NULL COMMENT 'Postcode id suffix ',
  `POSTCODE` varchar(9) NOT NULL COMMENT 'Post code',
  `COUNTRY_ID` int(10) DEFAULT NULL COMMENT 'Respective country id of the country',
  `COUNTY_STATE_ID` int(10) DEFAULT NULL COMMENT 'Id for state of that country',
  `TIME_ZONE_ID` int(10) DEFAULT NULL COMMENT 'Time zone identifier is the foreign key of this entity. This information is mapped with time zone entity',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `ISDELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`POSTCODE_ID`),
  UNIQUE KEY `UK_POSTCODEMST_POSTCODE_COUNTRYID_COUNTTYSTATEID_OAID` (`POSTCODE`,`COUNTRY_ID`,`COUNTY_STATE_ID`,`OA_ID`),
  KEY `FK_POSTCODEMST_COUNTRYID` (`COUNTRY_ID`),
  KEY `FK_POSTCODEMST_COUNTYSTATEID` (`COUNTY_STATE_ID`),
  KEY `FK_POSTCODEMST_TIMEZONEID` (`TIME_ZONE_ID`),
  KEY `FK_POSTCODEMST_OAID` (`OA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Different Poastal areas.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `prcss_obj_type_mst_vw`
--
CREATE TABLE IF NOT EXISTS `prcss_obj_type_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `prsnttn_layer_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `prsnttn_layer_obj_mst_vw` (
`TYP_ID` int(10)
,`TYP_CD` varchar(5)
,`TYP_NM` varchar(40)
,`VIEW_NM` varchar(40)
,`PARENT_TYP_ID` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `race_mst_vw`
--
CREATE TABLE IF NOT EXISTS `race_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `relationship_dtl`
--

CREATE TABLE IF NOT EXISTS `relationship_dtl` (
  `REL_DET_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary key auto generated unique running sequence number',
  `HIER_LEVEL_CONFIG_ID` int(10) NOT NULL COMMENT 'This is the foreign key of the hierarchy level config table. Its an auto generated number',
  `CHILD_ID` int(10) NOT NULL COMMENT 'Child Identifier',
  `PARENT_ID` int(10) NOT NULL COMMENT 'Parent Identifier',
  `HIER_TYPE_ID` int(10) NOT NULL COMMENT 'Hierarchy type ID is the ID Related to various hierarchy types. The examples of a hierarchy types are Company Hierarchy, Geographical Hierarchy, Management Hierarchy, Application Hierarchy, Menu hierarchy etc',
  `HIER_CHILD_ENTITY_TYPE_ID` int(10) NOT NULL COMMENT 'This is the ID of the Element of the Hierarchy  type. Company hierarchy is made up of elements such as company, dept sub dept etc. ',
  `HIER_PARENT_ENTITY_TYPE_ID` int(10) NOT NULL COMMENT 'This indicates the parent element type of the hierarchy',
  `LEVEL_SEQ` int(10) NOT NULL COMMENT 'This is an Free flow user text field which will dictate the level of the elements in the given hierarchy',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account ID',
  `OA_BRAND_ID` int(10) DEFAULT NULL COMMENT 'Brand  or company id',
  `IS_DELETED` tinyint(1) DEFAULT NULL COMMENT 'Flag to mark the hierarchy for deletion',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'Created by user name',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'updated by user name',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when record was updated',
  PRIMARY KEY (`REL_DET_ID`),
  KEY `FK_RELATIONSHIPDET_HIERLEVELCONFIGID` (`HIER_LEVEL_CONFIG_ID`),
  KEY `FK_RELATIONSHIPDET_HIERTYPEID` (`HIER_TYPE_ID`),
  KEY `FK_RELATIONSHIPDET_HIERENTITYTYPEID` (`HIER_CHILD_ENTITY_TYPE_ID`),
  KEY `FK_RELATIONSHIPDET_HIERENTITYPARENTTYPEID` (`HIER_PARENT_ENTITY_TYPE_ID`),
  KEY `FK_RELATIONSHIPDET_OAID` (`OA_ID`),
  KEY `FK_RELATIONSHIPDET_OABRANDID` (`OA_BRAND_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This table stores the parent child relationships. This is typically used to store the hierarchy details & its relatiohship' AUTO_INCREMENT=38 ;

--
-- Dumping data for table `relationship_dtl`
--

INSERT INTO `relationship_dtl` (`REL_DET_ID`, `HIER_LEVEL_CONFIG_ID`, `CHILD_ID`, `PARENT_ID`, `HIER_TYPE_ID`, `HIER_CHILD_ENTITY_TYPE_ID`, `HIER_PARENT_ENTITY_TYPE_ID`, `LEVEL_SEQ`, `OA_ID`, `OA_BRAND_ID`, `IS_DELETED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(6, 4, 472, 471, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-04 10:48:37', NULL),
(7, 4, 498, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:29:32', NULL),
(8, 4, 499, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:30:30', NULL),
(9, 4, 500, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:31:06', NULL),
(10, 4, 501, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:32:03', NULL),
(11, 4, 502, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:32:32', NULL),
(12, 4, 503, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:33:10', NULL),
(13, 4, 504, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:33:40', NULL),
(14, 4, 505, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:34:57', NULL),
(15, 4, 506, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:35:22', NULL),
(16, 4, 507, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:35:47', NULL),
(17, 4, 508, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:36:16', NULL),
(18, 4, 509, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:36:39', NULL),
(19, 4, 510, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:37:17', NULL),
(20, 4, 511, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:37:45', NULL),
(21, 4, 512, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:38:17', NULL),
(22, 4, 513, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:38:46', NULL),
(23, 4, 514, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:39:14', NULL),
(24, 4, 515, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:39:56', NULL),
(25, 4, 516, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:40:23', NULL),
(26, 4, 517, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:40:50', NULL),
(27, 4, 518, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 05:41:15', NULL),
(28, 4, 522, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, 0, '2014-04-05 06:25:46', '2014-04-05 06:31:56'),
(29, 4, 525, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 07:06:11', NULL),
(30, 4, 528, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-05 09:26:30', NULL),
(37, 4, 543, 474, 74, 76, 75, 0, NULL, NULL, NULL, 0, NULL, '2014-04-08 05:35:01', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `relegion_mst_vw`
--
CREATE TABLE IF NOT EXISTS `relegion_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `role_mst`
--

CREATE TABLE IF NOT EXISTS `role_mst` (
  `ROLE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Role identifier. This is a Unique auto generated primary key column of this entity',
  `ROLE_NM` varchar(40) NOT NULL COMMENT 'Role Name',
  `ROLE_DSCRPTN` varchar(255) DEFAULT NULL COMMENT 'Role description',
  `DMN_ID` int(10) DEFAULT NULL COMMENT 'Domain Identifier is the foreign key of this entity. This information is mapped with domain entity. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `IS_ADMIN_ROLE` tinyint(1) DEFAULT '0' COMMENT 'Flag to set role as an admin role of the organisation',
  `IS_ASSIGNABLE` tinyint(1) DEFAULT '1' COMMENT 'Flag to validate if the Role can be assigned to any user /profile or not',
  `IS_PREDEFINED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark that the role is a predefined system value',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`ROLE_ID`),
  UNIQUE KEY `UK_ROLEMST_ROLENMDMNID` (`ROLE_NM`,`DMN_ID`),
  KEY `FK_ROLEMST_DMNID` (`DMN_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Roles' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `role_mst`
--

INSERT INTO `role_mst` (`ROLE_ID`, `ROLE_NM`, `ROLE_DSCRPTN`, `DMN_ID`, `IS_DELETED`, `IS_ADMIN_ROLE`, `IS_ASSIGNABLE`, `IS_PREDEFINED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 'test', 'testing 2', 3, 0, 0, 1, 1, 5, 5, '2014-04-07 06:58:44', '2014-04-07 09:18:09');

-- --------------------------------------------------------

--
-- Stand-in structure for view `salutation_mst_vw`
--
CREATE TABLE IF NOT EXISTS `salutation_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `shift_mst`
--

CREATE TABLE IF NOT EXISTS `shift_mst` (
  `SHIFT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'shif  id is identifier represents the respective id of the employe work shift',
  `NAME` varchar(250) NOT NULL COMMENT 'Name for a shift',
  `HOURS_PER_DAY` decimal(4,2) NOT NULL COMMENT 'Total hours for a shift',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`SHIFT_ID`),
  KEY `FK_SHIFTMST_CREATEDBY` (`CREATED_BY`),
  KEY `FK_SHIFTMST_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_SHIFTMST_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Entity Stories all the master data of a work shift' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `state_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `state_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `street_mst`
--

CREATE TABLE IF NOT EXISTS `street_mst` (
  `STREET_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Street id is primary key of this table',
  `STREET_NAME` varchar(40) NOT NULL COMMENT 'Street name',
  `LOCALITY` varchar(40) DEFAULT NULL COMMENT 'Street locality',
  `AREA` varchar(40) DEFAULT NULL COMMENT 'Street area',
  `TOWN_ID` int(10) DEFAULT NULL COMMENT 'Town id blank id values indicates that it is a system generated  record and can be used across all the town records',
  `CENSUS_BLOCK_ID` int(10) DEFAULT NULL COMMENT 'Census block id  values indicates that it is a system generated  record and can be used across all the  records',
  `CITY_ID` int(10) DEFAULT NULL COMMENT 'Census block id  values indicates that it is a system generated  record and can be used across all the  records',
  `TERRITORY_ID` int(10) DEFAULT NULL COMMENT 'City id  values indicates that it is a system generated  record and can be used across all the city records',
  `DISTRICT_ID` int(10) DEFAULT NULL COMMENT 'District id  values indicates that it is a system generated  record and can be used across all the accounts',
  `POSTCODE_ID` int(10) DEFAULT NULL COMMENT 'Postal area code',
  `OA_ID` int(10) DEFAULT NULL COMMENT 'Organisation account id. Blank id values indicates that it is a system generated  record and can be used across all the accounts',
  `COURIER_ROUTE_DESC` varchar(100) DEFAULT NULL COMMENT 'Description of courier route',
  `ISDELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATEDBY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATEDON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`STREET_ID`),
  KEY `FK_STREETMST_TOWNID` (`TOWN_ID`),
  KEY `FK_STREETMST_CENSUSBLOCKID` (`CENSUS_BLOCK_ID`),
  KEY `FK_STREETMST_CITYID` (`CITY_ID`),
  KEY `FK_STREETMST_TERRITORYID` (`TERRITORY_ID`),
  KEY `FK_STREETMST_DISTRICTID` (`DISTRICT_ID`),
  KEY `FK_STREETMST_POSTCODEID` (`POSTCODE_ID`),
  KEY `FK_STREETMST_OAID` (`OA_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Different Streets in city.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `subdept_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `subdept_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `sw_app_hier_mst_vw`
--
CREATE TABLE IF NOT EXISTS `sw_app_hier_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `systempermisiontype_mst_vw`
--
CREATE TABLE IF NOT EXISTS `systempermisiontype_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `systm_glssry`
--

CREATE TABLE IF NOT EXISTS `systm_glssry` (
  `GLSSRY_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Glossary Identifier',
  `GLSSRY_CD` varchar(10) NOT NULL COMMENT 'Glossary Code',
  `GLSSRY_MNNG` varchar(25) NOT NULL COMMENT 'Glossary Meaning',
  `GLSSRY_DSCRPTN` varchar(100) DEFAULT NULL COMMENT 'Glossary Description',
  PRIMARY KEY (`GLSSRY_ID`),
  UNIQUE KEY `UK_SYSTMGLSSRY_GLSSRYCD` (`GLSSRY_CD`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='System Glossary. A glossary is a list of important words used in the systems, that give the meaning of those words. It is like a small dictionary meant to give a quick look up of words that pertain to the subject. Its a list of terms in a special subject, field, or area of usage, with accompanying definitions. This is used for explaining or defining difficult or unusual words and expressions used in the text.' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `systm_glssry`
--

INSERT INTO `systm_glssry` (`GLSSRY_ID`, `GLSSRY_CD`, `GLSSRY_MNNG`, `GLSSRY_DSCRPTN`) VALUES
(1, 'code3', 'mnng3', 'desc3');

-- --------------------------------------------------------

--
-- Table structure for table `systm_lst_dtl`
--

CREATE TABLE IF NOT EXISTS `systm_lst_dtl` (
  `TBL_NM` varchar(50) NOT NULL COMMENT 'System Table Name',
  `LST_NMBR` int(10) NOT NULL COMMENT 'Last number generated for the primary key column of the table',
  PRIMARY KEY (`TBL_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='System Last Detail. This table stores the Last sequence details of the system entities for auto number generation of Primary Key.';

--
-- Dumping data for table `systm_lst_dtl`
--

INSERT INTO `systm_lst_dtl` (`TBL_NM`, `LST_NMBR`) VALUES
('tab1', 2),
('tab3', 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `theme_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `theme_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `timezone_mst`
--

CREATE TABLE IF NOT EXISTS `timezone_mst` (
  `TIME_ZONE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Time zone id  is the unique primary key of this entity',
  `TIMEZONE` varchar(4) NOT NULL COMMENT 'Time according to different time zone',
  `TIMEZONE_TYPE_ID` int(10) NOT NULL COMMENT 'Time zone type id',
  `ISDELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATEDBY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and time when the record was updated',
  PRIMARY KEY (`TIME_ZONE_ID`),
  UNIQUE KEY `UK_TIMEZONEMST_TIMEZONE` (`TIMEZONE`),
  KEY `FK_TIMEZONEMST_TIMEZONETYPEID` (`TIMEZONE_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Different timezone' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `toolbar_mst_vw`
--
CREATE TABLE IF NOT EXISTS `toolbar_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `town_name_mst_vw`
--
CREATE TABLE IF NOT EXISTS `town_name_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
,`IS_PREDEFINED` tinyint(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `user_contacts`
--

CREATE TABLE IF NOT EXISTS `user_contacts` (
  `USER_CNTCT_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'User Contact detail identifier is a unique auto generated number used for primary key column of this entity',
  `USER_ID` int(10) NOT NULL COMMENT 'User Id is Identifier represents the respective ID of the User',
  `CNTCT_ID` int(10) DEFAULT NULL COMMENT 'Contact Identifier of the user from the contact module. This is used to link a employee, supplier, vendor or any such personal or non personal contact ids to a user',
  `USER_CNTCT_TYPE_ID` int(10) DEFAULT NULL COMMENT 'Contact Type indicates the type of contact mapped to the user account. This could be a Supplier, vendor, employee etc. The value is a master data mapped value and is a foreign ',
  `EXT_REF_NBR` varchar(40) DEFAULT NULL COMMENT 'External Reference ID',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`USER_CNTCT_ID`),
  UNIQUE KEY `UK_USERCONTACTS` (`USER_ID`,`CNTCT_ID`,`USER_CNTCT_TYPE_ID`),
  KEY `FK_USERCONTACTS_USERCNTCTTYPEID` (`USER_CNTCT_TYPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This Stores the Master Data definitions of all the User Contacts' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_contact_type_vw`
--
CREATE TABLE IF NOT EXISTS `user_contact_type_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `user_domain`
--

CREATE TABLE IF NOT EXISTS `user_domain` (
  `DMN_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Domain Identifier is the unique primary key of this entity. It is a Auto generated number',
  `DMN_NM` varchar(40) NOT NULL COMMENT 'User Domain Name',
  `DSCRPTN` varchar(100) DEFAULT NULL COMMENT 'User Domain Description',
  `OA_ID` int(10) NOT NULL COMMENT 'Organisation account Id. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`DMN_ID`),
  UNIQUE KEY `UK_USERDOMAIN_DMNNMOABRANDID` (`DMN_NM`,`OA_BRAND_ID`),
  KEY `FK_USERDOMAIN_OAID` (`OA_ID`),
  KEY `FK_USERDOMAIN_OABRANDID` (`OA_BRAND_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the User Domains' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_domain`
--

INSERT INTO `user_domain` (`DMN_ID`, `DMN_NM`, `DSCRPTN`, `OA_ID`, `OA_BRAND_ID`, `IS_DELETED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 'GEE', NULL, 9, 2, 0, 0, NULL, '2014-04-04 06:08:55', NULL),
(2, 'ABC', NULL, 10, 3, 0, 0, NULL, '2014-04-05 14:44:15', NULL),
(3, 'TES', 'testing', 11, 4, 0, 0, 5, '2014-04-07 04:33:49', '2014-04-07 06:07:47'),
(4, 'dem', NULL, 12, 5, 0, 0, NULL, '2014-04-07 04:58:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `USER_GRP_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Unique Id is generated for a user Group. This is a Unique auto generated primary key column value of the entity',
  `USER_GRP_NM` varchar(40) NOT NULL COMMENT 'User Group Name',
  `DMN_ID` int(10) NOT NULL COMMENT 'User Domain Identifier. It is a foreign key column value from the security domain table. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'A flag to mark a record for deletion the value can be true or false the default value is false',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`USER_GRP_ID`),
  UNIQUE KEY `UK_USERGROUP_USERGRPNMDMNID` (`USER_GRP_NM`,`DMN_ID`),
  KEY `FK_USERGROUP_DMNID` (`DMN_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This Stores the Data definitions of all the User Groups' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`USER_GRP_ID`, `USER_GRP_NM`, `DMN_ID`, `IS_DELETED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 'TEst GRP', 3, 0, 4, 1, '2014-04-02 00:00:00', '2014-04-09 04:53:05'),
(2, 'qwer', 1, 0, 1, NULL, '2014-04-08 07:32:31', NULL),
(3, 'poiu', 3, 0, 1, NULL, '2014-04-08 09:51:46', NULL),
(4, 'abc', 4, 0, 1, 1, '2014-04-08 10:18:50', '2014-04-08 10:35:30');

-- --------------------------------------------------------

--
-- Table structure for table `user_group_dtl`
--

CREATE TABLE IF NOT EXISTS `user_group_dtl` (
  `USER_GRP_DTL_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Unique Id is generated for a user Group. This is a Unique auto generated primary key column value of the entity',
  `USER_GRP_ID` int(10) NOT NULL COMMENT 'User Group Name',
  `USER_ID` int(10) NOT NULL COMMENT 'User Domain Identifier. It is a foreign key column value from the security domain table. Blank Id values indicates that it is a system generated  record and can be used across all the accounts',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`USER_GRP_DTL_ID`),
  KEY `FK_USERGROUPDTL_USERGRPID` (`USER_GRP_ID`),
  KEY `FK_USERGROUPDTL_USERID` (`USER_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the User info associated with a group' AUTO_INCREMENT=31 ;

--
-- Dumping data for table `user_group_dtl`
--

INSERT INTO `user_group_dtl` (`USER_GRP_DTL_ID`, `USER_GRP_ID`, `USER_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 2, 1, 1, NULL, '2014-04-08 07:32:31', NULL),
(2, 2, 2, 1, NULL, '2014-04-08 07:32:31', NULL),
(8, 3, 2, 1, NULL, '2014-04-08 09:51:46', NULL),
(9, 3, 6, 1, NULL, '2014-04-08 09:51:46', NULL),
(24, 2, 4, NULL, NULL, NULL, NULL),
(25, 2, 5, NULL, NULL, NULL, NULL),
(26, 2, 6, NULL, NULL, NULL, NULL),
(28, 1, 2, NULL, NULL, NULL, NULL),
(29, 1, 5, NULL, NULL, NULL, NULL),
(30, 2, 6, 0, 0, '2014-04-09 05:38:22', '2014-04-09 05:39:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_group_role`
--

CREATE TABLE IF NOT EXISTS `user_group_role` (
  `GRP_ROLE_ID` int(10) NOT NULL,
  `ROLE_ID` int(10) NOT NULL,
  `USER_GRP_ID` int(10) NOT NULL,
  `CREATED_BY` int(10) DEFAULT NULL,
  `UPDATED_BY` int(10) DEFAULT NULL,
  `CREATED_ON` datetime DEFAULT NULL,
  `UPDATED_ON` datetime DEFAULT NULL,
  PRIMARY KEY (`GRP_ROLE_ID`),
  UNIQUE KEY `USERGROUPROLE_UsrGrpIDRoleID` (`GRP_ROLE_ID`,`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_group_role`
--

INSERT INTO `user_group_role` (`GRP_ROLE_ID`, `ROLE_ID`, `USER_GRP_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 1, 1, 3, 3, '2014-04-02 00:00:00', '2014-04-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_mst`
--

CREATE TABLE IF NOT EXISTS `user_mst` (
  `USER_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'User Identifier. This is the primary key of the entity and is unique throughout the system',
  `USER_NAME` varchar(40) NOT NULL COMMENT 'User Name',
  `REG_EMAIL_ID` varchar(40) NOT NULL COMMENT 'Registered email address of the user',
  `PASSWORD` varchar(40) NOT NULL COMMENT 'Password of an user',
  `USER_STATUS_ID` int(10) NOT NULL COMMENT 'Status of the user such as Active, Inactive etc. This value is driven from master data. It is a foreign key column]',
  `EXT_REF_NBR` varchar(40) DEFAULT NULL COMMENT 'External Reference ID',
  `LAST_LOGIN_AT` datetime NOT NULL COMMENT 'Last Login date and time of an user',
  `DMN_ID` int(10) DEFAULT NULL COMMENT 'Domain Identifier is the foreign key of this entity. This information is mapped with domain entity',
  `ACTIVATION` varchar(100) DEFAULT NULL COMMENT 'Activation column is used to generate the Activation key for a new user. Once the user has validated his account this column will become blank',
  `IS_EDITABLE` tinyint(1) DEFAULT '1' COMMENT 'Flag to mark the record editable. True means editable, false means non editable',
  `IS_DELETED` tinyint(1) DEFAULT '0' COMMENT 'Flag to mark the record for soft delete. Once Spft deleted the record willnot be visible to non admin users. Non editable records cannnot be deleted',
  `IS_ADMIN` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Flag mark the user  as an admin of the organisation',
  `IS_ASSIGNABLE` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Flag to validate if the user can be assigned to any role or group profile and domain\nFalse means NO\nTrue means YES',
  `IS_PREDEFINED` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Flag to mark that the user  is a predefined system user',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `UK_USERMST_REGEMAILID` (`REG_EMAIL_ID`),
  UNIQUE KEY `UK_USERMST_USERNAMEDMNID` (`USER_NAME`,`DMN_ID`),
  KEY `FK_USERMST_USERSTATUSID` (`USER_STATUS_ID`),
  KEY `FK_USERMST_DMNID` (`DMN_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the Master Data definitions of all the Users' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `user_mst`
--

INSERT INTO `user_mst` (`USER_ID`, `USER_NAME`, `REG_EMAIL_ID`, `PASSWORD`, `USER_STATUS_ID`, `EXT_REF_NBR`, `LAST_LOGIN_AT`, `DMN_ID`, `ACTIVATION`, `IS_EDITABLE`, `IS_DELETED`, `IS_ADMIN`, `IS_ASSIGNABLE`, `IS_PREDEFINED`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(1, 'sysadmin', 'prdsupport@geeconglobal.com', 'Geecon0404', 1, NULL, '2014-04-11 04:06:26', 1, NULL, 1, 0, 0, 1, 0, NULL, NULL, '2014-04-03 00:00:00', '2014-04-03 00:00:00'),
(2, 'ankitd', 'ankitd@geeconglobal.com', 'ankitd', 1, NULL, '2014-04-11 10:07:55', 2, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-05 12:21:51', '2014-04-05 12:21:51'),
(4, 'nehap', 'nehap@geeconglobal.com', 'nehap', 1, NULL, '2014-04-07 04:32:02', 1, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-05 14:44:40', '2014-04-05 14:44:40'),
(5, 'sherwinm', 'sherwinm@geeconglobal.com', '123', 1, NULL, '0000-00-00 00:00:00', 3, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-07 04:35:39', '2014-04-07 04:35:39'),
(6, 'graminal', 'graminal@geeconglobal.com', '123', 1, NULL, '2014-04-09 07:15:02', 3, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-07 04:50:14', '2014-04-07 04:50:14'),
(7, 'prajaktab', 'prajaktabhatkar@geeconglobal.com', '1234', 1, NULL, '0000-00-00 00:00:00', 4, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-07 04:59:29', '2014-04-07 04:59:29'),
(9, 'aakashmewada', 'akash@geeconglobal.com', '123', 1, NULL, '0000-00-00 00:00:00', 1, 'da87912e514bb9149241a50d121b718c', 1, 0, 0, 1, 0, 0, 0, '2014-04-09 08:55:46', '2014-04-09 08:55:46'),
(10, 'praju', 'prajktab@geeconglobal.com', '123', 1, NULL, '0000-00-00 00:00:00', 1, 'fcc4a32bd52cdabd474f3d17baf94882', 1, 0, 0, 1, 0, 0, 0, '2014-04-09 09:06:14', '2014-04-09 09:06:14'),
(11, 'prajakta', 'prajaktab17@geeconglobal.com', '123', 1, NULL, '0000-00-00 00:00:00', 1, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-09 09:20:56', '2014-04-09 09:20:56'),
(12, 'prajub', 'prajaktab172@geeconglobal.com', 'gargi', 1, NULL, '0000-00-00 00:00:00', 1, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-09 09:34:26', '2014-04-09 09:34:26'),
(13, 'prajb', 'prajaktab@geeconglobal.com', '123', 1, NULL, '0000-00-00 00:00:00', 1, NULL, 1, 0, 0, 1, 0, 0, 0, '2014-04-09 09:36:16', '2014-04-09 09:36:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `USER_ROLE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Unique Id is generated for user role. It is a Auto ganerated primary key column',
  `ROLE_ID` int(10) NOT NULL COMMENT 'Foreign key column value driven from Role master table',
  `USER_ID` int(10) NOT NULL COMMENT 'User id of an user assigned with a role',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`USER_ROLE_ID`),
  UNIQUE KEY `UK_USERROLE_ROLEIDUSERID` (`ROLE_ID`,`USER_ID`),
  KEY `FK_USERROLE_USERID` (`USER_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='This stores the User Roles of the system. A Typical relationship is where a user role will have Role Master. Here this table will hold this relationship' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`USER_ROLE_ID`, `ROLE_ID`, `USER_ID`, `CREATED_BY`, `UPDATED_BY`, `CREATED_ON`, `UPDATED_ON`) VALUES
(3, 1, 2, 5, 5, '2014-04-09 04:54:39', '2014-04-09 05:05:45');

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_status_vw`
--
CREATE TABLE IF NOT EXISTS `user_status_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_obj_mst_vw`
--
CREATE TABLE IF NOT EXISTS `view_obj_mst_vw` (
`MSTR_ID` int(10)
,`MSTR_CD` varchar(10)
,`MSTR_NM` varchar(40)
,`TYP_ID` int(10)
,`RECORD_TYP` int(10)
,`IS_EDITABLE` tinyint(1)
,`IS_DELETED` tinyint(1)
,`OA_ID` int(10)
,`CREATED_BY` int(10)
,`UPDATED_BY` int(10)
,`CREATED_ON` datetime
,`UPDATED_ON` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `work_week_dtl`
--

CREATE TABLE IF NOT EXISTS `work_week_dtl` (
  `WORK_WEEK_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'work week id identifier. This is a Unique auto generated primary key column of this entity',
  `OPERATIONAL_COUNTRY_ID` int(10) DEFAULT NULL COMMENT 'Foreign key column value driven from Operional conutry master table',
  `MON` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `TUE` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `WED` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `THU` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `FRI` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `SAT` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `SUN` tinyint(3) DEFAULT '0' COMMENT 'Work week days ',
  `OA_BRAND_ID` int(10) NOT NULL COMMENT 'Brand  or company id',
  `CREATED_BY` int(10) DEFAULT NULL COMMENT 'User who created the records',
  `UPDATED_BY` int(10) DEFAULT NULL COMMENT 'User who updated  the records',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was created',
  `UPDATED_ON` datetime DEFAULT NULL COMMENT 'Date and Time when the record was updated',
  PRIMARY KEY (`WORK_WEEK_ID`),
  KEY `FK_WORKWEEKDTL_OPERATIONALCOUNTRYID` (`OPERATIONAL_COUNTRY_ID`),
  KEY `FK_WORKWEEKDTL_OABRANDID` (`OA_BRAND_ID`),
  KEY `FK_WORKWEEKDTL_CREATEDBY` (`CREATED_BY`),
  KEY `FK_WORKWEEKDTL_UPDATEDBY` (`UPDATED_BY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='This stores the  Data definitions of employees work week' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure for view `appl_name_mst_vw`
--
DROP TABLE IF EXISTS `appl_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `appl_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 75);

-- --------------------------------------------------------

--
-- Structure for view `area_name_mst_vw`
--
DROP TABLE IF EXISTS `area_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `area_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 67);

-- --------------------------------------------------------

--
-- Structure for view `board_of_dirs_mst_vw`
--
DROP TABLE IF EXISTS `board_of_dirs_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `board_of_dirs_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 70);

-- --------------------------------------------------------

--
-- Structure for view `buss_layer_obj_mst_vw`
--
DROP TABLE IF EXISTS `buss_layer_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `buss_layer_obj_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 18);

-- --------------------------------------------------------

--
-- Structure for view `cast_mst_vw`
--
DROP TABLE IF EXISTS `cast_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `cast_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 135);

-- --------------------------------------------------------

--
-- Structure for view `city_name_mst_vw`
--
DROP TABLE IF EXISTS `city_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `city_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 65);

-- --------------------------------------------------------

--
-- Structure for view `cntrllr_obj_mst_vw`
--
DROP TABLE IF EXISTS `cntrllr_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `cntrllr_obj_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 23);

-- --------------------------------------------------------

--
-- Structure for view `company_name_mst_vw`
--
DROP TABLE IF EXISTS `company_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `company_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 54);

-- --------------------------------------------------------

--
-- Structure for view `comp_hier_mst_vw`
--
DROP TABLE IF EXISTS `comp_hier_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `comp_hier_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 52);

-- --------------------------------------------------------

--
-- Structure for view `contact_address_type_vw`
--
DROP TABLE IF EXISTS `contact_address_type_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `contact_address_type_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 142);

-- --------------------------------------------------------

--
-- Structure for view `contact_relation_type_mst_vw`
--
DROP TABLE IF EXISTS `contact_relation_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `contact_relation_type_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 137);

-- --------------------------------------------------------

--
-- Structure for view `continent_name_mst_vw`
--
DROP TABLE IF EXISTS `continent_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `continent_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 60);

-- --------------------------------------------------------

--
-- Structure for view `country_name_mst_vw`
--
DROP TABLE IF EXISTS `country_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `country_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 61);

-- --------------------------------------------------------

--
-- Structure for view `county_name_mst_vw`
--
DROP TABLE IF EXISTS `county_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `county_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 63);

-- --------------------------------------------------------

--
-- Structure for view `data_layer_obj_mst_vw`
--
DROP TABLE IF EXISTS `data_layer_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `data_layer_obj_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 19);

-- --------------------------------------------------------

--
-- Structure for view `db_funcations_mst_vw`
--
DROP TABLE IF EXISTS `db_funcations_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_funcations_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 34);

-- --------------------------------------------------------

--
-- Structure for view `db_obj_type_mst_vw`
--
DROP TABLE IF EXISTS `db_obj_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_obj_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 26);

-- --------------------------------------------------------

--
-- Structure for view `db_procs_mst_vw`
--
DROP TABLE IF EXISTS `db_procs_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_procs_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 35);

-- --------------------------------------------------------

--
-- Structure for view `db_tables_mst_vw`
--
DROP TABLE IF EXISTS `db_tables_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_tables_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 31);

-- --------------------------------------------------------

--
-- Structure for view `db_triggers_mst_vw`
--
DROP TABLE IF EXISTS `db_triggers_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_triggers_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 33);

-- --------------------------------------------------------

--
-- Structure for view `db_views_mst_vw`
--
DROP TABLE IF EXISTS `db_views_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `db_views_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 32);

-- --------------------------------------------------------

--
-- Structure for view `dept_name_mst_vw`
--
DROP TABLE IF EXISTS `dept_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `dept_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 57);

-- --------------------------------------------------------

--
-- Structure for view `directors_mst_vw`
--
DROP TABLE IF EXISTS `directors_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `directors_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 71);

-- --------------------------------------------------------

--
-- Structure for view `district_name_mst_vw`
--
DROP TABLE IF EXISTS `district_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `district_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 64);

-- --------------------------------------------------------

--
-- Structure for view `division_name_mst_vw`
--
DROP TABLE IF EXISTS `division_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `division_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 55);

-- --------------------------------------------------------

--
-- Structure for view `email_account_use_type_vw`
--
DROP TABLE IF EXISTS `email_account_use_type_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `email_account_use_type_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 141);

-- --------------------------------------------------------

--
-- Structure for view `eml_notification_mst_vw`
--
DROP TABLE IF EXISTS `eml_notification_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `eml_notification_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 102);

-- --------------------------------------------------------

--
-- Structure for view `emt_sys_err_mst_vw`
--
DROP TABLE IF EXISTS `emt_sys_err_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_sys_err_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 9);

-- --------------------------------------------------------

--
-- Structure for view `emt_sys_info_mst_vw`
--
DROP TABLE IF EXISTS `emt_sys_info_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_sys_info_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 7);

-- --------------------------------------------------------

--
-- Structure for view `emt_sys_warn_mst_vw`
--
DROP TABLE IF EXISTS `emt_sys_warn_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_sys_warn_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 8);

-- --------------------------------------------------------

--
-- Structure for view `emt_usr_err_mst_vw`
--
DROP TABLE IF EXISTS `emt_usr_err_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_usr_err_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 12);

-- --------------------------------------------------------

--
-- Structure for view `emt_usr_info_mst_vw`
--
DROP TABLE IF EXISTS `emt_usr_info_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_usr_info_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 10);

-- --------------------------------------------------------

--
-- Structure for view `emt_usr_warn_mst_vw`
--
DROP TABLE IF EXISTS `emt_usr_warn_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `emt_usr_warn_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 11);

-- --------------------------------------------------------

--
-- Structure for view `entity_obj_type_mst_vw`
--
DROP TABLE IF EXISTS `entity_obj_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `entity_obj_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 24);

-- --------------------------------------------------------

--
-- Structure for view `epic_name_mst_vw`
--
DROP TABLE IF EXISTS `epic_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `epic_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 77);

-- --------------------------------------------------------

--
-- Structure for view `ethinicity_mst_vw`
--
DROP TABLE IF EXISTS `ethinicity_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `ethinicity_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 144);

-- --------------------------------------------------------

--
-- Structure for view `exception_message_type_mst_vw`
--
DROP TABLE IF EXISTS `exception_message_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `exception_message_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 6);

-- --------------------------------------------------------

--
-- Structure for view `exe_mngmnt_mst_vw`
--
DROP TABLE IF EXISTS `exe_mngmnt_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `exe_mngmnt_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 69);

-- --------------------------------------------------------

--
-- Structure for view `feature_name_mst_vw`
--
DROP TABLE IF EXISTS `feature_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `feature_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 78);

-- --------------------------------------------------------

--
-- Structure for view `form_mst_vw`
--
DROP TABLE IF EXISTS `form_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `form_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 27);

-- --------------------------------------------------------

--
-- Structure for view `gender_mst_vw`
--
DROP TABLE IF EXISTS `gender_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `gender_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 133);

-- --------------------------------------------------------

--
-- Structure for view `geo_hier_mst_vw`
--
DROP TABLE IF EXISTS `geo_hier_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `geo_hier_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 59);

-- --------------------------------------------------------

--
-- Structure for view `global_setting_item_mst_vw`
--
DROP TABLE IF EXISTS `global_setting_item_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `global_setting_item_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 36);

-- --------------------------------------------------------

--
-- Structure for view `group_name_mst_vw`
--
DROP TABLE IF EXISTS `group_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `group_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 53);

-- --------------------------------------------------------

--
-- Structure for view `gsdatavaluetype_mst_vw`
--
DROP TABLE IF EXISTS `gsdatavaluetype_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `gsdatavaluetype_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 2);

-- --------------------------------------------------------

--
-- Structure for view `hierarchy_type_vw`
--
DROP TABLE IF EXISTS `hierarchy_type_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `hierarchy_type_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 51);

-- --------------------------------------------------------

--
-- Structure for view `hod_mst_vw`
--
DROP TABLE IF EXISTS `hod_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `hod_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 72);

-- --------------------------------------------------------

--
-- Structure for view `inface_obj_type_mst_vw`
--
DROP TABLE IF EXISTS `inface_obj_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `inface_obj_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 25);

-- --------------------------------------------------------

--
-- Structure for view `leave_type_vw`
--
DROP TABLE IF EXISTS `leave_type_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `leave_type_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 182);

-- --------------------------------------------------------

--
-- Structure for view `location_name_mst_vw`
--
DROP TABLE IF EXISTS `location_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `location_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 56);

-- --------------------------------------------------------

--
-- Structure for view `mail_type_mst_vw`
--
DROP TABLE IF EXISTS `mail_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `mail_type_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 101);

-- --------------------------------------------------------

--
-- Structure for view `manager_mst_vw`
--
DROP TABLE IF EXISTS `manager_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `manager_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 73);

-- --------------------------------------------------------

--
-- Structure for view `marrital_status_mst_vw`
--
DROP TABLE IF EXISTS `marrital_status_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `marrital_status_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 134);

-- --------------------------------------------------------

--
-- Structure for view `menu_hier_vw`
--
DROP TABLE IF EXISTS `menu_hier_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `menu_hier_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 80);

-- --------------------------------------------------------

--
-- Structure for view `menu_item_mst_vw`
--
DROP TABLE IF EXISTS `menu_item_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `menu_item_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 30);

-- --------------------------------------------------------

--
-- Structure for view `mngt_hier_mst_vw`
--
DROP TABLE IF EXISTS `mngt_hier_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `mngt_hier_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 68);

-- --------------------------------------------------------

--
-- Structure for view `model_obj_mst_vw`
--
DROP TABLE IF EXISTS `model_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `model_obj_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 21);

-- --------------------------------------------------------

--
-- Structure for view `module_name_mst_vw`
--
DROP TABLE IF EXISTS `module_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `module_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 76);

-- --------------------------------------------------------

--
-- Structure for view `nationality_mst_vw`
--
DROP TABLE IF EXISTS `nationality_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `nationality_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 139);

-- --------------------------------------------------------

--
-- Structure for view `non_personal_contact_type_mst_vw`
--
DROP TABLE IF EXISTS `non_personal_contact_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `non_personal_contact_type_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 138);

-- --------------------------------------------------------

--
-- Structure for view `obj_layer_type_mst_vw`
--
DROP TABLE IF EXISTS `obj_layer_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `obj_layer_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 17);

-- --------------------------------------------------------

--
-- Structure for view `orgacct_settings_mst_vw`
--
DROP TABLE IF EXISTS `orgacct_settings_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `orgacct_settings_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 41);

-- --------------------------------------------------------

--
-- Structure for view `performance_status_vw`
--
DROP TABLE IF EXISTS `performance_status_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `performance_status_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 183);

-- --------------------------------------------------------

--
-- Structure for view `phone_number_type_mst_vw`
--
DROP TABLE IF EXISTS `phone_number_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `phone_number_type_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 140);

-- --------------------------------------------------------

--
-- Structure for view `prcss_obj_type_mst_vw`
--
DROP TABLE IF EXISTS `prcss_obj_type_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `prcss_obj_type_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 27);

-- --------------------------------------------------------

--
-- Structure for view `prsnttn_layer_obj_mst_vw`
--
DROP TABLE IF EXISTS `prsnttn_layer_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `prsnttn_layer_obj_mst_vw` AS select `common_type`.`TYP_ID` AS `TYP_ID`,`common_type`.`TYP_CD` AS `TYP_CD`,`common_type`.`TYP_NM` AS `TYP_NM`,`common_type`.`VIEW_NM` AS `VIEW_NM`,`common_type`.`PARENT_TYP_ID` AS `PARENT_TYP_ID`,`common_type`.`IS_EDITABLE` AS `IS_EDITABLE`,`common_type`.`IS_DELETED` AS `IS_DELETED`,`common_type`.`OA_ID` AS `OA_ID`,`common_type`.`CREATED_BY` AS `CREATED_BY`,`common_type`.`UPDATED_BY` AS `UPDATED_BY`,`common_type`.`CREATED_ON` AS `CREATED_ON`,`common_type`.`UPDATED_ON` AS `UPDATED_ON` from `common_type` where (`common_type`.`PARENT_TYP_ID` = 20);

-- --------------------------------------------------------

--
-- Structure for view `race_mst_vw`
--
DROP TABLE IF EXISTS `race_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `race_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 136);

-- --------------------------------------------------------

--
-- Structure for view `relegion_mst_vw`
--
DROP TABLE IF EXISTS `relegion_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `relegion_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 143);

-- --------------------------------------------------------

--
-- Structure for view `salutation_mst_vw`
--
DROP TABLE IF EXISTS `salutation_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `salutation_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 132);

-- --------------------------------------------------------

--
-- Structure for view `state_name_mst_vw`
--
DROP TABLE IF EXISTS `state_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `state_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 62);

-- --------------------------------------------------------

--
-- Structure for view `subdept_name_mst_vw`
--
DROP TABLE IF EXISTS `subdept_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `subdept_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 58);

-- --------------------------------------------------------

--
-- Structure for view `sw_app_hier_mst_vw`
--
DROP TABLE IF EXISTS `sw_app_hier_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `sw_app_hier_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 74);

-- --------------------------------------------------------

--
-- Structure for view `systempermisiontype_mst_vw`
--
DROP TABLE IF EXISTS `systempermisiontype_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `systempermisiontype_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 1);

-- --------------------------------------------------------

--
-- Structure for view `theme_name_mst_vw`
--
DROP TABLE IF EXISTS `theme_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `theme_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 79);

-- --------------------------------------------------------

--
-- Structure for view `toolbar_mst_vw`
--
DROP TABLE IF EXISTS `toolbar_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `toolbar_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 29);

-- --------------------------------------------------------

--
-- Structure for view `town_name_mst_vw`
--
DROP TABLE IF EXISTS `town_name_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `town_name_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON`,`independent_mst`.`IS_PREDEFINED` AS `IS_PREDEFINED` from `independent_mst` where (`independent_mst`.`TYP_ID` = 66);

-- --------------------------------------------------------

--
-- Structure for view `user_contact_type_vw`
--
DROP TABLE IF EXISTS `user_contact_type_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `user_contact_type_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 47);

-- --------------------------------------------------------

--
-- Structure for view `user_status_vw`
--
DROP TABLE IF EXISTS `user_status_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `user_status_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 46);

-- --------------------------------------------------------

--
-- Structure for view `view_obj_mst_vw`
--
DROP TABLE IF EXISTS `view_obj_mst_vw`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mydev`@`localhost` SQL SECURITY DEFINER VIEW `view_obj_mst_vw` AS select `independent_mst`.`MSTR_ID` AS `MSTR_ID`,`independent_mst`.`MSTR_CD` AS `MSTR_CD`,`independent_mst`.`MSTR_NM` AS `MSTR_NM`,`independent_mst`.`TYP_ID` AS `TYP_ID`,`independent_mst`.`RECORD_TYP` AS `RECORD_TYP`,`independent_mst`.`IS_EDITABLE` AS `IS_EDITABLE`,`independent_mst`.`IS_DELETED` AS `IS_DELETED`,`independent_mst`.`OA_ID` AS `OA_ID`,`independent_mst`.`CREATED_BY` AS `CREATED_BY`,`independent_mst`.`UPDATED_BY` AS `UPDATED_BY`,`independent_mst`.`CREATED_ON` AS `CREATED_ON`,`independent_mst`.`UPDATED_ON` AS `UPDATED_ON` from `independent_mst` where (`independent_mst`.`TYP_ID` = 22);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address_mst`
--
ALTER TABLE `address_mst`
  ADD CONSTRAINT `address_mst_ibfk_1` FOREIGN KEY (`DWELLING_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `address_mst_ibfk_2` FOREIGN KEY (`STREET_ID`) REFERENCES `street_mst` (`STREET_ID`),
  ADD CONSTRAINT `address_mst_ibfk_3` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`);

--
-- Constraints for table `application_dtl`
--
ALTER TABLE `application_dtl`
  ADD CONSTRAINT `application_dtl_ibfk_1` FOREIGN KEY (`APP_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `application_dtl_ibfk_2` FOREIGN KEY (`FUNCTION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `application_dtl_ibfk_3` FOREIGN KEY (`EPIC_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `application_dtl_ibfk_4` FOREIGN KEY (`FEATURE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `application_dtl_ibfk_5` FOREIGN KEY (`OPTIONAL_THEME_ID`) REFERENCES `independent_mst` (`MSTR_ID`);

--
-- Constraints for table `config_mapping_dtl`
--
ALTER TABLE `config_mapping_dtl`
  ADD CONSTRAINT `config_mapping_dtl_ibfk_1` FOREIGN KEY (`SRC_ENTTY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `config_mapping_dtl_ibfk_2` FOREIGN KEY (`TRGT_ENTTY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `config_mapping_dtl_ibfk_3` FOREIGN KEY (`CNFG_MPPNG_TYP_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `config_mapping_dtl_ibfk_4` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`);

--
-- Constraints for table `contact_address`
--
ALTER TABLE `contact_address`
  ADD CONSTRAINT `contact_address_ibfk_1` FOREIGN KEY (`CNTCT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `contact_address_ibfk_2` FOREIGN KEY (`CNTCT_ADD_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_address_ibfk_3` FOREIGN KEY (`ADD_ID`) REFERENCES `address_mst` (`ADDRESS_ID`),
  ADD CONSTRAINT `contact_address_ibfk_4` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_address_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_address_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `contact_add_phoneno`
--
ALTER TABLE `contact_add_phoneno`
  ADD CONSTRAINT `contact_add_phoneno_ibfk_1` FOREIGN KEY (`CNTCT_ADD_ID`) REFERENCES `contact_address` (`CNTCT_ADD_ID`),
  ADD CONSTRAINT `contact_add_phoneno_ibfk_2` FOREIGN KEY (`CNTCT_NBR_ID`) REFERENCES `contact_phones` (`PHONE_NBR_ID`),
  ADD CONSTRAINT `contact_add_phoneno_ibfk_3` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_add_phoneno_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_add_phoneno_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `contact_emails`
--
ALTER TABLE `contact_emails`
  ADD CONSTRAINT `contact_emails_ibfk_1` FOREIGN KEY (`CNTCT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `contact_emails_ibfk_2` FOREIGN KEY (`EMAIL_ADD_ID`) REFERENCES `email_address_mst` (`EMAIL_ADD_ID`),
  ADD CONSTRAINT `contact_emails_ibfk_3` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_emails_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_emails_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `contact_mst`
--
ALTER TABLE `contact_mst`
  ADD CONSTRAINT `contact_mst_ibfk_1` FOREIGN KEY (`CNTCT_SALUTATION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_2` FOREIGN KEY (`CNTCT_GENDER_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_3` FOREIGN KEY (`MARRITAL_STATUS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_4` FOREIGN KEY (`CAST_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_5` FOREIGN KEY (`RASE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_6` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_7` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_mst_ibfk_8` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `contact_nationality`
--
ALTER TABLE `contact_nationality`
  ADD CONSTRAINT `contact_nationality_ibfk_1` FOREIGN KEY (`CNTCT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `contact_nationality_ibfk_2` FOREIGN KEY (`NATIONALITY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `contact_nationality_ibfk_3` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_nationality_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_nationality_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `contact_phones`
--
ALTER TABLE `contact_phones`
  ADD CONSTRAINT `contact_phones_ibfk_1` FOREIGN KEY (`CNTCT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `contact_phones_ibfk_2` FOREIGN KEY (`PHONE_NBR_ID`) REFERENCES `phone_nbr_mst` (`PHONE_NBR_ID`),
  ADD CONSTRAINT `contact_phones_ibfk_3` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `contact_phones_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `contact_phones_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `currency_mst`
--
ALTER TABLE `currency_mst`
  ADD CONSTRAINT `currency_mst_ibfk_1` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `currency_mst_ibfk_2` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `currency_mst_ibfk_3` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `currency_mst_ibfk_4` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `currency_rate`
--
ALTER TABLE `currency_rate`
  ADD CONSTRAINT `currency_rate_ibfk_1` FOREIGN KEY (`SRC_CURR_ID`) REFERENCES `currency_mst` (`CURR_ID`),
  ADD CONSTRAINT `currency_rate_ibfk_2` FOREIGN KEY (`TRG_CURR_ID`) REFERENCES `currency_mst` (`CURR_ID`),
  ADD CONSTRAINT `currency_rate_ibfk_3` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `currency_rate_ibfk_4` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `dependent_dtl`
--
ALTER TABLE `dependent_dtl`
  ADD CONSTRAINT `dependent_dtl_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `dependent_dtl_ibfk_2` FOREIGN KEY (`OA_DEP_CNTCTS_ID`) REFERENCES `oa_contacts` (`OA_CNTCTS_ID`),
  ADD CONSTRAINT `dependent_dtl_ibfk_3` FOREIGN KEY (`RELATION_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `dependent_dtl_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `dependent_dtl_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `email_account_dtl`
--
ALTER TABLE `email_account_dtl`
  ADD CONSTRAINT `email_account_dtl_ibfk_1` FOREIGN KEY (`EMAIL_ADD_ID`) REFERENCES `email_address_mst` (`EMAIL_ADD_ID`),
  ADD CONSTRAINT `email_account_dtl_ibfk_2` FOREIGN KEY (`CONTACT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `email_account_dtl_ibfk_3` FOREIGN KEY (`EMAIL_ACCT_USE_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `email_account_dtl_ibfk_4` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `email_account_dtl_ibfk_5` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `email_address_mst`
--
ALTER TABLE `email_address_mst`
  ADD CONSTRAINT `email_address_mst_ibfk_1` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `email_address_mst_ibfk_2` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `email_address_mst_ibfk_3` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `email_config`
--
ALTER TABLE `email_config`
  ADD CONSTRAINT `email_config_ibfk_1` FOREIGN KEY (`MAIL_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `email_config_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `email_config_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `email_config_ibfk_4` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `email_config_ibfk_5` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `email_subscriber`
--
ALTER TABLE `email_subscriber`
  ADD CONSTRAINT `email_subscriber_ibfk_1` FOREIGN KEY (`NOTIFICATION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `email_subscriber_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `email_subscriber_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `email_subscriber_ibfk_4` FOREIGN KEY (`CREATEDBY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `email_subscriber_ibfk_5` FOREIGN KEY (`UPDATEDBY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emergency_contact_dtl`
--
ALTER TABLE `emergency_contact_dtl`
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_2` FOREIGN KEY (`EMERG_CONTACT_ID`) REFERENCES `oa_contacts` (`OA_CNTCTS_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_3` FOREIGN KEY (`EMERG_CONTACT_RELATION_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_4` FOREIGN KEY (`EMERG_CONTACT_TEL_ID`) REFERENCES `oa_contact_phones` (`OA_CNTCT_PHONE_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_5` FOREIGN KEY (`EMERG_CONTACT_MOBILE_ID`) REFERENCES `oa_contact_phones` (`OA_CNTCT_PHONE_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_6` FOREIGN KEY (`EMERG_CONTACT_OFFNO_ID`) REFERENCES `oa_contact_phones` (`OA_CNTCT_PHONE_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_7` FOREIGN KEY (`EMERG_CONTACT_EMAIL_ID`) REFERENCES `oa_contact_emails` (`OA_CNTCT_EML_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_8` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emergency_contact_dtl_ibfk_9` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_basic_sal_dtl`
--
ALTER TABLE `emp_basic_sal_dtl`
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_2` FOREIGN KEY (`EMP_GRADE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_3` FOREIGN KEY (`POSITION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_4` FOREIGN KEY (`CURRENCY_ID`) REFERENCES `currency_mst` (`CURR_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_5` FOREIGN KEY (`PAY_FREQUENCY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_6` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_basic_sal_dtl_ibfk_7` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_education`
--
ALTER TABLE `emp_education`
  ADD CONSTRAINT `emp_education_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_education_ibfk_2` FOREIGN KEY (`EDU_QUAL_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_education_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_education_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_language`
--
ALTER TABLE `emp_language`
  ADD CONSTRAINT `emp_language_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_language_ibfk_2` FOREIGN KEY (`LANGUAGE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_language_ibfk_3` FOREIGN KEY (`LANGUAGE_FLUENCY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_language_ibfk_4` FOREIGN KEY (`LANGUAGE_COMPETENCY_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_language_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_language_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_licence`
--
ALTER TABLE `emp_licence`
  ADD CONSTRAINT `emp_licence_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_licence_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_licence_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_mst`
--
ALTER TABLE `emp_mst`
  ADD CONSTRAINT `emp_mst_ibfk_1` FOREIGN KEY (`OA_CNTCTS_ID`) REFERENCES `oa_contacts` (`OA_CNTCTS_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_2` FOREIGN KEY (`OA_CNTCT_ADD_ID`) REFERENCES `oa_contact_address` (`OA_CNTCT_ADD_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_3` FOREIGN KEY (`OA_CNTCT_EML_ID`) REFERENCES `oa_contact_emails` (`OA_CNTCT_EML_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_4` FOREIGN KEY (`OA_CNTCT_PHONE_ID`) REFERENCES `oa_contact_phones` (`OA_CNTCT_PHONE_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_5` FOREIGN KEY (`EMP_STATUS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_6` FOREIGN KEY (`JOB_TITLE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_7` FOREIGN KEY (`JOB_CAT_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_8` FOREIGN KEY (`EMP_GRADE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_9` FOREIGN KEY (`TERMINATION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_10` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_11` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_mst_ibfk_12` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_picture`
--
ALTER TABLE `emp_picture`
  ADD CONSTRAINT `emp_picture_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_picture_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_picture_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_reporting`
--
ALTER TABLE `emp_reporting`
  ADD CONSTRAINT `emp_reporting_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_reporting_ibfk_2` FOREIGN KEY (`MANAGER_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_reporting_ibfk_3` FOREIGN KEY (`MANAGER_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_reporting_ibfk_4` FOREIGN KEY (`REPORTING_MODE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_reporting_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_reporting_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_reporting_locations`
--
ALTER TABLE `emp_reporting_locations`
  ADD CONSTRAINT `emp_reporting_locations_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_reporting_locations_ibfk_2` FOREIGN KEY (`LOCATION_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `emp_reporting_locations_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_reporting_locations_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_skill`
--
ALTER TABLE `emp_skill`
  ADD CONSTRAINT `emp_skill_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_skill_ibfk_2` FOREIGN KEY (`SKILL_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_skill_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_skill_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_work_experience`
--
ALTER TABLE `emp_work_experience`
  ADD CONSTRAINT `emp_work_experience_ibfk_1` FOREIGN KEY (`EMP_ID`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_work_experience_ibfk_2` FOREIGN KEY (`JOB_TITLE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `emp_work_experience_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_work_experience_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `emp_work_shift`
--
ALTER TABLE `emp_work_shift`
  ADD CONSTRAINT `emp_work_shift_ibfk_1` FOREIGN KEY (`WORK_SHIFT_ID`) REFERENCES `shift_mst` (`SHIFT_ID`),
  ADD CONSTRAINT `emp_work_shift_ibfk_2` FOREIGN KEY (`EMP_NUMBER`) REFERENCES `emp_mst` (`EMP_ID`),
  ADD CONSTRAINT `emp_work_shift_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `emp_work_shift_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `entity_obj_attrbt_mppng`
--
ALTER TABLE `entity_obj_attrbt_mppng`
  ADD CONSTRAINT `entity_obj_attrbt_mppng_ibfk_1` FOREIGN KEY (`OBJ_MPPNG_ID`) REFERENCES `entity_obj_mppng` (`OBJ_MPPNG_ID`);

--
-- Constraints for table `exception_log`
--
ALTER TABLE `exception_log`
  ADD CONSTRAINT `exception_log_ibfk_1` FOREIGN KEY (`EXCEPTION_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `exception_log_ibfk_2` FOREIGN KEY (`APP_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `exception_log_ibfk_3` FOREIGN KEY (`MODULE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `exception_log_ibfk_4` FOREIGN KEY (`PROCESS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `exception_log_ibfk_5` FOREIGN KEY (`MSG_ID`) REFERENCES `message_mst` (`MSG_ID`);

--
-- Constraints for table `group_role`
--
ALTER TABLE `group_role`
  ADD CONSTRAINT `group_role_ibfk_1` FOREIGN KEY (`ROLE_ID`) REFERENCES `role_mst` (`ROLE_ID`),
  ADD CONSTRAINT `group_role_ibfk_2` FOREIGN KEY (`USER_GRP_ID`) REFERENCES `user_group` (`USER_GRP_ID`);

--
-- Constraints for table `hier_level_config`
--
ALTER TABLE `hier_level_config`
  ADD CONSTRAINT `hier_level_config_ibfk_1` FOREIGN KEY (`HIER_TYPE_ID`) REFERENCES `common_type` (`TYP_ID`),
  ADD CONSTRAINT `hier_level_config_ibfk_2` FOREIGN KEY (`HIER_CHILD_ENTITY_TYPE_ID`) REFERENCES `common_type` (`TYP_ID`),
  ADD CONSTRAINT `hier_level_config_ibfk_4` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `hier_level_config_ibfk_5` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`);

--
-- Constraints for table `holiday_mst`
--
ALTER TABLE `holiday_mst`
  ADD CONSTRAINT `holiday_mst_ibfk_1` FOREIGN KEY (`OPERATIONAL_COUNTRY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `holiday_mst_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `holiday_mst_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `holiday_mst_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `independent_mst`
--
ALTER TABLE `independent_mst`
  ADD CONSTRAINT `independent_mst_ibfk_1` FOREIGN KEY (`TYP_ID`) REFERENCES `common_type` (`TYP_ID`);

--
-- Constraints for table `leavetype_dtl`
--
ALTER TABLE `leavetype_dtl`
  ADD CONSTRAINT `leavetype_dtl_ibfk_1` FOREIGN KEY (`LEAVE_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `leavetype_dtl_ibfk_2` FOREIGN KEY (`OPERATIONAL_COUNTRY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `leavetype_dtl_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leavetype_dtl_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leavetype_dtl_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `leave_dtl`
--
ALTER TABLE `leave_dtl`
  ADD CONSTRAINT `leave_dtl_ibfk_1` FOREIGN KEY (`LEAVE_REQUEST_ID`) REFERENCES `leave_requests_dtl` (`LEAVE_REQUEST_ID`),
  ADD CONSTRAINT `leave_dtl_ibfk_2` FOREIGN KEY (`LEAVE_EMP_ID`) REFERENCES `leave_employee` (`LEAVE_EMP_ID`),
  ADD CONSTRAINT `leave_dtl_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leave_dtl_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leave_dtl_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `leave_employee`
--
ALTER TABLE `leave_employee`
  ADD CONSTRAINT `leave_employee_ibfk_1` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leave_employee_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leave_employee_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `leave_period_mst`
--
ALTER TABLE `leave_period_mst`
  ADD CONSTRAINT `leave_period_mst_ibfk_1` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leave_period_mst_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leave_period_mst_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `leave_quota`
--
ALTER TABLE `leave_quota`
  ADD CONSTRAINT `leave_quota_ibfk_1` FOREIGN KEY (`LEAVE_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `leave_quota_ibfk_2` FOREIGN KEY (`LEAVE_PERIOD_ID`) REFERENCES `leave_period_mst` (`LEAVE_PERIOD_ID`),
  ADD CONSTRAINT `leave_quota_ibfk_3` FOREIGN KEY (`LEAVE_EMP_ID`) REFERENCES `leave_employee` (`LEAVE_EMP_ID`),
  ADD CONSTRAINT `leave_quota_ibfk_4` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leave_quota_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leave_quota_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `leave_requests_dtl`
--
ALTER TABLE `leave_requests_dtl`
  ADD CONSTRAINT `leave_requests_dtl_ibfk_1` FOREIGN KEY (`LEAVE_TYPE_ID`) REFERENCES `leavetype_dtl` (`LEAVE_TYPE_ID`),
  ADD CONSTRAINT `leave_requests_dtl_ibfk_2` FOREIGN KEY (`LEAVE_PERIOD_ID`) REFERENCES `leave_period_mst` (`LEAVE_PERIOD_ID`),
  ADD CONSTRAINT `leave_requests_dtl_ibfk_3` FOREIGN KEY (`LEAVE_EMP_ID`) REFERENCES `leave_employee` (`LEAVE_EMP_ID`),
  ADD CONSTRAINT `leave_requests_dtl_ibfk_4` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `leave_requests_dtl_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `leave_requests_dtl_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `location_mst`
--
ALTER TABLE `location_mst`
  ADD CONSTRAINT `location_mst_ibfk_1` FOREIGN KEY (`LOC_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `location_mst_ibfk_2` FOREIGN KEY (`LOC_TIMEZONE_CD`) REFERENCES `timezone_mst` (`TIME_ZONE_ID`),
  ADD CONSTRAINT `location_mst_ibfk_3` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`);

--
-- Constraints for table `message_mst`
--
ALTER TABLE `message_mst`
  ADD CONSTRAINT `message_mst_ibfk_1` FOREIGN KEY (`SYSTEM_MSG_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `message_mst_ibfk_2` FOREIGN KEY (`MSG_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`);

--
-- Constraints for table `oa_brands`
--
ALTER TABLE `oa_brands`
  ADD CONSTRAINT `oa_brands_ibfk_1` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`);

--
-- Constraints for table `oa_brand_settings`
--
ALTER TABLE `oa_brand_settings`
  ADD CONSTRAINT `oa_brand_settings_ibfk_1` FOREIGN KEY (`OABS_ATTRBUTE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `oa_brand_settings_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`);

--
-- Constraints for table `oa_contacts`
--
ALTER TABLE `oa_contacts`
  ADD CONSTRAINT `oa_contacts_ibfk_1` FOREIGN KEY (`OA_CNTCT_RELTYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `oa_contacts_ibfk_2` FOREIGN KEY (`CNTCT_ID`) REFERENCES `contact_mst` (`CNTCT_ID`),
  ADD CONSTRAINT `oa_contacts_ibfk_3` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contacts_ibfk_4` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contacts_ibfk_5` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contacts_ibfk_6` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `oa_contact_address`
--
ALTER TABLE `oa_contact_address`
  ADD CONSTRAINT `oa_contact_address_ibfk_1` FOREIGN KEY (`CNTCT_ADD_ID`) REFERENCES `contact_address` (`CNTCT_ADD_ID`),
  ADD CONSTRAINT `oa_contact_address_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contact_address_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contact_address_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contact_address_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `oa_contact_add_phoneno`
--
ALTER TABLE `oa_contact_add_phoneno`
  ADD CONSTRAINT `oa_contact_add_phoneno_ibfk_1` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contact_add_phoneno_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contact_add_phoneno_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contact_add_phoneno_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `oa_contact_emails`
--
ALTER TABLE `oa_contact_emails`
  ADD CONSTRAINT `oa_contact_emails_ibfk_1` FOREIGN KEY (`CNTCT_EML_ID`) REFERENCES `contact_emails` (`CNTCT_EML_ID`),
  ADD CONSTRAINT `oa_contact_emails_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contact_emails_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contact_emails_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contact_emails_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `oa_contact_nationality`
--
ALTER TABLE `oa_contact_nationality`
  ADD CONSTRAINT `oa_contact_nationality_ibfk_1` FOREIGN KEY (`CNTCT_NATIONALITY_ID`) REFERENCES `contact_nationality` (`CNTCT_NATIONALITY_ID`),
  ADD CONSTRAINT `oa_contact_nationality_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contact_nationality_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contact_nationality_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contact_nationality_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `oa_contact_phones`
--
ALTER TABLE `oa_contact_phones`
  ADD CONSTRAINT `oa_contact_phones_ibfk_1` FOREIGN KEY (`CNTCT_PHONE_ID`) REFERENCES `contact_phones` (`CNTCT_PHONE_ID`),
  ADD CONSTRAINT `oa_contact_phones_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `oa_contact_phones_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `oa_contact_phones_ibfk_4` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `oa_contact_phones_ibfk_5` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `obj_attrbt_previleges`
--
ALTER TABLE `obj_attrbt_previleges`
  ADD CONSTRAINT `obj_attrbt_previleges_ibfk_1` FOREIGN KEY (`OBJ_ATTRBT_ID`) REFERENCES `entity_obj_attrbt` (`OBJ_ATTRBT_ID`),
  ADD CONSTRAINT `obj_attrbt_previleges_ibfk_2` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `obj_attrbt_previleges_ibfk_3` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `obj_attrbt_previleges_ibfk_4` FOREIGN KEY (`USER_ID`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `org_accounts`
--
ALTER TABLE `org_accounts`
  ADD CONSTRAINT `org_accounts_ibfk_1` FOREIGN KEY (`OA_STATUS_ID`) REFERENCES `independent_mst` (`MSTR_ID`);

--
-- Constraints for table `performance_indicator`
--
ALTER TABLE `performance_indicator`
  ADD CONSTRAINT `performance_indicator_ibfk_1` FOREIGN KEY (`JOB_TITLE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `performance_indicator_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `performance_indicator_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `performance_indicator_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `performance_review`
--
ALTER TABLE `performance_review`
  ADD CONSTRAINT `performance_review_ibfk_1` FOREIGN KEY (`PI_EMP_ID`) REFERENCES `pi_employee` (`PI_EMP_ID`),
  ADD CONSTRAINT `performance_review_ibfk_2` FOREIGN KEY (`REVIEWER_ID`) REFERENCES `performance_review` (`PI_EMP_ID`),
  ADD CONSTRAINT `performance_review_ibfk_3` FOREIGN KEY (`JOB_TITLE_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `performance_review_ibfk_4` FOREIGN KEY (`SUB_DIVISION_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `performance_review_ibfk_5` FOREIGN KEY (`PR_STATUS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `performance_review_ibfk_6` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `performance_review_ibfk_7` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `performance_review_ibfk_8` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `performance_review_comments`
--
ALTER TABLE `performance_review_comments`
  ADD CONSTRAINT `performance_review_comments_ibfk_1` FOREIGN KEY (`PI_EMP_ID`) REFERENCES `pi_employee` (`PI_EMP_ID`),
  ADD CONSTRAINT `performance_review_comments_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `performance_review_comments_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `performance_review_comments_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `permission_dtl`
--
ALTER TABLE `permission_dtl`
  ADD CONSTRAINT `permission_dtl_ibfk_1` FOREIGN KEY (`PERMISSIONS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `permission_dtl_ibfk_2` FOREIGN KEY (`OBJ_ATTRBT_PREVILEGES_ID`) REFERENCES `obj_attrbt_previleges` (`OBJ_ATTRBT_PREVILEGES_ID`);

--
-- Constraints for table `phone_nbr_mst`
--
ALTER TABLE `phone_nbr_mst`
  ADD CONSTRAINT `phone_nbr_mst_ibfk_1` FOREIGN KEY (`OA_ID_ORIGINATED`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `phone_nbr_mst_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `phone_nbr_mst_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `pi_employee`
--
ALTER TABLE `pi_employee`
  ADD CONSTRAINT `pi_employee_ibfk_1` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `pi_employee_ibfk_2` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `pi_employee_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `postcode_mst`
--
ALTER TABLE `postcode_mst`
  ADD CONSTRAINT `postcode_mst_ibfk_1` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `postcode_mst_ibfk_2` FOREIGN KEY (`COUNTY_STATE_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `postcode_mst_ibfk_3` FOREIGN KEY (`TIME_ZONE_ID`) REFERENCES `timezone_mst` (`TIME_ZONE_ID`),
  ADD CONSTRAINT `postcode_mst_ibfk_4` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`);

--
-- Constraints for table `relationship_dtl`
--
ALTER TABLE `relationship_dtl`
  ADD CONSTRAINT `relationship_dtl_ibfk_1` FOREIGN KEY (`HIER_LEVEL_CONFIG_ID`) REFERENCES `hier_level_config` (`HIER_LEVEL_CONFIG_ID`),
  ADD CONSTRAINT `relationship_dtl_ibfk_2` FOREIGN KEY (`HIER_TYPE_ID`) REFERENCES `common_type` (`TYP_ID`),
  ADD CONSTRAINT `relationship_dtl_ibfk_3` FOREIGN KEY (`HIER_CHILD_ENTITY_TYPE_ID`) REFERENCES `common_type` (`TYP_ID`),
  ADD CONSTRAINT `relationship_dtl_ibfk_4` FOREIGN KEY (`HIER_PARENT_ENTITY_TYPE_ID`) REFERENCES `common_type` (`TYP_ID`),
  ADD CONSTRAINT `relationship_dtl_ibfk_5` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `relationship_dtl_ibfk_6` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`);

--
-- Constraints for table `role_mst`
--
ALTER TABLE `role_mst`
  ADD CONSTRAINT `role_mst_ibfk_1` FOREIGN KEY (`DMN_ID`) REFERENCES `user_domain` (`DMN_ID`);

--
-- Constraints for table `shift_mst`
--
ALTER TABLE `shift_mst`
  ADD CONSTRAINT `shift_mst_ibfk_1` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `shift_mst_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `shift_mst_ibfk_3` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `street_mst`
--
ALTER TABLE `street_mst`
  ADD CONSTRAINT `street_mst_ibfk_1` FOREIGN KEY (`TOWN_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `street_mst_ibfk_2` FOREIGN KEY (`CENSUS_BLOCK_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `street_mst_ibfk_3` FOREIGN KEY (`CITY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `street_mst_ibfk_4` FOREIGN KEY (`TERRITORY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `street_mst_ibfk_5` FOREIGN KEY (`DISTRICT_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `street_mst_ibfk_6` FOREIGN KEY (`POSTCODE_ID`) REFERENCES `postcode_mst` (`POSTCODE_ID`),
  ADD CONSTRAINT `street_mst_ibfk_7` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`);

--
-- Constraints for table `timezone_mst`
--
ALTER TABLE `timezone_mst`
  ADD CONSTRAINT `timezone_mst_ibfk_1` FOREIGN KEY (`TIMEZONE_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`);

--
-- Constraints for table `user_contacts`
--
ALTER TABLE `user_contacts`
  ADD CONSTRAINT `user_contacts_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `user_contacts_ibfk_2` FOREIGN KEY (`USER_CNTCT_TYPE_ID`) REFERENCES `independent_mst` (`MSTR_ID`);

--
-- Constraints for table `user_domain`
--
ALTER TABLE `user_domain`
  ADD CONSTRAINT `user_domain_ibfk_1` FOREIGN KEY (`OA_ID`) REFERENCES `org_accounts` (`OA_ID`),
  ADD CONSTRAINT `user_domain_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`);

--
-- Constraints for table `user_group`
--
ALTER TABLE `user_group`
  ADD CONSTRAINT `user_group_ibfk_1` FOREIGN KEY (`DMN_ID`) REFERENCES `user_domain` (`DMN_ID`);

--
-- Constraints for table `user_group_dtl`
--
ALTER TABLE `user_group_dtl`
  ADD CONSTRAINT `user_group_dtl_ibfk_1` FOREIGN KEY (`USER_GRP_ID`) REFERENCES `user_group` (`USER_GRP_ID`),
  ADD CONSTRAINT `user_group_dtl_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `user_mst`
--
ALTER TABLE `user_mst`
  ADD CONSTRAINT `user_mst_ibfk_1` FOREIGN KEY (`USER_STATUS_ID`) REFERENCES `independent_mst` (`MSTR_ID`),
  ADD CONSTRAINT `user_mst_ibfk_2` FOREIGN KEY (`DMN_ID`) REFERENCES `user_domain` (`DMN_ID`);

--
-- Constraints for table `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`ROLE_ID`) REFERENCES `role_mst` (`ROLE_ID`),
  ADD CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `user_mst` (`USER_ID`);

--
-- Constraints for table `work_week_dtl`
--
ALTER TABLE `work_week_dtl`
  ADD CONSTRAINT `work_week_dtl_ibfk_1` FOREIGN KEY (`OPERATIONAL_COUNTRY_ID`) REFERENCES `location_mst` (`LOC_ID`),
  ADD CONSTRAINT `work_week_dtl_ibfk_2` FOREIGN KEY (`OA_BRAND_ID`) REFERENCES `oa_brands` (`OA_BRAND_ID`),
  ADD CONSTRAINT `work_week_dtl_ibfk_3` FOREIGN KEY (`CREATED_BY`) REFERENCES `user_mst` (`USER_ID`),
  ADD CONSTRAINT `work_week_dtl_ibfk_4` FOREIGN KEY (`UPDATED_BY`) REFERENCES `user_mst` (`USER_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
